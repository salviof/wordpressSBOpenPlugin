( function( $ ) {
    $(function() { 
    
    /**
     * Open mobile preview mode on DMM Settings panel click
     */
    $( '.wp-full-overlay' ).on('click', '#accordion-panel-DMM_settings_panel h3' , function() { 
        $('.preview-tablet').trigger('click'); 
        });
    $( '.wp-full-overlay' ).on('click', 'ul#sub-accordion-panel-DMM_settings_panel button.customize-panel-back' , function() { 
        $('.preview-desktop').trigger('click'); 
        }); 
        
    });
   
 $( document ).ready( function() { 
         
     // show/hide conditional controls depending on header format chosen
     var $chiHeaderStyleD = Chi_DMM_Options.chi_header_style_D,
         $chimmcFixedMenu = Chi_DMM_Options.chimmc_fixed_menu,
         $chimmcFullwidthMenu = Chi_DMM_Options.chimmc_fullwidth,
         $chimmcElementGradient = Chi_DMM_Options.chimmc_element_with_gradient,
         $chiMMCiconsEnabled = Chi_DMM_Options.chimmc_icons_on_off,
         $chiMMCiconsAlign = Chi_DMM_Options.chimmc_icons_position,
         $chiMMCbgImageEnabled = Chi_DMM_Options.chimmc_bg_image_on_off,
         $chiMMCmenuGradientEnabled = Chi_DMM_Options.chimmc_menu_gradient_on_off,
         $chiMMCheaderGradientEnabled = Chi_DMM_Options.chimmc_header_gradient_on_off,
         $chidmm_text_align = $('#customize-control-et_divi-chidmm_text_align'),
         $chidmm_fixed = $( '#customize-control-et_divi-chidmm_fixed' ),
         $chidmm_fullwidth = $( '#customize-control-et_divi-chidmm_fullwidth' ),
         $chidmm_fullwidth_phone = $( '#customize-control-et_divi-chidmm_fullwidth_phone' ),
         $chidmm_fullwidth_tablet = $( '#customize-control-et_divi-chidmm_fullwidth_tablet' ),
         $chidmm_collapse_submenu = $( '#customize-control-et_divi-chidmm_collapse_submenu' ),
         $chidmm_border_color = $( '#customize-control-et_divi-chidmm_border_color' ),
         $chidmm_padding = $( '#customize-control-et_divi-chidmm_padding' ),
         $chidmm_padding_slide = $( '#customize-control-et_divi-chidmm_padding_slide' ),
         $chidmm_item_bg_color = $( '#customize-control-et_divi-chidmm_item_bg_color' ),
         $chidmm_current_item_bg_color = $( '#customize-control-et_divi-chidmm_current_item_bg_color' ),
         $chidmm_letter_spacing = $( '#customize-control-et_divi-chidmm_letter_spacing' ),
         $chidmm_font_style = $( '#customize-control-et_divi-chidmm_font_style' ),
         $chidmm_trbl_border_width = $( '#customize-control-et_divi-chidmm_trbl_border_width' ),
         $chidmm_item_border_color = $( '#customize-control-et_divi-chidmm_item_border_color' ),
         $chidmm_item_trbl_border_width = $( '#customize-control-et_divi-chidmm_item_trbl_border_width' ),
         $chidmm_submenu_bg_color = $( '#customize-control-et_divi-chidmm_submenu_bg_color' ),
         $chidmm_border_radius = $( '#customize-control-et_divi-chidmm_border_radius' ),
         $chidmm_item_border_radius = $( '#customize-control-et_divi-chidmm_item_border_radius' ),
         $chi_DMM_Mobile_Menu_shadows = $( '#accordion-section-DMM_Mobile_Menu_shadows h3, #customize-control-et_divi-chidmm_dd_shadow_in_out, #customize-control-et_divi-chidmm_dd_shadow_x_offset, #customize-control-et_divi-chidmm_dd_shadow_y_offset, #customize-control-et_divi-chidmm_dd_shadow_blur, #customize-control-et_divi-chidmm_dd_shadow_spread, #customize-control-et_divi-chidmm_dd_shadow_color' ),
         $chidmm_fixed_menu_height = $( '#customize-control-et_divi-chidmm_fixed_menu_height' ),
         $chidmm_fixed_scrollable = $( '#customize-control-et_divi-chidmm_fixed_scrollable' ),
         $chimmc_menu_gradient_on_off = $( '#customize-control-et_divi-chimmc_menu_gradient_on_off' ),
         $chimmc_menu_gradient_stop1_color = $( '#customize-control-et_divi-chimmc_menu_gradient_stop1_color' ),
         $chimmc_menu_gradient_stop1_location = $( '#customize-control-et_divi-chimmc_menu_gradient_stop1_location' ),
         $chimmc_menu_gradient_stop2_color = $( '#customize-control-et_divi-chimmc_menu_gradient_stop2_color' ),
         $chimmc_menu_gradient_stop2_location = $( '#customize-control-et_divi-chimmc_menu_gradient_stop2_location' ),
         $chimmc_menu_gradient_stop3_color = $( '#customize-control-et_divi-chimmc_menu_gradient_stop3_color' ),
         $chimmc_menu_gradient_stop3_location = $( '#customize-control-et_divi-chimmc_menu_gradient_stop3_location' ),
         $chimmc_menu_gradient_angle = $( '#customize-control-et_divi-chimmc_menu_gradient_angle' ),
         $chimmc_gradient_clip = $('#customize-control-et_divi-chimmc_gradient_clip'),
         $chimmc_bg_image_on_off = $('#customize-control-et_divi-chimmc_bg_image_on_off'),
         $chimmc_bg_image_clip = $('#customize-control-et_divi-chimmc_bg_image_clip'),
         $chimmc_header_gradient_on_off = $( '#customize-control-et_divi-chimmc_header_gradient_on_off' ),
         $chimmc_header_gradient_stop1_color = $( '#customize-control-et_divi-chimmc_header_gradient_stop1_color' ),
         $chimmc_header_gradient_stop1_location = $( '#customize-control-et_divi-chimmc_header_gradient_stop1_location' ),
         $chimmc_header_gradient_stop2_color = $( '#customize-control-et_divi-chimmc_header_gradient_stop2_color' ),
         $chimmc_header_gradient_stop2_location = $( '#customize-control-et_divi-chimmc_header_gradient_stop2_location' ),
         $chimmc_header_gradient_stop3_color = $( '#customize-control-et_divi-chimmc_header_gradient_stop3_color' ),
         $chimmc_header_gradient_stop3_location = $( '#customize-control-et_divi-chimmc_header_gradient_stop3_location' ),
         $chimmc_header_gradient_angle = $( '#customize-control-et_divi-chimmc_header_gradient_angle' ),
         $chimmc_animations_acc_section = $( '#accordion-section-DMM_Mobile_Menu_animations h3' ),
         $chimmc_animations_sub_acc_section = $( 'ul#sub-accordion-section-DMM_Mobile_Menu_animations' ),
         $chimmc_header_text_color = $( '#customize-control-et_divi-chimmc_header_text_color' ),
         $chimmc_menu_bar_format = $( '#customize-control-et_divi-chimmc_menu_bar_format' ),
         $chimmc_menu_bar_text = $( '#customize-control-et_divi-chimmc_menu_bar_text' ),
         $chimmc_menu_bar_close_text = $( '#customize-control-et_divi-chimmc_menu_bar_close_text' ),
         $chimmc_menu_bar_close_icon = $( '#customize-control-et_divi-chimmc_menu_bar_close_icon' ),
         $chimmc_menu_bar_text_size = $( '#customize-control-et_divi-chimmc_menu_bar_text_size' ),
         $chimmc_menu_bar_icon_size = $( '#customize-control-et_divi-chimmc_menu_bar_icon_size' ),
         $chimmc_menu_search_icon_size = $( '#customize-control-et_divi-chimmc_menu_search_icon_size' ),
         $chimmc_menu_bar_font_style = $( '#customize-control-et_divi-chimmc_menu_bar_font_style' ),
         $chimmc_menu_dd_top_offset = $( '#customize-control-et_divi-chimmc_menu_dd_top_offset' ),
         $chimmc_menu_bar_bg_color = $( '#customize-control-et_divi-chimmc_menu_bar_bg_color' ),
         $chimmc_icons_on_off = $( '#customize-control-et_divi-chimmc_icons_on_off' ),
         $chimmc_icons_position = $( '#customize-control-et_divi-chimmc_icons_position' ),
         $chimmc_align_icons_left = $( '#customize-control-et_divi-chimmc_align_icons_left' ),
         $chimmc_align_icons_right = $( '#customize-control-et_divi-chimmc_align_icons_right' ),
         $chimmc_menu_icons_size = $( '#customize-control-et_divi-chimmc_menu_icons_size' ),
         $chimmc_select_menu = $( '#customize-control-et_divi-chimmc_select_menu' ),
         $chimmc_sec_menu_items_list = $( '#customize-control-et_divi-chimmc_sec_menu_items_list' ),
         $chimmc_search_icon = $( '#customize-control-et_divi-chimmc_search_icon' ),
         $chidmm_collapse_submenu_select = $('#customize-control-et_divi-chidmm_collapse_submenu select'),
         $chimmc_parent_clickable = $('#customize-control-et_divi-chimmc_parent_clickable'),
         $chimmc_toggle_submenus = $('#customize-control-et_divi-chimmc_toggle_submenus'),
         $chimmc_submenu_animation = $('#customize-control-et_divi-chimmc_submenu_animation'),
         $chimmc_submenu_animation_speed = $('#customize-control-et_divi-chimmc_submenu_animation_speed'),
         $chimmc_arrow_styles_on = $('#customize-control-et_divi-chimmc_arrow_styles_on'),
         $chimmc_arrow_styles_on_checkbox = $('#customize-control-et_divi-chimmc_arrow_styles_on input[type=checkbox]'),
         $chimmc_arrow_options_set = $('#customize-control-et_divi-chimmc_parent_arrow, #customize-control-et_divi-chimmc_parent_arrow_rotate, #customize-control-et_divi-chimmc_parent_arrow_size, #customize-control-et_divi-chimmc_parent_arrow_brdr_width, #customize-control-et_divi-chimmc_parent_arrow_brdr_radius, #customize-control-et_divi-chimmc_parent_arrow_padding, #customize-control-et_divi-chimmc_parent_arrow_color, #customize-control-et_divi-chimmc_a_parent_arrow_color, #customize-control-et_divi-chimmc_parent_arrow_bg_color, #customize-control-et_divi-chimmc_parent_arrow_brdr_color'),
         $chimmc_sec_menu_items_position = $('#customize-control-et_divi-chimmc_sec_menu_items_position'),
         $chimmc_menu_items_list = $('#customize-control-et_divi-chimmc_menu_items_list'),
         $chimmc_mob_menu_items_list = $('#customize-control-et_divi-chimmc_mob_menu_items_list'),
         $chimmc_divi_library_layouts_section = $( '#accordion-section-DMM_Divi_Library_Layouts_Settings h3' ),
         $chimmc_pb_layouts_add_above = $( '#customize-control-et_divi-chimmc_pb_layouts_add_above' ),
         $chimmc_pb_layouts_add_below = $( '#customize-control-et_divi-chimmc_pb_layouts_add_below' );
     
     
     // reset control value to default
        $('.chidmm_reset_slider').on('click', function () {
            var $this_input_slider = $( this ).closest('div.chidmm-multi-box-control-input').find('input.chidmm-multi-box-slider'),
                $this_input_box = $( this ).closest('div.chidmm-multi-box-control-input').find('input.et-pb-range-input'),
                input_default = $this_input_slider.data('reset_value');

                $this_input_box.val( input_default );
                $this_input_slider.val( input_default );
            $this_input_slider.change();
        });
     
     /* show/hide parent arrow options set */
     function show_hide_parent_arrow_options_set(){
        /* show/hide parent arrow options set on load */
        if($chimmc_arrow_styles_on_checkbox.is(':checked')){
            $chimmc_arrow_options_set.fadeIn(800);
        } else {
            $chimmc_arrow_options_set.fadeOut(800);
            }
        /* show/hide parent arrow options set on change */
        $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chimmc_arrow_styles_on input[type=checkbox]', function(){

            is_checked = $(this).is(':checked');

            if ( is_checked ) {
                $chimmc_arrow_options_set.fadeIn(800);
            } else {
                $chimmc_arrow_options_set.fadeOut(800);
            }

        });
         
     }
     
     /* show/hide submenu animation speed option */
     function show_hide_submenu_animation_speed(){
         
        var $chimmc_submenu_animation_selected_value = $('#customize-control-et_divi-chimmc_submenu_animation select').val();
         
        // if submenu animation selected on load
        if ( 'none' === $chimmc_submenu_animation_selected_value ) {
            $chimmc_submenu_animation_speed.fadeOut(800);
        } else {
                $chimmc_submenu_animation_speed.fadeIn(800);
        }

        $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chimmc_submenu_animation select', function(){
                $chi_input = $(this);
                // if submenu animation selected on change
                if ( 'none' === $chi_input.val() ) {
                    $chimmc_submenu_animation_speed.fadeOut(800);

                } else {
                        $chimmc_submenu_animation_speed.fadeIn(800);
                }
            });
     }
     
     /* show/hide collapsed submenu options set */
     function show_hide_collapsed_submenu_options_set(){
        /* show/hide collapsed submenu options on load */
        if ($chidmm_collapse_submenu_select.val() == '1'){
            $chimmc_parent_clickable.show();
            $chimmc_toggle_submenus.show();
            $chimmc_submenu_animation.show();
            
            /* show/hide submenu animation speed option */
            show_hide_submenu_animation_speed();
            
            $chimmc_arrow_styles_on.show();

            /* show/hide parent arrow options set */
            show_hide_parent_arrow_options_set();

        } else {
            $chimmc_parent_clickable.hide();
            $chimmc_toggle_submenus.hide();
            $chimmc_submenu_animation.hide();
            $chimmc_submenu_animation_speed.hide();
            $chimmc_arrow_styles_on.hide();
            $chimmc_arrow_options_set.hide();
        }
        /* show/hide collapsed submenu options on change */
        $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chidmm_collapse_submenu select', function(){
             $chi_input = $(this);

            if ( $chi_input.val() == '1' ) {
                $chimmc_parent_clickable.fadeIn(800);
                $chimmc_toggle_submenus.fadeIn(800);
                $chimmc_submenu_animation.fadeIn(800);
            
                /* show/hide submenu animation speed option */
                show_hide_submenu_animation_speed();
            
                $chimmc_arrow_styles_on.fadeIn(800);

                /* show/hide parent arrow options set */
                show_hide_parent_arrow_options_set();

            } else {
                $chimmc_parent_clickable.fadeOut(800);
                $chimmc_toggle_submenus.fadeOut(800);
                $chimmc_submenu_animation.fadeOut(800);
                $chimmc_submenu_animation_speed.fadeOut(800);
                $chimmc_arrow_styles_on.fadeOut(800);
                $chimmc_arrow_options_set.fadeOut(800);
            }

        });
         
     }

     /* show/hide chimmc_sec_menu_items_position option */
     function show_hide_sec_menu_items_position_option(){
         
         var $divi_secondary_menu_value = $('#customize-control-nav_menu_locations-secondary-menu select').val();
         
         // if secondary-menu location has not been assigned a menu (on load)
         if ( '0' === $divi_secondary_menu_value ) {
            $chimmc_sec_menu_items_position.hide();
        } else {
                $chimmc_sec_menu_items_position.show();
        }

        $( '#customize-theme-controls' ).on( 'change', '#customize-control-nav_menu_locations-secondary-menu select', function(){
                $chi_input = $(this);
                // if submenu animation selected on change
                if ( '0' === $chi_input.val() ) {
                    $chimmc_sec_menu_items_position.hide();
                } else {
                        $chimmc_sec_menu_items_position.show();
                }
            });
     }
     
     /* show/hide PRIMARY and MMC Mobile menu items list options */
     function show_hide_primary_and_mob_menu_items_list_options(){
         
         var $divi_primary_menu_value = $('#customize-control-nav_menu_locations-primary-menu select').val(),
             $chimmc_mob_menu_value = $('#customize-control-nav_menu_locations-chimmc-mobile-menu select').val();
             
         
         // if secondary-menu location has not been assigned a menu (on load)
         if ( '0' === $chimmc_mob_menu_value ) {
            $chimmc_mob_menu_items_list.hide();
            $chimmc_menu_items_list.show();
        } else {
                $chimmc_mob_menu_items_list.show();
                $chimmc_menu_items_list.hide();
        }

        $( '#customize-theme-controls' ).on( 'change', '#customize-control-nav_menu_locations-chimmc-mobile-menu select', function(){
            
            var $divi_header_style = $('#customize-control-et_divi-header_style select').val(),
                $chi_input = $(this);
            
                // if submenu animation selected on change
                

                if ( '0' === $chi_input.val() ) {

                    $chimmc_mob_menu_items_list.hide();
                    $chimmc_menu_items_list.show();

                    } else {

                        if('slide' !== $divi_header_style || 'fullscreen' !== $divi_header_style){

                            $chimmc_mob_menu_items_list.show();
                            $chimmc_menu_items_list.hide();

                            } else {

                                $chimmc_mob_menu_items_list.hide();
                                $chimmc_menu_items_list.show();

                            }

                    }
            
            });
     }
     
     /* show/hide options for adding Divi Layouts above and below the menu items */
     function show_hide_pb_layouts_add_above_below_options(){
         
         var $chimmc_add_pb_layouts_value = $('#customize-control-et_divi-chimmc_add_pb_layouts select').val();
         
         // check the selected value of the 'ADD LAYOUTS FROM DIVI LIBRARY' option (on load)
         if ( 'disabled' === $chimmc_add_pb_layouts_value ) {
             
            $chimmc_pb_layouts_add_above.hide();
            $chimmc_pb_layouts_add_below.hide();
             
            } else if ('above' === $chimmc_add_pb_layouts_value){
                
                $chimmc_pb_layouts_add_above.show();
                $chimmc_pb_layouts_add_below.hide();
                
                } else if ('above_below' === $chimmc_add_pb_layouts_value){
                    
                    $chimmc_pb_layouts_add_above.show();
                    $chimmc_pb_layouts_add_below.show();
                    
                    } else {
                        
                        $chimmc_pb_layouts_add_above.hide();
                        $chimmc_pb_layouts_add_below.show();
                        
                        }

        $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chimmc_add_pb_layouts select', function(){
                $chi_input = $(this);
            
                // check the selected value of the 'ADD LAYOUTS FROM DIVI LIBRARY' option (on load)
                 if ( 'disabled' === $chi_input.val() ) {

                    $chimmc_pb_layouts_add_above.fadeOut(800);
                    $chimmc_pb_layouts_add_below.fadeOut(800);

                    } else if ('above' === $chi_input.val()){

                        $chimmc_pb_layouts_add_above.fadeIn(800);
                        $chimmc_pb_layouts_add_below.fadeOut(800);

                        } else if ('above_below' === $chi_input.val()){

                            $chimmc_pb_layouts_add_above.fadeIn(800);
                            $chimmc_pb_layouts_add_below.fadeIn(800);

                            } else {

                                $chimmc_pb_layouts_add_above.fadeOut(800);
                                $chimmc_pb_layouts_add_below.fadeIn(800);

                                }
            
                });
         }


    // if either Fullscreen or Slide In header format is selected 
    if ( 'slide' === $chiHeaderStyleD || 'fullscreen' === $chiHeaderStyleD ) {
        $chidmm_fixed.hide();
        $chidmm_fullwidth.hide();
        $chidmm_collapse_submenu.hide();
        $chidmm_border_color.hide();
        $chidmm_padding.hide();
        $chidmm_letter_spacing.hide();
        $chidmm_font_style.hide();
        $chidmm_trbl_border_width.hide();
        $chidmm_border_radius.hide();
        $chimmc_animations_acc_section.hide();
        $chimmc_animations_sub_acc_section.hide();
        $chimmc_header_text_color.hide();
        $chimmc_menu_bar_format.hide();
        $chimmc_menu_bar_text.hide();
        $chimmc_menu_bar_close_text.hide();
        $chimmc_menu_bar_close_icon.hide();
        $chimmc_menu_bar_text_size.hide();
        $chimmc_menu_bar_icon_size.hide();
        $chimmc_menu_search_icon_size.hide();
        $chimmc_menu_bar_font_style.hide();
        $chimmc_menu_dd_top_offset.hide();
        $chimmc_gradient_clip.hide();
        $chimmc_bg_image_clip.hide();
        $chimmc_search_icon.hide();
        $chimmc_parent_clickable.hide();
        $chimmc_toggle_submenus.hide();
        $chimmc_submenu_animation.hide();
        $chimmc_submenu_animation_speed.hide();
            
        /* prevent from hiding if collapse submenu is disabled */
        $chimmc_arrow_styles_on.show();
        
        /* show/hide parent arrow options set */
        show_hide_parent_arrow_options_set();
        
        $chimmc_sec_menu_items_position.hide();
        $chimmc_menu_items_list.show();
        $chimmc_mob_menu_items_list.hide();
        
        $chimmc_divi_library_layouts_section.hide();
        
    } else {
            $chidmm_fixed.show();
            $chidmm_fullwidth.show();
            $chidmm_collapse_submenu.show();
            $chidmm_border_color.show();
            $chidmm_padding.show();
            $chidmm_letter_spacing.show();
            $chidmm_font_style.show();
            $chidmm_trbl_border_width.show();
            $chidmm_border_radius.show();
            $chimmc_animations_acc_section.show();
            $chimmc_animations_sub_acc_section.show();
            $chimmc_header_text_color.show();
            $chimmc_menu_bar_format.show();
            $chimmc_menu_bar_text.show();
            $chimmc_menu_bar_close_text.show();
            $chimmc_menu_bar_close_icon.show();
            $chimmc_menu_bar_text_size.show();
            $chimmc_menu_bar_icon_size.show();
            $chimmc_menu_search_icon_size.show();
            $chimmc_menu_bar_font_style.show();
            $chimmc_menu_dd_top_offset.show();
            $chimmc_gradient_clip.show();
            $chimmc_bg_image_clip.show();
            $chimmc_search_icon.show();
        
            /* show/hide collapsed submenu options set */
            show_hide_collapsed_submenu_options_set();
            /* show/hide chimmc_sec_menu_items_position option */
            show_hide_sec_menu_items_position_option();
      
        /* show/hide PRIMARY and MMC Mobile menu items list options */
        show_hide_primary_and_mob_menu_items_list_options();
        
        $chimmc_divi_library_layouts_section.show();
        show_hide_pb_layouts_add_above_below_options();      
            
    }
    
    $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-header_style select', function(){
			$chi_input = $(this);

			if ( 'slide' === $chi_input.val() || 'fullscreen' === $chi_input.val() ) {
				$chidmm_fixed.hide();
                $chidmm_fullwidth.hide();
                $chidmm_collapse_submenu.hide();
                $chidmm_border_color.hide();
                $chidmm_padding.hide();
                $chidmm_letter_spacing.hide();
                $chidmm_font_style.hide();
                $chidmm_trbl_border_width.hide();
                $chidmm_border_radius.hide();
                $chimmc_animations_acc_section.hide();
                $chimmc_animations_sub_acc_section.hide();
                $chimmc_header_text_color.hide();
                $chimmc_menu_bar_format.hide();
                $chimmc_menu_bar_text.hide();
                $chimmc_menu_bar_close_text.hide();
                $chimmc_menu_bar_close_icon.hide();
                $chimmc_menu_bar_text_size.hide();
                $chimmc_menu_bar_icon_size.hide();
                $chimmc_menu_search_icon_size.hide();
                $chimmc_menu_bar_font_style.hide();
                $chimmc_menu_dd_top_offset.hide();
                $chimmc_gradient_clip.hide();
                $chimmc_bg_image_clip.hide();
                $chimmc_search_icon.hide();
                $chimmc_parent_clickable.hide();
                $chimmc_toggle_submenus.hide();
                $chimmc_submenu_animation.hide();
                $chimmc_submenu_animation_speed.hide();
            
                /* prevent from hiding if collapse submenu is disabled */
                $chimmc_arrow_styles_on.show();
                
                /* show/hide parent arrow options set */
                show_hide_parent_arrow_options_set();
                
                $chimmc_sec_menu_items_position.hide();
                $chimmc_menu_items_list.show();        
                $chimmc_mob_menu_items_list.hide();    
                $chimmc_divi_library_layouts_section.hide();

			} else {
                    $chidmm_fixed.show();
                    $chidmm_fullwidth.show();
                    $chidmm_collapse_submenu.show();
                    $chidmm_border_color.show();
                    $chidmm_padding.show();
                    $chidmm_letter_spacing.show();
                    $chidmm_font_style.show();
                    $chidmm_trbl_border_width.show();
                    $chidmm_border_radius.show();
                    $chimmc_animations_acc_section.show();
                    $chimmc_animations_sub_acc_section.show();
                    $chimmc_header_text_color.show();
                    $chimmc_menu_bar_format.show();
                    $chimmc_menu_bar_text.show();
                    $chimmc_menu_bar_close_text.show();
                    $chimmc_menu_bar_close_icon.show();
                    $chimmc_menu_bar_text_size.show();
                    $chimmc_menu_bar_icon_size.show();
                    $chimmc_menu_search_icon_size.show();
                    $chimmc_menu_bar_font_style.show();
                    $chimmc_menu_dd_top_offset.show();
                    $chimmc_gradient_clip.show();
                    $chimmc_bg_image_clip.show();
                    $chimmc_search_icon.show();
                
                    /* show/hide collapsed submenu options set */
                    show_hide_collapsed_submenu_options_set();
                    /* show/hide chimmc_sec_menu_items_position option */
                    show_hide_sec_menu_items_position_option();
      
                    /* show/hide PRIMARY and MMC Mobile menu items list options */
                    show_hide_primary_and_mob_menu_items_list_options();

                    $chimmc_divi_library_layouts_section.show();
                    show_hide_pb_layouts_add_above_below_options()
        
			}
		});
    // if Fullscreen header format selected 
    if ( 'fullscreen' === $chiHeaderStyleD ) {
        $chidmm_text_align.hide();
        $chidmm_item_bg_color.hide();
        $chidmm_current_item_bg_color.hide();
        $chidmm_item_border_color.hide();
        $chidmm_item_trbl_border_width.hide();
        $chidmm_submenu_bg_color.hide();
        $chidmm_item_border_radius.hide();
        $chi_DMM_Mobile_Menu_shadows.hide();
        $chimmc_align_icons_left.hide();
        $chimmc_align_icons_right.hide();
    } else {
            $chidmm_text_align.show();
            $chidmm_item_bg_color.show();
            $chidmm_current_item_bg_color.show();
            $chidmm_item_border_color.show();
            $chidmm_item_trbl_border_width.show();
            $chidmm_submenu_bg_color.show();
            $chidmm_item_border_radius.show();
            $chi_DMM_Mobile_Menu_shadows.show();
            $chimmc_align_icons_left.show();
            $chimmc_align_icons_right.show();
    }
    
    $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-header_style select', function(){
			$chi_input = $(this);

			if ( 'fullscreen' === $chi_input.val() ) {
                $chidmm_text_align.hide();
                $chidmm_item_bg_color.hide();
                $chidmm_current_item_bg_color.hide();
                $chidmm_item_border_color.hide();
                $chidmm_item_trbl_border_width.hide();
                $chidmm_submenu_bg_color.hide();
                $chidmm_item_border_radius.hide();
                $chi_DMM_Mobile_Menu_shadows.hide();
                $chimmc_align_icons_left.hide();
                $chimmc_align_icons_right.hide();

			} else {
                    $chidmm_text_align.show();
                    $chidmm_item_bg_color.show();
                    $chidmm_current_item_bg_color.show();
                    $chidmm_item_border_color.show();
                    $chidmm_item_trbl_border_width.show();
                    $chidmm_submenu_bg_color.show();
                    $chidmm_item_border_radius.show();
                    $chi_DMM_Mobile_Menu_shadows.show();
                    $chimmc_align_icons_left.show();
                    $chimmc_align_icons_right.show();
			}
		}); 
    // if Slide-In header format selected 
    if ( 'slide' === $chiHeaderStyleD ) {
        $chidmm_padding_slide.show();
    } else {
            $chidmm_padding_slide.hide();
    }
    
    $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-header_style select', function(){
			$chi_input = $(this);

			if ( 'slide' === $chi_input.val() ) {
                $chidmm_padding_slide.show();

			} else {
                    $chidmm_padding_slide.hide();
			}
		});
    // if Slide-In or Fullscreen header formats or fixed menu selected - v1.1 
    if ( 'slide' === $chiHeaderStyleD || 'fullscreen' === $chiHeaderStyleD || 'absolute' === $chimmcFixedMenu ) {
        $chidmm_fixed_menu_height.fadeOut(800);
        $chidmm_fixed_scrollable.fadeOut(800);
    } else {
            $chidmm_fixed_menu_height.fadeIn(800);
            $chidmm_fixed_scrollable.fadeIn(800);
    }
    
    $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chidmm_fixed select', function(){
			$chi_input = $(this);

			if ( 'absolute' === $chi_input.val() ) {
                $chidmm_fixed_menu_height.fadeOut(800);
                $chidmm_fixed_scrollable.fadeOut(800);

			} else {
                    $chidmm_fixed_menu_height.fadeIn(800);
                    $chidmm_fixed_scrollable.fadeIn(800);
			}
		});
     $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-header_style select', function(){
			$chi_input = $(this);

			if ( 'slide' === $chi_input.val() || 'fullscreen' === $chi_input.val() ) {
                $chidmm_fixed_menu_height.fadeOut(800);
                $chidmm_fixed_scrollable.fadeOut(800);

			} else {
                    $chidmm_fixed_menu_height.fadeIn(800);
                    $chidmm_fixed_scrollable.fadeIn(800);
			}
		});
     
     // if Slide-In or Fullscreen header formats or fullwidth menu enabled 
    if ( 'slide' === $chiHeaderStyleD || 'fullscreen' === $chiHeaderStyleD || 'relative' === $chimmcFullwidthMenu ) {
        $chidmm_fullwidth_phone.fadeOut(800);
        $chidmm_fullwidth_tablet.fadeOut(800);
    } else {
            $chidmm_fullwidth_phone.fadeIn(800);
            $chidmm_fullwidth_tablet.fadeIn(800);
    }
    
    $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chidmm_fullwidth select', function(){
			$chi_input = $(this);

			if ( 'relative' === $chi_input.val() ) {
                $chidmm_fullwidth_phone.fadeOut(800);
                $chidmm_fullwidth_tablet.fadeOut(800);

			} else {
                    $chidmm_fullwidth_phone.fadeIn(800);
                    $chidmm_fullwidth_tablet.fadeIn(800);
			}
		});
     $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-header_style select', function(){
			$chi_input = $(this);

			if ( 'slide' === $chi_input.val() || 'fullscreen' === $chi_input.val() ) {
                $chidmm_fullwidth_phone.fadeOut(800);
                $chidmm_fullwidth_tablet.fadeOut(800);

			} else {
                    $chidmm_fullwidth_phone.fadeIn(800);
                    $chidmm_fullwidth_tablet.fadeIn(800);
			}
		});
     
     // if Menu Header selected 
    if ( 'menuHeader' === $chimmcElementGradient ) {
        $chimmc_menu_gradient_on_off.hide();
        $chimmc_menu_gradient_stop1_color.hide();
        $chimmc_menu_gradient_stop1_location.hide();
        $chimmc_menu_gradient_stop2_color.hide();
        $chimmc_menu_gradient_stop2_location.hide();
        $chimmc_menu_gradient_stop3_color.hide();
        $chimmc_menu_gradient_stop3_location.hide();
        $chimmc_menu_gradient_angle.hide();
        $chimmc_gradient_clip.hide();
            $chimmc_header_gradient_on_off.show();
            $chimmc_header_gradient_stop1_color.show();
            $chimmc_header_gradient_stop1_location.show();
            $chimmc_header_gradient_stop2_color.show();
            $chimmc_header_gradient_stop2_location.show();
            $chimmc_header_gradient_stop3_color.show();
            $chimmc_header_gradient_stop3_location.show();
            $chimmc_header_gradient_angle.show();
    } else { 
            $chimmc_menu_gradient_on_off.show();
            $chimmc_menu_gradient_stop1_color.show();
            $chimmc_menu_gradient_stop1_location.show();
            $chimmc_menu_gradient_stop2_color.show();
            $chimmc_menu_gradient_stop2_location.show();
            $chimmc_menu_gradient_stop3_color.show();
            $chimmc_menu_gradient_stop3_location.show();
            $chimmc_menu_gradient_angle.show();
            $chimmc_gradient_clip.show();
                $chimmc_header_gradient_on_off.hide();
                $chimmc_header_gradient_stop1_color.hide();
                $chimmc_header_gradient_stop1_location.hide();
                $chimmc_header_gradient_stop2_color.hide();
                $chimmc_header_gradient_stop2_location.hide();
                $chimmc_header_gradient_stop3_color.hide();
                $chimmc_header_gradient_stop3_location.hide();
                $chimmc_header_gradient_angle.hide();       
            }
    
    $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chimmc_element_with_gradient select', function(){
			$chi_input = $(this);

			if ( 'menuHeader' === $chi_input.val() ) {
                $chimmc_menu_gradient_on_off.hide();
                $chimmc_menu_gradient_stop1_color.hide();
                $chimmc_menu_gradient_stop1_location.hide();
                $chimmc_menu_gradient_stop2_color.hide();
                $chimmc_menu_gradient_stop2_location.hide();
                $chimmc_menu_gradient_stop3_color.hide();
                $chimmc_menu_gradient_stop3_location.hide();
                $chimmc_menu_gradient_angle.hide();
                $chimmc_gradient_clip.hide();
                    $chimmc_header_gradient_on_off.show();
                    $chimmc_header_gradient_stop1_color.show();
                    $chimmc_header_gradient_stop1_location.show();
                    $chimmc_header_gradient_stop2_color.show();
                    $chimmc_header_gradient_stop2_location.show();
                    $chimmc_header_gradient_stop3_color.show();
                    $chimmc_header_gradient_stop3_location.show();
                    $chimmc_header_gradient_angle.show();

			} else {
                    $chimmc_menu_gradient_on_off.show();
                    $chimmc_menu_gradient_stop1_color.show();
                    $chimmc_menu_gradient_stop1_location.show();
                    $chimmc_menu_gradient_stop2_color.show();
                    $chimmc_menu_gradient_stop2_location.show();
                    $chimmc_menu_gradient_stop3_color.show();
                    $chimmc_menu_gradient_stop3_location.show();
                    $chimmc_menu_gradient_angle.show();
                    $chimmc_gradient_clip.show();
                        $chimmc_header_gradient_on_off.hide();
                        $chimmc_header_gradient_stop1_color.hide();
                        $chimmc_header_gradient_stop1_location.hide();
                        $chimmc_header_gradient_stop2_color.hide();
                        $chimmc_header_gradient_stop2_location.hide();
                        $chimmc_header_gradient_stop3_color.hide();
                        $chimmc_header_gradient_stop3_location.hide();
                        $chimmc_header_gradient_angle.hide();
			     }
		});
     
    // if either Centered or Centered Inline Logo header format is selected 
    if ( 'centered' === $chiHeaderStyleD || 'split' === $chiHeaderStyleD ) {
        $chimmc_menu_bar_bg_color.show();
        
    } else {
            $chimmc_menu_bar_bg_color.hide();
            
    }
    
    $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-header_style select', function(){
			$chi_input = $(this);

			if ( 'centered' === $chi_input.val() || 'split' === $chi_input.val() ) {
				$chimmc_menu_bar_bg_color.show();               

			} else {
                    $chimmc_menu_bar_bg_color.hide();
                
			}
		});    
    
    
    /**
     * menu header gradient enabled/disabled control
     */
    if ( 'enabled' === $chiMMCheaderGradientEnabled ) {
        
        $chimmc_header_gradient_on_off.addClass('chimmc_feature_enabled').removeClass('chimmc_feature_disabled');

    } else {
        
            $chimmc_header_gradient_on_off.removeClass('chimmc_feature_enabled').addClass('chimmc_feature_disabled');

        }

    $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chimmc_header_gradient_on_off select', function(){
            $chi_input = $(this);

            if ( 'enabled' === $chi_input.val() ) {
                
                $chimmc_header_gradient_on_off.addClass('chimmc_feature_enabled').removeClass('chimmc_feature_disabled');

            } else {
                
                $chimmc_header_gradient_on_off.removeClass('chimmc_feature_enabled').addClass('chimmc_feature_disabled');

            }
        });
     
     
    /**
     * menu gradient enabled/disabled control
     */
    if ( 'enabled' === $chiMMCmenuGradientEnabled ) {
        
        $chimmc_menu_gradient_on_off.addClass('chimmc_feature_enabled').removeClass('chimmc_feature_disabled');

    } else {
        
            $chimmc_menu_gradient_on_off.removeClass('chimmc_feature_enabled').addClass('chimmc_feature_disabled');

        }

    $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chimmc_menu_gradient_on_off select', function(){
            $chi_input = $(this);

            if ( 'enabled' === $chi_input.val() ) {
                
                $chimmc_menu_gradient_on_off.addClass('chimmc_feature_enabled').removeClass('chimmc_feature_disabled');

            } else {
                
                $chimmc_menu_gradient_on_off.removeClass('chimmc_feature_enabled').addClass('chimmc_feature_disabled');

            }
        });
     
     /**
     * menu bg image enabled/disabled control
     */
    if ( 'enabled' === $chiMMCbgImageEnabled ) {
        
        $chimmc_bg_image_on_off.addClass('chimmc_feature_enabled').removeClass('chimmc_feature_disabled');

    } else {
        
            $chimmc_bg_image_on_off.removeClass('chimmc_feature_enabled').addClass('chimmc_feature_disabled');

        }

    $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chimmc_bg_image_on_off select', function(){
            $chi_input = $(this);

            if ( 'enabled' === $chi_input.val() ) {
                
                $chimmc_bg_image_on_off.addClass('chimmc_feature_enabled').removeClass('chimmc_feature_disabled');

            } else {
                
                $chimmc_bg_image_on_off.removeClass('chimmc_feature_enabled').addClass('chimmc_feature_disabled');

            }
        }); 
     
    /**
     * menu icons enabled/disabled control
     */
    if ( 'enabled' === $chiMMCiconsEnabled ) {
        
        $chimmc_icons_on_off.addClass('chimmc_feature_enabled').removeClass('chimmc_feature_disabled');

    } else {
        
            $chimmc_icons_on_off.removeClass('chimmc_feature_enabled').addClass('chimmc_feature_disabled');

        }

    $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chimmc_icons_on_off select', function(){
            $chi_input = $(this);

            if ( 'enabled' === $chi_input.val() ) {
                
                $chimmc_icons_on_off.addClass('chimmc_feature_enabled').removeClass('chimmc_feature_disabled');

            } else {
                
                $chimmc_icons_on_off.removeClass('chimmc_feature_enabled').addClass('chimmc_feature_disabled');

            }
        });               
                
    // menu icons alignment controls 
    if ( $chiMMCiconsAlign == 'before' ) {

        $chimmc_align_icons_left.show();
        $chimmc_align_icons_right.hide();

    } else {
        
            $chimmc_align_icons_left.hide();
            $chimmc_align_icons_right.show();

        } 

    $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chimmc_icons_position select', function(){
            $chi_input = $(this);

            if ( $chi_input.val() == 'before' ) {

                $chimmc_align_icons_left.show();
                $chimmc_align_icons_right.hide();

            } else {

                    $chimmc_align_icons_left.hide();
                    $chimmc_align_icons_right.show();

                } 
            });

    
    /**
     * Show/Hide menu items icon picker controls 
     */
    // show saved primary menu item and hide the rest on load
    var $chimmc_selected_menu_item = $('#customize-control-et_divi-chimmc_menu_items_list select').val();

    $('li[id^="customize-control-et_divi-chimmc_menu_icon_"]').not('#customize-control-et_divi-chimmc_menu_icon_' + $chimmc_selected_menu_item + '').addClass('hide_icon_picker').removeClass('show_icon_picker');

    $('#customize-control-et_divi-chimmc_menu_icon_' + $chimmc_selected_menu_item + '').addClass('show_icon_picker').removeClass('hide_icon_picker');

    // loop through primary menu items 
    $('#customize-control-et_divi-chimmc_menu_items_list select > option').each(function( ) {

        // update menu item icon
        //console.log( 'chimmc_menu_icon_' + this.value + '' );

        // show selected primary menu item icon picker and hide the rest on change
        $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chimmc_menu_items_list select', function(){
                $chi_input = $(this);

                if ( $chi_input.val() == '' + this.value + '' ) {

                    $('#customize-control-et_divi-chimmc_menu_icon_' + this.value + '').addClass('show_icon_picker').removeClass('hide_icon_picker');
                    $('li[id^="customize-control-et_divi-chimmc_menu_icon_"]').not('#customize-control-et_divi-chimmc_menu_icon_' + this.value + '').addClass('hide_icon_picker').removeClass('show_icon_picker');

                } else {

                    $('li[id^="customize-control-et_divi-chimmc_menu_icon_"]').addClass('hide_icon_picker').removeClass('show_icon_picker');

                    } 
                });

    });
     
     // show saved MMC mobile menu item and hide the rest on load
     var $chimmc_selected_menu_item = $('#customize-control-et_divi-chimmc_mob_menu_items_list select').val();

        $('li[id^="customize-control-et_divi-chimmc_menu_icon_"]').not('#customize-control-et_divi-chimmc_menu_icon_' + $chimmc_selected_menu_item + '').addClass('hide_icon_picker').removeClass('show_icon_picker');

        $('#customize-control-et_divi-chimmc_menu_icon_' + $chimmc_selected_menu_item + '').addClass('show_icon_picker').removeClass('hide_icon_picker');

        // loop through primary menu items 
        $('#customize-control-et_divi-chimmc_mob_menu_items_list select > option').each(function( ) {

            // show selected primary menu item icon picker and hide the rest on change
            $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chimmc_mob_menu_items_list select', function(){
                    $chi_input = $(this);

                    if ( $chi_input.val() == '' + this.value + '' ) {

                        $('#customize-control-et_divi-chimmc_menu_icon_' + this.value + '').addClass('show_icon_picker').removeClass('hide_icon_picker');
                        $('li[id^="customize-control-et_divi-chimmc_menu_icon_"]').not('#customize-control-et_divi-chimmc_menu_icon_' + this.value + '').addClass('hide_icon_picker').removeClass('show_icon_picker');

                    } else {

                        $('li[id^="customize-control-et_divi-chimmc_menu_icon_"]').addClass('hide_icon_picker').removeClass('show_icon_picker');

                        } 
                });

        });

    // show saved secondary menu item and hide the rest on load
    var $chimmc_selected_menu_item = $('#customize-control-et_divi-chimmc_sec_menu_items_list select').val();

    $('li[id^="customize-control-et_divi-chimmc_menu_icon_"]').not('#customize-control-et_divi-chimmc_menu_icon_' + $chimmc_selected_menu_item + '').addClass('hide_icon_picker').removeClass('show_icon_picker');

    $('#customize-control-et_divi-chimmc_menu_icon_' + $chimmc_selected_menu_item + '').addClass('show_icon_picker').removeClass('hide_icon_picker');

    // loop through secondary menu items 
    $('#customize-control-et_divi-chimmc_sec_menu_items_list select > option').each(function( ) {

        // show selected secondary menu item icon picker and hide the rest on change
        $( '#customize-theme-controls' ).on( 'change', '#customize-control-et_divi-chimmc_sec_menu_items_list select', function(){
                $chi_input = $(this);

                if ( $chi_input.val() == '' + this.value + '' ) {

                    $('#customize-control-et_divi-chimmc_menu_icon_' + this.value + '').addClass('show_icon_picker').removeClass('hide_icon_picker');
                    $('li[id^="customize-control-et_divi-chimmc_menu_icon_"]').not('#customize-control-et_divi-chimmc_menu_icon_' + this.value + '').addClass('hide_icon_picker').removeClass('show_icon_picker');

                } else {

                    $('li[id^="customize-control-et_divi-chimmc_menu_icon_"]').addClass('hide_icon_picker').removeClass('show_icon_picker');

                    } 
                });

    });
     
     // hide all icon pickers on menu and header format changes
    $( '#customize-theme-controls' ).on( 'change', '#customize-control-nav_menu_locations-secondary-menu select,\
                                        #customize-control-nav_menu_locations-primary-menu select,\
                                        #customize-control-nav_menu_locations-chimmc-mobile-menu select,\
                                        #customize-control-et_divi-header_style select', function(){
        
        $('li[id^="customize-control-et_divi-chimmc_menu_icon_"]').addClass('hide_icon_picker').removeClass('show_icon_picker');

    });
     
    // END showing/hiding menu items icon picker controls
     
     
    });
    
    /**
     * icon picker control "Remove icon" option
     */
      
    $(function() {      
        $('.chimmc_icon_picker_control ul.et_font_icon > li:first-child').wrap('<div class="chimmc_remove_icon_wrapper"></div>');     
        $('.chimmc_icon_picker_control ul.et_font_icon .chimmc_remove_icon_wrapper').append('<span class="chimmc_remove_icon_text">Remove icon</span>'); 
    });
    
} )( jQuery );