
(function ($) {
    
/**
 * Theme Customizer live preview
 */
    function et_customizer_update_styles( style_id, $style_content ) {
    // Update customizer live preview
            if ( $( style_id ).length ) {
                if ( '' !== $style_content ) {
                    $( style_id ).replaceWith( $style_content );
                } else {
                    $( style_id ).remove();
                }
            } else {
                $( 'head' ).append( $style_content );
            }
        }

/**
 * Collapse nested mobile menu submenu items
 */
    function chi_dmm_collapse_submenus() {
        
        // add chidmm_collapsable class to submenu
        $('.chi_dmm_styles .chi_mmc_activated #mobile_menu').addClass('chidmm_collapsable');
         
        var $menu = $('.chi_dmm_styles .chi_mmc_activated #mobile_menu.chidmm_collapsable'),
            top_level_link = '.chi_dmm_styles .chi_mmc_activated #mobile_menu.chidmm_collapsable .menu-item-has-children > a';

        $menu.find('a').each(function() {
            $(this).off('click');

            if ( $(this).is(top_level_link) ) {
                $(this).attr('href', '#');
            }

            if ( ! $(this).siblings('.sub-menu').length ) {
                $(this).on('click', function(event) {
                    $(this).parents('.mobile_nav').trigger('click');
                });
            } else {
                $(this).on('click', function(event) {
                    event.preventDefault();
                    
                    var this_parent_siblings = $(this).parent().siblings('li.menu-item-has-children');
                    
                    // if submenu accordion is enabled
                    if ($('body').hasClass('chimmc_toggle_submenus')){
                        
                        // close other opened submenus of the same submenu level if a new one is opened
                        this_parent_siblings.removeClass('visible').addClass('hidden_sub');
                        
                    }
                    
                    // toggle current submenu
                    $(this).parent().removeClass('hidden_sub').toggleClass('visible');   
                    
                });
            }
        });
    }

    $(window).load(function() {
        setTimeout(function() {
            chi_dmm_collapse_submenus();
        }, 700);
    });
/** End Collapse nested mobile menu submenu items **/

/**
 * Insert custom font styling
 */
	function chidmm_set_font_styles( value, important_tag ) {
		var font_styles = value.split( '|' ),
			style = '';

		if ( $.inArray( 'bold', font_styles ) >= 0 ) {
			style += "font-weight: bold " + important_tag + ";";
		} else {
			style += "font-weight: normal " + important_tag + ";";
		}

		if ( $.inArray( 'italic', font_styles ) >= 0 ) {
			style += "font-style: italic " + important_tag + ";";
		} else {
			style += "font-style: inherit " + important_tag + ";";
		}

		if ( $.inArray( 'underline', font_styles ) >= 0 ) {
			style += "text-decoration: underline " + important_tag + ";";
		} else {
			style += "text-decoration: inherit " + important_tag + ";";
		}

		if ( $.inArray( 'uppercase', font_styles ) >= 0 ) {
			style += "text-transform: uppercase " + important_tag + ";";
		} else {
			style += "text-transform: inherit " + important_tag + ";";
		}

		return style;
	}    
/** END Inserting custom font styling **/

	//Update mobile menu items font size
	wp.customize( 'et_divi[chidmm_font_size]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_font_size">@media all and (max-width: 980px) {body.chi_dmm_styles #et-top-navigation .mobile_nav ul#mobile_menu.et_mobile_menu > li > a {font-size: ' + newval + 'px !important;} body.chi_dmm_styles ul#mobile_menu_slide.et_mobile_menu > li > a {font-size: ' + newval + 'px !important;}} </style>',
				style_id = 'style#chidmm_font_size';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
	//Update mobile menu fixed state
	wp.customize( 'et_divi[chidmm_fixed]', function( value ) {
		value.bind( function( newval ) {
            
            if( newval == 'fixed' ){ 
                    $('.chi_dmm_styles .chi_mmc_activated #mobile_menu').addClass('chi_mmc_fixed_menu'); 
                    } else {
                        $('.chi_dmm_styles .chi_mmc_activated #mobile_menu').removeClass('chi_mmc_fixed_menu');
                    }
            
            if ( newval == 'fixed' ){
			var $style_content = '<style id="chidmm_fixed">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles #main-header.chi_mmc_activated, body.chi_dmm_styles #top-header  {position: ' + newval + ' !important;}body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated #mobile_menu { overflow-y: scroll !important; -ms-overflow-style: -ms-autohiding-scrollbar; } .chi_dmm_styles .chi_mmc_activated #mobile_menu::-webkit-scrollbar { width: 10px; height: 3px;}.chi_dmm_styles .chi_mmc_activated #mobile_menu::-webkit-scrollbar-button { background-color: rgba(0,0,0,0.3); }.chi_dmm_styles .chi_mmc_activated #mobile_menu::-webkit-scrollbar-track {  background-color: rgba(0,0,0,0.1);}.chi_dmm_styles .chi_mmc_activated #mobile_menu::-webkit-scrollbar-track-piece { background-color: rgba(0,0,0,0.1);}.chi_dmm_styles .chi_mmc_activated #mobile_menu::-webkit-scrollbar-thumb { height: 30px; background-color: rgba(0,0,0,0.3); border-radius: 0px;}.chi_dmm_styles .chi_mmc_activated #mobile_menu::-webkit-scrollbar-corner { background-color: rgba(0,0,0,0.7);}.chi_dmm_styles .chi_mmc_activated #mobile_menu::-webkit-resizer { background-color: rgba(0,0,0,0.9);}.chi_dmm_styles .chi_mmc_activated #mobile_menu {  scrollbar-base-color: rgba(0,0,0,0.2); scrollbar-highlight-color: rgba(0,0,0,0.3); scrollbar-track-color: rgba(0,0,0,0.1); scrollbar-arrow-color: rgba(0,0,0,0.1); } }</style>';} else {
                var $style_content = '<style id="chidmm_fixed">@media all and (max-width: 980px) { body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles  #main-header.chi_mmc_activated, body.chi_dmm_styles #top-header  {position: ' + newval + ' !important;}body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated #mobile_menu { overflow-y: hidden !important; max-height: none !important; -ms-overflow-style: initial; }}</style>';}
				style_id = 'style#chidmm_fixed';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update fixed mobile menu height - since v1.1
	wp.customize( 'et_divi[chidmm_fixed_menu_height]', function( value ) {
		value.bind( function( newval ) {     
			var $style_content = '<style id="chidmm_fixed_menu_height">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated #mobile_menu.chi_mmc_fixed_menu {max-height: ' + newval + 'vh !important;}} </style>',
				style_id = 'style#chidmm_fixed_menu_height';	
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    // make fixed dropdown menu scrollable
	wp.customize( 'et_divi[chidmm_fixed_scrollable]', function( value ) {
		value.bind( function( newval ) { 
            
            var fixed_menu_overflow_y = (true === newval)? 'scroll' : 'hidden';
            
			var $style_content = '<style id="chidmm_fixed_scrollable">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated #mobile_menu.chi_mmc_fixed_menu {overflow-y: ' + fixed_menu_overflow_y + ' !important;}} </style>',
				style_id = 'style#chidmm_fixed_scrollable';	
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
	
	//Update mobile menu fullwidth state
    function chimmc_fullwidth_menu_preview(setting){ 
        
        wp.customize( 'et_divi['+setting+']', function( value ) {
            value.bind( function( newval ) {
                
            var chimmc_fullwidth_menu_on_media = '',
                chimmc_fullwidth_menu_off_media = '',
                chidmm_fullwidth = wp.customize('et_divi[chidmm_fullwidth]').get(),
                fullwidth_phone = wp.customize('et_divi[chidmm_fullwidth_phone]').get(),
                fullwidth_tablet = wp.customize('et_divi[chidmm_fullwidth_tablet]').get();


            if (chidmm_fullwidth == 'initial' && (true === fullwidth_phone || true === fullwidth_tablet)) {
                
                if (true === fullwidth_phone && true === fullwidth_tablet) {
                    // if fullwidth enabled for both tablet and phone
                    chimmc_fullwidth_menu_on_media = '(max-width: 980px)';
                    chimmc_fullwidth_menu_off_media = '(max-width: 0px)';
                } else if (true === fullwidth_phone && false === fullwidth_tablet) {
                    // if fullwidth enabled for phone only
                    chimmc_fullwidth_menu_on_media = '(max-width: 479px)';
                    chimmc_fullwidth_menu_off_media = '(max-width: 980px) and (min-width: 480px)';
                } else if (false === fullwidth_phone && true === fullwidth_tablet) {
                    // if fullwidth enabled for tablet only
                    chimmc_fullwidth_menu_on_media = '(max-width: 980px) and (min-width: 480px)';
                    chimmc_fullwidth_menu_off_media = '(max-width: 479px)';
                } else if (false === fullwidth_phone && false === fullwidth_tablet) {
                    // if both phone and tablet fullwidth checkboxes unchecked(why would you need that?)
                    chimmc_fullwidth_menu_on_media = '(max-width: 0px)';
                    chimmc_fullwidth_menu_off_media = '(max-width: 0px)';
                }

                var $style_content = '<style id="chidmm_fullwidth"> @media all and '+chimmc_fullwidth_menu_on_media+' {    body.chi_dmm_styles .container.et_menu_container {position: ' + chidmm_fullwidth + ' !important;} body.chi_dmm_styles.et_header_style_centered .chi_mmc_activated #mobile_menu.et_mobile_menu { width: 125% !important; left: -12.5% !important;} body.chi_dmm_styles.et_header_style_split .chi_mmc_activated #mobile_menu.et_mobile_menu { width: 125% !important; left: -12.5% !important;} body.chi_dmm_styles.et_header_style_left .logo_container{width: 90%;}}\
                @media all and '+chimmc_fullwidth_menu_off_media+' { body.chi_dmm_styles .container.et_menu_container {position: relative !important;}body.chi_dmm_styles.et_header_style_centered .chi_mmc_activated #mobile_menu.et_mobile_menu { width: 100% !important; left: 0 !important;} body.chi_dmm_styles.et_header_style_split .chi_mmc_activated #mobile_menu.et_mobile_menu { width: 100% !important; left: 0 !important;}}\
                </style>',
                    style_id = 'style#chidmm_fullwidth'; 
                } else {
                     var $style_content = '<style id="chidmm_fullwidth"> @media all and (max-width: 980px) { body.chi_dmm_styles .container.et_menu_container {position: relative !important;}body.chi_dmm_styles.et_header_style_centered .chi_mmc_activated #mobile_menu.et_mobile_menu { width: 100% !important; left: 0 !important;} body.chi_dmm_styles.et_header_style_split .chi_mmc_activated #mobile_menu.et_mobile_menu { width: 100% !important; left: 0 !important;}}</style>',
                    style_id = 'style#chidmm_fullwidth';   
                    }

                et_customizer_update_styles( style_id, $style_content );
               } );
        } );
        
    }
    
    // fullwidth menu enabled/disabled
    chimmc_fullwidth_menu_preview('chidmm_fullwidth');
    // fullwidth menu enabled/disabled on phone
    chimmc_fullwidth_menu_preview('chidmm_fullwidth_phone');
    // fullwidth menu enabled/disabled on tablet
    chimmc_fullwidth_menu_preview('chidmm_fullwidth_tablet');
    
    
   // Add class for collapsing submenu
    wp.customize( 'et_divi[chidmm_collapse_submenu]', function( value ) {
        value.bind( function( newval ) {
        if( newval == 1 ){ 

            $('.chi_dmm_styles #mobile_menu').addClass('chidmm_collapsable');
            
            if( !$('.chimmc_mobile_menu_arrow').length ){ 

                // append arrow to parent menu item
                $('.chi_dmm_styles:not(.et_header_style_slide):not(.et_header_style_fullscreen) .chidmm_collapsable.et_mobile_menu li.menu-item-has-children > a').append('<span class="chimmc_mobile_menu_arrow"></span>'); 
                }

            } else {

                $('.chi_dmm_styles #mobile_menu').removeClass('chidmm_collapsable');
                
                // remove arrow from parent menu item
                $('.chi_dmm_styles:not(.et_header_style_slide):not(.et_header_style_fullscreen) .et_mobile_menu li.menu-item-has-children > a').children('span').remove();

            }
    
           } );
    } );
    //Update mobile menu border color
	wp.customize( 'et_divi[chidmm_border_color]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_border_color">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu {border-color: ' + newval + ' !important;}} </style>',
				style_id = 'style#chidmm_border_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu item bg color
	wp.customize( 'et_divi[chidmm_item_bg_color]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_item_bg_color">@media all and (max-width: 980px) {body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not([class^="et_pb_"]),body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not([class^="et_pb_"]) {background-color: ' + newval + ' !important;}} </style>',
				style_id = 'style#chidmm_item_bg_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu current item bg color
	wp.customize( 'et_divi[chidmm_current_item_bg_color]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_current_item_bg_color">@media all and (max-width: 980px) {body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button).current-menu-item, body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button).current-menu-parent, body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button).current-menu-ancestor,body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not(.CTA-button).current-menu-item, body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not(.CTA-button).current-menu-parent, body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not(.CTA-button).current-menu-ancestor  {background-color: ' + newval + ' !important;}} </style>',
				style_id = 'style#chidmm_current_item_bg_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu background color
	wp.customize( 'et_divi[chidmm_bg_color]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_bg_color">@media all and (max-width: 980px) { body.chi_dmm_styles.et_header_style_slide #page-container .et_slide_in_menu_container, body.chi_dmm_styles.et_header_style_slide #main-header .nav li ul, body.chi_dmm_styles.et_header_style_slide .et-search-form, body.chi_dmm_styles.et_header_style_fullscreen #page-container .et_slide_in_menu_container {background-color: ' + newval + ' !important;} body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu { background-color: ' + newval + ' !important;} }</style>',
				style_id = 'style#chidmm_bg_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu main header background color
	wp.customize( 'et_divi[chidmm_header_bg_color]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_header_bg_color">@media all and (max-width: 980px) {body.chi_dmm_styles #main-header.chi_mmc_activated, body.chi_dmm_styles.et_header_style_slide #main-header  {background-color: ' + newval + ' !important;}} </style>',
				style_id = 'style#chidmm_header_bg_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu top header background color
	wp.customize( 'et_divi[chidmm_top_header_bg_color]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_top_header_bg_color">@media all and (max-width: 980px) {body.chi_dmm_styles #top-header, body.chi_dmm_styles .et_slide_menu_top {background-color: ' + newval + ' !important;}} </style>',
				style_id = 'style#chidmm_top_header_bg_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu item border color
	wp.customize( 'et_divi[chidmm_item_border_color]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_item_border_color">@media all and (max-width: 980px) {body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button), body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not([class^="et_pb_"]) {border-color: ' + newval + ' !important;}} </style>',
				style_id = 'style#chidmm_item_border_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu link color
	wp.customize( 'et_divi[chidmm_link_color]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_link_color">@media all and (max-width: 980px) { body.chi_dmm_styles .chi_mmc_activated .et_mobile_menu > li:not([class^="et_pb_"]) > a, .et_header_style_slide #mobile_menu_slide > li:not([class^="et_pb_"]) > a, .et_header_style_slide #mobile_menu_slide > li:not(.CTA-button) > a > span.et_mobile_menu_arrow:before, .et_header_style_fullscreen .et_slide_in_menu_container #mobile_menu_slide > li:not([class^="et_pb_"]) > a, .et_header_style_fullscreen .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button) > a > span.et_mobile_menu_arrow:before {color: ' + newval + ' !important;}} </style>',
				style_id = 'style#chidmm_link_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu current link color
	wp.customize( 'et_divi[chidmm_active_link_color]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_active_link_color">@media all and (max-width: 980px) {body.chi_dmm_styles .chi_mmc_activated .et_mobile_menu > li:not(.CTA-button).current-menu-item > a, .et_header_style_slide .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-item > a, .et_header_style_slide .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-item > a > span.et_mobile_menu_arrow:before, body.chi_dmm_styles.et_header_style_fullscreen .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-item > a, body.chi_dmm_styles.et_header_style_fullscreen .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-item > a > span.et_mobile_menu_arrow:before, body.chi_dmm_styles .chi_mmc_activated .et_mobile_menu > li:not(.CTA-button).current-menu-parent > a, .et_header_style_slide .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-parent > a, .et_header_style_slide .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-parent > a > span.et_mobile_menu_arrow:before, body.chi_dmm_styles.et_header_style_fullscreen .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-parent > a, body.chi_dmm_styles.et_header_style_fullscreen .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-parent > a > span.et_mobile_menu_arrow:before, body.chi_dmm_styles .chi_mmc_activated .et_mobile_menu > li:not(.CTA-button).current-menu-ancestor > a, .et_header_style_slide .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-ancestor > a, .et_header_style_slide .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-ancestor > a > span.et_mobile_menu_arrow:before, body.chi_dmm_styles.et_header_style_fullscreen .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-ancestor > a, body.chi_dmm_styles.et_header_style_fullscreen .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-ancestor > a > span.et_mobile_menu_arrow:before {color: ' + newval + ' !important;}} </style>',
				style_id = 'style#chidmm_active_link_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu item top border width
	wp.customize( 'et_divi[chidmm_item_t_border_width]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_item_t_border_width">@media all and (max-width: 980px) {body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button), body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not(.CTA-button){border-top-width: ' + newval + 'px !important; border-style: solid;}} </style>',
				style_id = 'style#chidmm_item_t_border_width';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu item right border width
	wp.customize( 'et_divi[chidmm_item_r_border_width]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_item_r_border_width">@media all and (max-width: 980px) {body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button), body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not(.CTA-button){border-right-width: ' + newval + 'px !important; border-style: solid;}} </style>',
				style_id = 'style#chidmm_item_r_border_width';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu item bottom border width
	wp.customize( 'et_divi[chidmm_item_b_border_width]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_item_b_border_width">@media all and (max-width: 980px) {body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button), body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not(.CTA-button){border-bottom-width: ' + newval + 'px !important; border-style: solid;}} </style>',
				style_id = 'style#chidmm_item_b_border_width';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu item left border width
	wp.customize( 'et_divi[chidmm_item_l_border_width]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_item_l_border_width">@media all and (max-width: 980px) {body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button), body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not(.CTA-button){border-left-width: ' + newval + 'px !important; border-style: solid;}} </style>',
				style_id = 'style#chidmm_item_l_border_width';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu top border width
	wp.customize( 'et_divi[chidmm_top_border_width]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_top_border_width">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu {border-top-width: ' + newval + 'px !important; border-style: solid !important;}} </style>',
				style_id = 'style#chidmm_top_border_width';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu right border width
	wp.customize( 'et_divi[chidmm_right_border_width]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_right_border_width">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu {border-right-width: ' + newval + 'px !important; border-style: solid !important;}} </style>',
				style_id = 'style#chidmm_right_border_width';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu bottom border width
	wp.customize( 'et_divi[chidmm_bottom_border_width]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_bottom_border_width">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu {border-bottom-width: ' + newval + 'px !important; border-style: solid !important;}} </style>',
				style_id = 'style#chidmm_bottom_border_width';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu left border width
	wp.customize( 'et_divi[chidmm_left_border_width]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_left_border_width">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu {border-left-width: ' + newval + 'px !important; border-style: solid !important;}} </style>',
				style_id = 'style#chidmm_left_border_width';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu padding top
    wp.customize( 'et_divi[chidmm_padding_top]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_padding_top">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu {padding-top: ' + newval + '%;}} </style>',
				style_id = 'style#chidmm_padding_top';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu padding right
    wp.customize( 'et_divi[chidmm_padding_right]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_padding_right">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu {padding-right: ' + newval + '%;}} </style>',
				style_id = 'style#chidmm_padding_right';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu padding bottom
    wp.customize( 'et_divi[chidmm_padding_bottom]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_padding_bottom">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu {padding-bottom: ' + newval + '%;}} </style>',
				style_id = 'style#chidmm_padding_bottom';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu padding left
    wp.customize( 'et_divi[chidmm_padding_left]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_padding_left">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu {padding-left: ' + newval + '%;}} </style>',
				style_id = 'style#chidmm_padding_left';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update slide-in mobile menu padding top
    wp.customize( 'et_divi[chidmm_padding_top_slide]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_padding_top_slide">@media all and (max-width: 980px) {body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container .et_mobile_menu {padding-top: ' + newval + 'px !important;}} </style>',
				style_id = 'style#chidmm_padding_top_slide';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update slide-in mobile menu padding right
    wp.customize( 'et_divi[chidmm_padding_right_slide]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_padding_right_slide">@media all and (max-width: 980px) {body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container .et_mobile_menu {padding-right: ' + newval + 'px !important;}} </style>',
				style_id = 'style#chidmm_padding_right_slide';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update slide-in mobile menu padding bottom
    wp.customize( 'et_divi[chidmm_padding_bottom_slide]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_padding_bottom_slide">@media all and (max-width: 980px) {body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container .et_mobile_menu {padding-bottom: ' + newval + 'px !important;}} </style>',
				style_id = 'style#chidmm_padding_bottom_slide';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update slide-in mobile menu padding left
    wp.customize( 'et_divi[chidmm_padding_left_slide]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_padding_left_slide">@media all and (max-width: 980px) {body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container .et_mobile_menu {padding-left: ' + newval + 'px !important;}} </style>',
				style_id = 'style#chidmm_padding_left_slide';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu items margins
	wp.customize( 'et_divi[chidmm_items_margins]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_items_margins">@media all and (max-width: 980px) {.chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu li:not([class^="et_pb_"]):not(:first-of-type), .chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu li:not([class^="et_pb_"]):not(:first-of-type) {margin-top: ' + newval + 'px !important;}.chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu li:not([class^="et_pb_"]):not(:last-of-type), .chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu li:not([class^="et_pb_"]):not(:last-of-type) {margin-bottom: ' + newval + 'px !important;}} </style>',
				style_id = 'style#chidmm_items_margins';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    // Update mobile menu links letter spacing
	wp.customize( 'et_divi[chidmm_letter_spacing]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_letter_spacing">@media all and (max-width: 980px){ body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li:not([class^="et_pb_"]) a {letter-spacing: ' + newval + 'px !important;}} </style>',
				style_id = 'style#chidmm_letter_spacing';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    // Update mobile menu font style
    wp.customize( 'et_divi[chidmm_font_style]', function( value ) {
		value.bind( function( to ) {
			var styles = chidmm_set_font_styles( to, '' ),
				$style_content = '<style id="chidmm_font_style">@media all and (max-width: 980px){ body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu > li > a {' + styles + '}}</style>',
				style_id = 'style#chidmm_font_style';

			et_customizer_update_styles( style_id, $style_content );
		} );
	} );
    //Update mobile submenu background color
	wp.customize( 'et_divi[chidmm_submenu_bg_color]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_submenu_bg_color">@media all and (max-width: 980px) {body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li ul.sub-menu, body.chi_dmm_styles.et_header_style_slide #page-container .et_slide_in_menu_container #mobile_menu_slide li ul.sub-menu {background-color: ' + newval + ' !important;}} </style>',
				style_id = 'style#chidmm_submenu_bg_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile submenu link color
	wp.customize( 'et_divi[chidmm_submenu_link_color]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_submenu_link_color">@media all and (max-width: 980px) {body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li ul.sub-menu a, .et_header_style_slide .et_slide_in_menu_container #mobile_menu_slide li ul.sub-menu a, .et_header_style_slide .et_slide_in_menu_container li ul.sub-menu span.et_mobile_menu_arrow::before, .et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li a, .et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li span.et_mobile_menu_arrow::before{color: ' + newval + ' !important;}} </style>',
				style_id = 'style#chidmm_submenu_link_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile submenu current link color
	wp.customize( 'et_divi[chidmm_submenu_active_link_color]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_submenu_active_link_color">@media all and (max-width: 980px) {body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li ul.sub-menu li.current-menu-item > a, .et_header_style_slide .et_slide_in_menu_container #mobile_menu_slide li ul.sub-menu li.current-menu-item > a, .et_header_style_slide #mobile_menu_slide li ul.sub-menu  li.current-menu-item span.et_mobile_menu_arrow::before,   body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li ul.sub-menu li.current-menu-parent > a, .et_header_style_slide .et_slide_in_menu_container #mobile_menu_slide li ul.sub-menu li.current-menu-parent > a, .et_header_style_slide #mobile_menu_slide li ul.sub-menu  li.current-menu-parent > a > span.et_mobile_menu_arrow::before,   body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li ul.sub-menu li.current-menu-ancestor > a, .et_header_style_slide .et_slide_in_menu_container #mobile_menu_slide li ul.sub-menu li.current-menu-ancestor > a, .et_header_style_slide #mobile_menu_slide li ul.sub-menu  li.current-menu-ancestor > a > span.et_mobile_menu_arrow::before, .et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li.current-menu-item a,.et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li.current-menu-item span.et_mobile_menu_arrow::before,.et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li.current-menu-parent > a, .et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li.current-menu-parent > a > span.et_mobile_menu_arrow::before,.et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li.current-menu-ancestor > a,.et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li.current-menu-ancestor > a > span.et_mobile_menu_arrow::before {color: ' + newval + ' !important;}} </style>',
				style_id = 'style#chidmm_submenu_active_link_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile submenu font size
	wp.customize( 'et_divi[chidmm_submenu_font_size]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chidmm_submenu_font_size">@media all and (max-width: 980px) {body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li ul.sub-menu a, body.chi_dmm_styles.et_header_style_slide #page-container .et_slide_in_menu_container #mobile_menu_slide li ul.sub-menu a, body.chi_dmm_styles.et_header_style_fullscreen #page-container .et_pb_fullscreen_nav_container #mobile_menu_slide li ul.sub-menu li a, body.chi_dmm_styles.et_header_style_fullscreen .et_pb_fullscreen_nav_container li ul.sub-menu li span.et_mobile_menu_arrow::before {font-size: ' + newval + 'px !important;}} </style>',
				style_id = 'style#chidmm_submenu_font_size';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    // Update mobile submenu font style
    wp.customize( 'et_divi[chidmm_submenu_font_style]', function( value ) {
		value.bind( function( to ) {
			var styles = chidmm_set_font_styles( to, '' ),
				$style_content = '<style id="chidmm_submenu_font_style">@media all and (max-width: 980px){ body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li:not(.CTA-button) ul.sub-menu a, body.chi_dmm_styles.et_header_style_slide #page-container .et_slide_in_menu_container #mobile_menu_slide li:not(.CTA-button) ul.sub-menu a, body.chi_dmm_styles.et_header_style_fullscreen #page-container .et_pb_fullscreen_nav_container #mobile_menu_slide li:not(.CTA-button) ul.sub-menu li:not(.CTA-button) a {' + styles + '}}</style>',
				style_id = 'style#chidmm_submenu_font_style';

			et_customizer_update_styles( style_id, $style_content );
		} );
	} );
    
    // START - Update menu item border radius
    
    function chidmm_item_menu_radius( value ) {
        
            radius = '';
        
            newvalTop = wp.customize('et_divi[chidmm_item_border_tl_radius]').get();
            newvalRight = wp.customize('et_divi[chidmm_item_border_tr_radius]').get();
            newvalBottom = wp.customize('et_divi[chidmm_item_border_br_radius]').get();
            newvalLeft = wp.customize('et_divi[chidmm_item_border_bl_radius]').get();
    
            radius = newvalTop + 'px ' + newvalRight + 'px ' + newvalBottom + 'px '+ newvalLeft + 'px ';
        
            return radius;
        
    }
    
    wp.customize( 'et_divi[chidmm_item_border_tl_radius]' , function borderRadiusLive ( value ) {
		value.bind( function( to ) {
            
           var radius = chidmm_item_menu_radius( to );
            
			var $style_content = '<style id="chidmm_item_border_radius">@media all and (max-width: 980px) { body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button), body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not([class^="et_pb_"]) {-webkit-border-radius: ' + radius + ' !important; -moz-border-radius: ' + radius + ' !important; border-radius: ' + radius + ' !important;}} </style>',
				style_id = 'style#chidmm_item_border_radius';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    
    wp.customize( 'et_divi[chidmm_item_border_tr_radius]' , function borderRadiusLive ( value ) {
		value.bind( function( to ) {
            
           var radius = chidmm_item_menu_radius( to );
            
			var $style_content = '<style id="chidmm_item_border_radius">@media all and (max-width: 980px) { body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button), body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not([class^="et_pb_"]) {-webkit-border-radius: ' + radius + ' !important; -moz-border-radius: ' + radius + ' !important; border-radius: ' + radius + ' !important;}} </style>',
				style_id = 'style#chidmm_item_border_radius';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    
    wp.customize( 'et_divi[chidmm_item_border_br_radius]' , function borderRadiusLive ( value ) {
		value.bind( function( to ) {
            
           var radius = chidmm_item_menu_radius( to );
            
			var $style_content = '<style id="chidmm_item_border_radius">@media all and (max-width: 980px) { body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button), body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not([class^="et_pb_"]) {-webkit-border-radius: ' + radius + ' !important; -moz-border-radius: ' + radius + ' !important; border-radius: ' + radius + ' !important;}} </style>',
				style_id = 'style#chidmm_item_border_radius';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    wp.customize( 'et_divi[chidmm_item_border_bl_radius]' , function borderRadiusLive ( value ) {
		value.bind( function( to ) {
            
           var radius = chidmm_item_menu_radius( to );
            
			var $style_content = '<style id="chidmm_item_border_radius">@media all and (max-width: 980px) { body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button), body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not([class^="et_pb_"]) {-webkit-border-radius: ' + radius + ' !important; -moz-border-radius: ' + radius + ' !important; border-radius: ' + radius + ' !important;}} </style>',
				style_id = 'style#chidmm_item_border_radius';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    
    // END menu item border radius //
    // START - Update menu border radius
    
    function chidmm_menu_radius( value ) {
        
            radius = '';
        
            newvalTop = wp.customize('et_divi[chidmm_border_tl_radius]').get();
            newvalRight = wp.customize('et_divi[chidmm_border_tr_radius]').get();
            newvalBottom = wp.customize('et_divi[chidmm_border_br_radius]').get();
            newvalLeft = wp.customize('et_divi[chidmm_border_bl_radius]').get();
    
            radius = newvalTop + 'px ' + newvalRight + 'px ' + newvalBottom + 'px '+ newvalLeft + 'px ';
        
            return radius;
        
    }
    
    wp.customize( 'et_divi[chidmm_border_tl_radius]' , function borderRadiusLive ( value ) {
		value.bind( function( to ) {
            
           var radius = chidmm_menu_radius( to );
            
			var $style_content = '<style id="chidmm_border_radius">@media all and (max-width: 980px) { body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu {-webkit-border-radius: ' + radius + ' !important; -moz-border-radius: ' + radius + ' !important; border-radius: ' + radius + ' !important;}} </style>',
				style_id = 'style#chidmm_border_radius';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    
    wp.customize( 'et_divi[chidmm_border_tr_radius]' , function borderRadiusLive ( value ) {
		value.bind( function( to ) {
            
            var radius = chidmm_menu_radius( to );
            
			var $style_content = '<style id="chidmm_border_radius">@media all and (max-width: 980px) { body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu {-webkit-border-radius: ' + radius + ' !important; -moz-border-radius: ' + radius + ' !important; border-radius: ' + radius + ' !important;}} </style>',
				style_id = 'style#chidmm_border_radius';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    
    wp.customize( 'et_divi[chidmm_border_br_radius]' , function borderRadiusLive ( value ) {
		value.bind( function( to ) {
            
            var radius = chidmm_menu_radius( to );
            
			var $style_content = '<style id="chidmm_border_radius">@media all and (max-width: 980px) { body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu {-webkit-border-radius: ' + radius + ' !important; -moz-border-radius: ' + radius + ' !important; border-radius: ' + radius + ' !important;}} </style>',
				style_id = 'style#chidmm_border_radius';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    wp.customize( 'et_divi[chidmm_border_bl_radius]' , function borderRadiusLive ( value ) {
		value.bind( function( to ) {
            
            var radius = chidmm_menu_radius( to );
            
			var $style_content = '<style id="chidmm_border_radius">@media all and (max-width: 980px) { body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu {-webkit-border-radius: ' + radius + ' !important; -moz-border-radius: ' + radius + ' !important; border-radius: ' + radius + ' !important;}} </style>',
				style_id = 'style#chidmm_border_radius';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    
    // END menu item border radius 
    
    // START - Update menu shadow
    
    function chidmm_menu_shadow( value ) {
        
            shadow = '';
        
            shadowInOut = wp.customize('et_divi[chidmm_dd_shadow_in_out]').get();
            xOffset = wp.customize('et_divi[chidmm_dd_shadow_x_offset]').get();
            yOffset = wp.customize('et_divi[chidmm_dd_shadow_y_offset]').get();
            shadowBlur = wp.customize('et_divi[chidmm_dd_shadow_blur]').get();
            shadowSpread = wp.customize('et_divi[chidmm_dd_shadow_spread]').get();
            shadowColor = wp.customize('et_divi[chidmm_dd_shadow_color]').get();
    
            shadow = shadowInOut + ' ' + xOffset + 'px ' + yOffset + 'px ' + shadowBlur + 'px '+ shadowSpread + 'px ' + shadowColor ;
        
            return shadow;
        
    }
    
    wp.customize( 'et_divi[chidmm_dd_shadow_in_out]' , function borderShadowLive ( value ) {
		value.bind( function( to ) {
            
           var shadow = chidmm_menu_shadow( to );
            
			var $style_content = '<style id="chidmm_box_shadow">@media all and (max-width: 980px) { body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu, body.et_header_style_slide .et_slide_in_menu_container.et_pb_slide_menu_opened {-webkit-box-shadow: ' + shadow + ' !important; -moz-box-shadow: ' + shadow + ' !important; box-shadow: ' + shadow + ' !important;}} </style>',
				style_id = 'style#chidmm_box_shadow';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    wp.customize( 'et_divi[chidmm_dd_shadow_x_offset]' , function borderShadowLive ( value ) {
		value.bind( function( to ) {
            
           var shadow = chidmm_menu_shadow( to );
            
			var $style_content = '<style id="chidmm_box_shadow">@media all and (max-width: 980px) { body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu, body.et_header_style_slide .et_slide_in_menu_container.et_pb_slide_menu_opened {-webkit-box-shadow: ' + shadow + ' !important; -moz-box-shadow: ' + shadow + ' !important; box-shadow: ' + shadow + ' !important;}} </style>',
				style_id = 'style#chidmm_box_shadow';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    wp.customize( 'et_divi[chidmm_dd_shadow_y_offset]' , function borderShadowLive ( value ) {
		value.bind( function( to ) {
            
           var shadow = chidmm_menu_shadow( to );
            
			var $style_content = '<style id="chidmm_box_shadow">@media all and (max-width: 980px) { body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu, body.et_header_style_slide .et_slide_in_menu_container.et_pb_slide_menu_opened {-webkit-box-shadow: ' + shadow + ' !important; -moz-box-shadow: ' + shadow + ' !important; box-shadow: ' + shadow + ' !important;}} </style>',
				style_id = 'style#chidmm_box_shadow';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    wp.customize( 'et_divi[chidmm_dd_shadow_spread]' , function borderShadowLive ( value ) {
		value.bind( function( to ) {
            
           var shadow = chidmm_menu_shadow( to );
            
			var $style_content = '<style id="chidmm_box_shadow">@media all and (max-width: 980px) { body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu, body.et_header_style_slide .et_slide_in_menu_container.et_pb_slide_menu_opened {-webkit-box-shadow: ' + shadow + ' !important; -moz-box-shadow: ' + shadow + ' !important; box-shadow: ' + shadow + ' !important;}} </style>',
				style_id = 'style#chidmm_box_shadow';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    wp.customize( 'et_divi[chidmm_dd_shadow_blur]' , function borderShadowLive ( value ) {
		value.bind( function( to ) {
            
           var shadow = chidmm_menu_shadow( to );
            
			var $style_content = '<style id="chidmm_box_shadow">@media all and (max-width: 980px) { body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu, body.et_header_style_slide .et_slide_in_menu_container.et_pb_slide_menu_opened {-webkit-box-shadow: ' + shadow + ' !important; -moz-box-shadow: ' + shadow + ' !important; box-shadow: ' + shadow + ' !important;}} </style>',
				style_id = 'style#chidmm_box_shadow';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    wp.customize( 'et_divi[chidmm_dd_shadow_color]' , function borderShadowLive ( value ) {
		value.bind( function( to ) {
            
           var shadow = chidmm_menu_shadow( to );
            
			var $style_content = '<style id="chidmm_box_shadow">@media all and (max-width: 980px) { body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu, body.et_header_style_slide .et_slide_in_menu_container.et_pb_slide_menu_opened {-webkit-box-shadow: ' + shadow + ' !important; -moz-box-shadow: ' + shadow + ' !important; box-shadow: ' + shadow + ' !important;}} </style>',
				style_id = 'style#chidmm_box_shadow';
				
			et_customizer_update_styles( style_id, $style_content );
	       
        } );
	   
    } );
    
    // END menu shadow 
    
	// START GRADIENTS
    // dropdown menu gradient
    function chimmc_menu_gradient( value ) {
        
            gradient = '';
            
            chimmc_menu_gradient_on_off = wp.customize('et_divi[chimmc_menu_gradient_on_off]').get();
        
            stop1_Color = wp.customize('et_divi[chimmc_menu_gradient_stop1_color]').get();
            stop1_Location = wp.customize('et_divi[chimmc_menu_gradient_stop1_location]').get();
            stop2_Color = wp.customize('et_divi[chimmc_menu_gradient_stop2_color]').get();
            stop2_Location = wp.customize('et_divi[chimmc_menu_gradient_stop2_location]').get();
            stop3_Color = wp.customize('et_divi[chimmc_menu_gradient_stop3_color]').get();
            stop3_Location = wp.customize('et_divi[chimmc_menu_gradient_stop3_location]').get();
            menuGradientAngle = wp.customize('et_divi[chimmc_menu_gradient_angle]').get();
            // disable gradient background clip for fullscreen header
            chimmc_gradient_clip = ( $('body.chi_dmm_styles').hasClass('et_header_style_fullscreen') ) ? '' : wp.customize('et_divi[chimmc_gradient_clip]').get();
        
            chimmc_bg_image_on_off = wp.customize('et_divi[chimmc_bg_image_on_off]').get();
            chimmc_bg_image_url = wp.customize('et_divi[chimmc_bg_image_url]').get();
            chimmc_bg_image_size = wp.customize('et_divi[chimmc_bg_image_size]').get();
            chimmc_bg_image_position = wp.customize('et_divi[chimmc_bg_image_position]').get();
            chimmc_bg_image_repeat = wp.customize('et_divi[chimmc_bg_image_repeat]').get();
            // disable background image clip for fullscreen header
            chimmc_bg_image_clip = ( $('body.chi_dmm_styles').hasClass('et_header_style_fullscreen') ) ? '' : wp.customize('et_divi[chimmc_bg_image_clip]').get();
    
            gradient = menuGradientAngle + 'deg, ' + stop1_Color + ' ' + stop1_Location + '%, ' + stop2_Color + ' ' + stop2_Location + '%, ' + stop3_Color + ' ' + stop3_Location + '% ';
        
            chimmc_menu_moz_linear_gradient = ( chimmc_menu_gradient_on_off == 'enabled' ) ? '-moz-linear-gradient( ' + gradient + ' ) ' + chimmc_gradient_clip + ' ' : '';
            chimmc_menu_webkit_linear_gradient = ( chimmc_menu_gradient_on_off == 'enabled' ) ? '-webkit-linear-gradient( ' + gradient + ' ) ' + chimmc_gradient_clip + ' ' : '';
            chimmc_menu_o_linear_gradient = ( chimmc_menu_gradient_on_off == 'enabled' ) ? '-o-linear-gradient( ' + gradient + ' ) ' + chimmc_gradient_clip + ' ' : '';
            chimmc_menu_linear_gradient = ( chimmc_menu_gradient_on_off == 'enabled' ) ? 'linear-gradient( ' + gradient + ' ) ' + chimmc_gradient_clip + ' ' : '';

            chimmc_bg_image = ( chimmc_bg_image_on_off == 'enabled' ) ? 'url(' + chimmc_bg_image_url + ') ' + chimmc_bg_image_position + ' ' + chimmc_bg_image_repeat + ' ' + chimmc_bg_image_clip : '';
            // comma between menu gradient and menu bg image
            chimmc_bg_comma = ( 'enabled' == chimmc_bg_image_on_off && 'enabled' == chimmc_menu_gradient_on_off ) ? ',' : '';
        
        
        if (chimmc_menu_gradient_on_off == 'enabled' || chimmc_bg_image_on_off == 'enabled' ){
        
            menuGradientCSS = '@media all and (max-width: 980px) { \
            body.chi_dmm_styles .chi_mmc_activated #mobile_menu , \
            body.chi_dmm_styles .et_slide_in_menu_container { \
                background: ' + chimmc_menu_webkit_linear_gradient + ' ' + chimmc_bg_comma + ' ' + chimmc_bg_image + ' !important; \
                background: ' + chimmc_menu_o_linear_gradient + ' ' + chimmc_bg_comma + ' ' + chimmc_bg_image + ' !important; \
                background: ' + chimmc_menu_moz_linear_gradient + ' ' + chimmc_bg_comma + ' ' + chimmc_bg_image + ' !important; \
                background: ' + chimmc_menu_linear_gradient + ' ' + chimmc_bg_comma + ' ' + chimmc_bg_image + ' !important;' ;
                
                if ( chimmc_bg_image_on_off == 'enabled' ){
                    menuGradientCSS += 'background-size: ' + chimmc_bg_image_size + ' !important; ';
                }
                
                menuGradientCSS += '}}';
        }
            else {
                menuGradientCSS = '@media all and (max-width: 980px) { body.chi_dmm_styles .chi_mmc_activated #mobile_menu, body.chi_dmm_styles .et_slide_in_menu_container { background: none !important;}}';
            }
        
            return menuGradientCSS;
        
    }
    
    function chimmc_menu_gradient_preview( setting ) {
        wp.customize( 'et_divi[' + setting + ']' , function menuGradientLive ( value ) {
            value.bind( function( to ) {  
                var menuGradientCSS = chimmc_menu_gradient( to );  
                var $style_content = '<style id="chimmc_dropdown_menu_gradient">' + menuGradientCSS + '</style>',
                    style_id = 'style#chimmc_dropdown_menu_gradient';
                et_customizer_update_styles( style_id, $style_content );

            } );

        } );    
    }
    
    // Update dropdown menu gradient enabled/disabled state
    chimmc_menu_gradient_preview( 'chimmc_menu_gradient_on_off' );
    
    // Update dropdown menu gradient stop 1 color
    chimmc_menu_gradient_preview( 'chimmc_menu_gradient_stop1_color' );
    
    // Update dropdown menu gradient stop 1 location
    chimmc_menu_gradient_preview( 'chimmc_menu_gradient_stop1_location' );
    
    // Update dropdown menu gradient stop 2 color
    chimmc_menu_gradient_preview( 'chimmc_menu_gradient_stop2_color' );
    
    // Update dropdown menu gradient stop 2 location
    chimmc_menu_gradient_preview( 'chimmc_menu_gradient_stop2_location' );
    
    // Update dropdown menu gradient stop 3 color
    chimmc_menu_gradient_preview( 'chimmc_menu_gradient_stop3_color' );
    
    // Update dropdown menu gradient stop 3 location
    chimmc_menu_gradient_preview( 'chimmc_menu_gradient_stop3_location' );
    
    // Update dropdown menu gradient angle
    chimmc_menu_gradient_preview( 'chimmc_menu_gradient_angle' );
    
    // Update dropdown menu gradient background-clip
    chimmc_menu_gradient_preview( 'chimmc_gradient_clip' );
    
    // Update dropdown menu background image enabled/disabled state
    chimmc_menu_gradient_preview( 'chimmc_bg_image_on_off' );
    
    // Update dropdown menu background image url
    chimmc_menu_gradient_preview( 'chimmc_bg_image_url' );
    
    // Update dropdown menu background image position
    chimmc_menu_gradient_preview( 'chimmc_bg_image_position' );
    
    // Update dropdown menu background image repeat
    chimmc_menu_gradient_preview( 'chimmc_bg_image_repeat' );
    
    // Update dropdown menu background image clip
    chimmc_menu_gradient_preview( 'chimmc_bg_image_clip' );
    
    // Update dropdown menu background image size
    chimmc_menu_gradient_preview( 'chimmc_bg_image_size' );
    
    // END dropdown menu gradient
    
    // menu header gradient
    function chimmc_menu_header_gradient( value ) {
        
            header_gradient = '';
            
            chimmc_header_gradient_on_off = wp.customize('et_divi[chimmc_header_gradient_on_off]').get();
        
            header_stop1_Color = wp.customize('et_divi[chimmc_header_gradient_stop1_color]').get();
            header_stop1_Location = wp.customize('et_divi[chimmc_header_gradient_stop1_location]').get();
            header_stop2_Color = wp.customize('et_divi[chimmc_header_gradient_stop2_color]').get();
            header_stop2_Location = wp.customize('et_divi[chimmc_header_gradient_stop2_location]').get();
            header_stop3_Color = wp.customize('et_divi[chimmc_header_gradient_stop3_color]').get();
            header_stop3_Location = wp.customize('et_divi[chimmc_header_gradient_stop3_location]').get();
            header_GradientAngle = wp.customize('et_divi[chimmc_header_gradient_angle]').get();
    
            header_gradient = header_GradientAngle + 'deg, ' + header_stop1_Color + ' ' + header_stop1_Location + '%, ' + header_stop2_Color + ' ' + header_stop2_Location + '%, ' + header_stop3_Color + ' ' + header_stop3_Location + '% ';
           
        if (chimmc_header_gradient_on_off == 'enabled'){
        
            header_GradientCSS = '@media all and (max-width: 980px) { body.chi_dmm_styles #main-header.chi_mmc_activated { background: -webkit-linear-gradient(' + header_gradient + ') !important; background: -o-linear-gradient(' + header_gradient + ') !important; background: -moz-linear-gradient(' + header_gradient + ') !important; background: linear-gradient(' + header_gradient + ') !important;}}';
        }
            else {
                header_GradientCSS = '@media all and (max-width: 980px) { body.chi_dmm_styles #main-header.chi_mmc_activated { background: none ;}}';
            }
        
            return header_GradientCSS;
        
    }
    
    function chimmc_header_gradient_preview( setting ) {
        wp.customize( 'et_divi[' + setting + ']' , function headerGradientLive ( value ) {
            value.bind( function( to ) {  
                var header_GradientCSS = chimmc_menu_header_gradient( to );  
                var $style_content = '<style id="chimmc_menu_header_gradient">' + header_GradientCSS + '</style>',
                    style_id = 'style#chimmc_menu_header_gradient';
                et_customizer_update_styles( style_id, $style_content );

            } );

        } );    
    }
    
    // Update dropdown menu gradient enabled/disabled state
    chimmc_header_gradient_preview( 'chimmc_header_gradient_on_off' );
    
    // Update dropdown menu gradient stop 1 color
    chimmc_header_gradient_preview( 'chimmc_header_gradient_stop1_color' );
    
    // Update dropdown menu gradient stop 1 location
    chimmc_header_gradient_preview( 'chimmc_header_gradient_stop1_location' );
    
    // Update dropdown menu gradient stop 2 color
    chimmc_header_gradient_preview( 'chimmc_header_gradient_stop2_color' );
    
    // Update dropdown menu gradient stop 2 location
    chimmc_header_gradient_preview( 'chimmc_header_gradient_stop2_location' );
    
    // Update dropdown menu gradient stop 3 color
    chimmc_header_gradient_preview( 'chimmc_header_gradient_stop3_color' );
    
    // Update dropdown menu gradient stop 3 location
    chimmc_header_gradient_preview( 'chimmc_header_gradient_stop3_location' );
    
    // Update dropdown menu gradient angle
    chimmc_header_gradient_preview( 'chimmc_header_gradient_angle' );
    
    // END menu header gradient
       
    // END GRADIENTS
    
    // START CUSTOM MENU ANIMATIONS
    
    function chimmc_apply_custom_animations ( first_animation, second_animation ){ 
        
        if ( $('body:not(.et_header_style_slide):not(.et_header_style_fullscreen)').hasClass('et_header_style_left') || $('body').hasClass('et_header_style_centered') || $('body').hasClass('et_header_style_split') ) {

            var $this_menu = $('#main-header .mobile_nav');
            var $dropdown_nav = $('#main-header .et_mobile_menu');
            $this_menu.off('click');

            $this_menu.on( 'click', '.mobile_menu_bar', function(){
                if ( $this_menu.hasClass('closed') ){
                    $this_menu.removeClass( 'closed' ).addClass( 'opened' );

                    if ( first_animation != 'default') {
                        // remove default slideDown effect
                        $dropdown_nav.stop(true, true);
                    } else {
                        // add slideDown effect
                        $('.mobile_nav.opened .et_mobile_menu').slideDown(700);
                    }

                    // keep the menu visible while animation runs
                    $('.mobile_nav.opened .et_mobile_menu').css( { 'display' : 'block' } );

                } else if ( $this_menu.hasClass('opened') ) {
                    $this_menu.removeClass( 'opened' ).addClass( 'closed' );

                    if ( second_animation != 'default' ){
                        // remove default slideUp effect
                        $dropdown_nav.stop(true, true);
                    } else {
                        // add slideUp effect
                        $('.mobile_nav.closed .et_mobile_menu').slideUp(700);
                    }

                    // hide the menu after css animation completed
                    
                    if ( second_animation == 'none' ){

                    setTimeout( function() {
                        // fix for menu disappearing due to animation delay despite having class 'opened' 
                        $this_menu.removeClass( 'opened' ).addClass( 'closed' );
                        // hide menu without delay for 'none' value
                        $dropdown_nav.css( { 'display' : 'none' } );
                    }, 0 );
                    } else {
                    setTimeout( function() {
                        // fix for menu disappearing due to animation delay despite having class 'opened' 
                        $this_menu.removeClass( 'opened' ).addClass( 'closed' );
                        // hide menu with a delay
                        $dropdown_nav.css( { 'display' : 'none' } );
                        }, 700 );
                    }
                }
                return false;
                } );
            }
    }
    
    //Update mobile menu open animation
	wp.customize( 'et_divi[chimmc_menu_in_animation]', function( value ) {
       
		value.bind( function( newval ) {
            
            if (newval == null){
                var $chimmc_menu_in_animation = wp.customize('et_divi[chimmc_menu_in_animation]').get();
            } else {
                $chimmc_menu_in_animation = newval;
            }
            
            var $chimmc_menu_out_animation = wp.customize('et_divi[chimmc_menu_out_animation]').get();
            
            chimmc_apply_custom_animations ( $chimmc_menu_in_animation , $chimmc_menu_out_animation );
            
            if ( newval != 'default' ){
                
                var $style_content = '<style id="chimmc_menu_in_animation">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles #main-header.chi_mmc_activated  .mobile_nav.opened .et_mobile_menu {animation: ' + newval + ' .8s ease !important; -webkit-animation: ' + newval + ' .8s ease !important;}} </style>',
				style_id = 'style#chimmc_menu_in_animation';
				
                et_customizer_update_styles( style_id, $style_content );
            
                } else {
                    
                    var $style_content = '<style id="chimmc_menu_in_animation">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles #main-header.chi_mmc_activated  .mobile_nav.opened .et_mobile_menu {animation: none .8s ease !important; -webkit-animation: none .8s ease !important;}} </style>',
				    style_id = 'style#chimmc_menu_in_animation';
				
                    et_customizer_update_styles( style_id, $style_content );
                
                    } 
            } );
    } );
    
    //Update mobile menu close animation
	wp.customize( 'et_divi[chimmc_menu_out_animation]', function( value ) {
       
		value.bind( function( newval ) {
            
            if (newval == null) {
                var $chimmc_menu_out_animation = wp.customize('et_divi[chimmc_menu_out_animation]').get();
            } else {
                $chimmc_menu_out_animation = newval;
            }
            
            var $chimmc_menu_in_animation = wp.customize('et_divi[chimmc_menu_in_animation]').get();
            
            chimmc_apply_custom_animations ( $chimmc_menu_in_animation , $chimmc_menu_out_animation );
            
            if ( newval != 'default' ){
                                    
                var $style_content = '<style id="chimmc_menu_out_animation">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles #main-header.chi_mmc_activated .mobile_nav.closed .et_mobile_menu {animation: ' + newval + ' .8s ease !important; -webkit-animation: ' + newval + ' .8s ease !important;}} </style>',
				style_id = 'style#chimmc_menu_out_animation';
				
                et_customizer_update_styles( style_id, $style_content );
       
                } else {
                    
                    var $style_content = '<style id="chimmc_menu_out_animation">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles #main-header.chi_mmc_activated .mobile_nav.closed .et_mobile_menu {animation: none !important; -webkit-animation: none !important;}} </style>',
				    style_id = 'style#chimmc_menu_out_animation';
				
                    et_customizer_update_styles( style_id, $style_content );
                
                    } 
	       } );
	} );
    
    // END CUSTOM MENU ANIMATIONS
    
    
    // SINCE V1.3.2
    
    // Fix for vertical nav top offset
    
	wp.customize( 'et_divi[vertical_nav]', function( value ) {
       
		value.bind( function( newval ) {                     
            
            if ( newval === true ){               
                
                    var adminBarHeight = $( '#wpadminbar' ).length > 0 ? parseInt( $( '#wpadminbar' ).outerHeight() ) : 0;
                
            var topHeaderHeight = $( '#top-header' ).length > 0 ? parseInt( $( '#top-header' ).outerHeight() ) : 0;

            var mainHeaderHeight = $( '#main-header.chi_mmc_activated' ).length > 0 ? parseInt( $( '#main-header.chi_mmc_activated' ).outerHeight() ) : 0;

            var offset = adminBarHeight + topHeaderHeight + mainHeaderHeight ;
                
                    //var $style_content = '',
        
                    var $style_content = '<style id="chimmc_vertical_nav">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_left #main-header.chi_mmc_activated, body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_centered #main-header.chi_mmc_activated, body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_split #main-header.chi_mmc_activated { top: ' + topHeaderHeight + 'px !important; }body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_left #main-content, body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_centered #main-content, body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_split #main-content { padding-top: ' + offset + 'px !important; } } </style>',
                        style_id = 'style#chimmc_vertical_nav';

                        et_customizer_update_styles( style_id, $style_content );
       
                } else if ( newval === false ){
                    
                    var topHeaderHeight = $( '#top-header' ).length > 0 ? parseInt( $( '#top-header' ).outerHeight() ) : 0;
                   
                        var $style_content = '<style id="chimmc_vertical_nav">@media all and (max-width: 980px) {body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_left #main-header.chi_mmc_activated, body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_centered #main-header.chi_mmc_activated, body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_split #main-header.chi_mmc_activated { top: ' + topHeaderHeight + 'px !important; }body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_left #main-content, body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_centered #main-content, body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_split #main-content { padding-top: 0 !important; } } </style>',
				            style_id = 'style#chimmc_vertical_nav';
				
                    et_customizer_update_styles( style_id, $style_content );
                
                    } 
	       } );
	} );
    
    // End fix for vertical nav top offset
    
    // SINCE v1.4
    
    // menu header options
    
    function chimmc_apply_menu_header_settings( value ) {
        
        var chimmc_menu_bar_format = wp.customize('et_divi[chimmc_menu_bar_format]').get(); 
        var chimmc_menu_bar_text = wp.customize('et_divi[chimmc_menu_bar_text]').get(); 
        var chimmc_menu_bar_close_text = wp.customize('et_divi[chimmc_menu_bar_close_text]').get();
        var chimmc_menu_bar_close_icon = wp.customize('et_divi[chimmc_menu_bar_close_icon]').get();
        var chimmc_search_icon = wp.customize('et_divi[chimmc_search_icon]').get();
        var chimmc_menu_bar_text_size = wp.customize('et_divi[chimmc_menu_bar_text_size]').get();
        // search icon/hamburger = 0.53125 (32px is for hamburger icon)
        var chimmc_menu_bar_icon_size = wp.customize('et_divi[chimmc_menu_bar_icon_size]').get();
        // calculate search icon size relatively to hamburger icon size
        var chimmc_menu_search_icon_size = Math.round( chimmc_menu_bar_icon_size * 0.53125 );
        var chimmc_menu_bar_font_style = wp.customize('et_divi[chimmc_menu_bar_font_style]').get();

        // swap pseudo elements: after <-> before
        var chimmc_menu_pseudo_1 = ( chimmc_menu_bar_format == 'text_icon' ) ? 'after' : 'before';
        var chimmc_menu_pseudo_2 = ( chimmc_menu_bar_format == 'text_icon' ) ? 'before' : 'after';
        // show/hide pseudo elements' content
        var chimmc_menu_pseudo_1_content = ( chimmc_menu_bar_format == 'text_only' ) ? '' : '\\61' ;
        var chimmc_menu_pseudo_2_content = ( chimmc_menu_bar_format == 'icon_only' ) ? '' : chimmc_menu_bar_text ;
        // menu "close" text
        var chimmc_menu_pseudo_2_content_close = ( '' != chimmc_menu_bar_close_text && chimmc_menu_bar_format != 'icon_only' ) ? chimmc_menu_bar_close_text : chimmc_menu_pseudo_2_content;
        //enable/disable "X" icon for closing menu
        var chimmc_menu_pseudo_1_content_close = ( true === chimmc_menu_bar_close_icon && chimmc_menu_bar_format != 'text_only' ) ? '\\4d' : chimmc_menu_pseudo_1_content;
        // dropdown menu top offset
        var chimmc_menu_dd_top_offset = wp.customize('et_divi[chimmc_menu_dd_top_offset]').get();
        var centered_split_top_offset = eval(chimmc_menu_dd_top_offset) + eval(53); 
        
        // font styles
        var styles = chidmm_set_font_styles( chimmc_menu_bar_font_style, '' );
        // fix for menu icon font weight when text_icon format chosen
        var icon_font_weight_normal = 'body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_left #main-header.chi_mmc_activated .mobile_menu_bar:after, .chi_dmm_styles.et_header_style_split #main-header .mobile_menu_bar:after,.chi_dmm_styles.et_header_style_centered #main-header .mobile_menu_bar:after { font-weight: normal !important; }';
        var pseudo_after_icon_style = ( chimmc_menu_bar_format == 'text_icon' ) ? icon_font_weight_normal : '';
        
        // add padding-right to menu bar text
        var menu_icon_text_padding_right = ( chimmc_menu_bar_format == 'text_icon' || chimmc_menu_bar_format == 'icon_only' ) ? 0 : 5;
        
        // search icon display
        var search_display = ( true === chimmc_search_icon ) ? 'block' : 'none';
       
        
        var Chimmc_Menu_Header_Sttings = ' .chi_dmm_styles #main-header .mobile_nav.opened .mobile_menu_bar:' + chimmc_menu_pseudo_1 + ', .chi_dmm_styles #main-header .mobile_nav.closed .mobile_menu_bar:' + chimmc_menu_pseudo_1 + ' { font-family: "ETmodules" !important; font-size:' + chimmc_menu_bar_icon_size + 'px ; } .chi_dmm_styles #main-header.chi_mmc_activated #et_search_icon:before { font-size: ' + chimmc_menu_search_icon_size + 'px; } .chi_dmm_styles #main-header .mobile_nav.closed .mobile_menu_bar:' + chimmc_menu_pseudo_1 + ' { content: "' + chimmc_menu_pseudo_1_content + '" !important; } .chi_dmm_styles #main-header .mobile_nav.opened .mobile_menu_bar:' + chimmc_menu_pseudo_1 + ' { content: "' + chimmc_menu_pseudo_1_content_close + '"; } .chi_dmm_styles #et-top-navigation .mobile_nav.opened .mobile_menu_bar:' + chimmc_menu_pseudo_2 + ', .chi_dmm_styles #et-top-navigation .mobile_nav.closed .mobile_menu_bar:' + chimmc_menu_pseudo_2 + ' { font-family: inherit !important; font-size: ' + chimmc_menu_bar_text_size + 'px !important; padding-top: 0px; padding-right: ' + menu_icon_text_padding_right + 'px; padding-bottom: 2px; padding-left: 0px; } .chi_dmm_styles .mobile_nav .select_page { font-size: ' + chimmc_menu_bar_text_size + 'px !important; ' + styles + ' } .chi_dmm_styles #main-header .mobile_nav.closed .mobile_menu_bar:' + chimmc_menu_pseudo_2 + ' { content: "' + chimmc_menu_pseudo_2_content + '"; } .chi_dmm_styles #main-header .mobile_nav.opened .mobile_menu_bar:' + chimmc_menu_pseudo_2 + ' { content: "' + chimmc_menu_pseudo_2_content_close + '"; } .chi_dmm_styles #main-header .mobile_nav.opened .mobile_menu_bar:' + chimmc_menu_pseudo_2 + ', .chi_dmm_styles #main-header .mobile_nav.closed .mobile_menu_bar:' + chimmc_menu_pseudo_2 + ' { ' + styles + ' } body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_left #main-header.chi_mmc_activated .et_mobile_menu { margin-top: ' + chimmc_menu_dd_top_offset + 'px; } .chi_dmm_styles.et_header_style_split #main-header .et_mobile_menu, .chi_dmm_styles.et_header_style_centered  #main-header .et_mobile_menu { top: ' + centered_split_top_offset + 'px; } body:not(.et_header_style_slide):not(.et_header_style_fullscreen).et_header_style_left #et_top_search,.et_vertical_nav.et_header_style_left #main-header #et_top_search, .et_header_style_centered #et_top_search,.et_vertical_nav.et_header_style_centered #main-header #et_top_search, .et_header_style_split #et_top_search,.et_vertical_nav.et_header_style_split #main-header #et_top_search{display: ' + search_display + ' !important;}.et_header_style_centered .et_search_outer,.et_header_style_split .et_search_outer{display: ' + search_display + ' !important;} ' + pseudo_after_icon_style + '';
        /* END menu header */
        
        return Chimmc_Menu_Header_Sttings;
      
    }
        
    function chimmc_menu_header_settings_preview( setting ) {
        wp.customize( 'et_divi[' + setting + ']' , function menuHeaderSettingsLive ( value ) {
            value.bind( function( to ) { 
                
                var Chimmc_Menu_Header_Sttings = chimmc_apply_menu_header_settings( to );
                
                var $style_content = '<style id="chimmc_apply_menu_header_settings">@media all and (max-width: 980px) {' + Chimmc_Menu_Header_Sttings + '}</style>',
                    style_id = 'style#chimmc_apply_menu_header_settings';
                et_customizer_update_styles( style_id, $style_content );
                
            } );

        } );    
    }
 
    // Update 
    chimmc_menu_header_settings_preview( 'chimmc_menu_bar_format' );
    
    // Update 
    chimmc_menu_header_settings_preview( 'chimmc_menu_bar_text' );
    
    // Update 
    chimmc_menu_header_settings_preview( 'chimmc_menu_bar_close_text' );
    
    // Update 
    chimmc_menu_header_settings_preview( 'chimmc_menu_bar_close_icon' );
    
    // Update 
    chimmc_menu_header_settings_preview( 'chimmc_search_icon' );
    
    // Update 
    chimmc_menu_header_settings_preview( 'chimmc_menu_bar_text_size' );
    
    // Update 
    chimmc_menu_header_settings_preview( 'chimmc_menu_bar_icon_size' );
    
    // Update 
    chimmc_menu_header_settings_preview( 'chimmc_menu_bar_font_style' );
    
    // Update 
    chimmc_menu_header_settings_preview( 'chimmc_menu_dd_top_offset' );
        
    //Update mobile menu header bar text color
	wp.customize( 'et_divi[chimmc_header_text_color]', function( value ) {
		value.bind( function( newval ) {
            
			var $style_content = '<style id="chimmc_header_text_color">@media all and (max-width: 980px) {body.chi_dmm_styles.et_header_style_centered .chi_mmc_activated .mobile_nav .select_page, body.chi_dmm_styles.et_header_style_split .chi_mmc_activated .mobile_nav .select_page, body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .mobile_menu_bar:before, body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .mobile_menu_bar:after, body.chi_dmm_styles .chi_mmc_activated #et_search_icon:before, body.chi_dmm_styles .chi_mmc_activated #et_top_search .et-search-form input, body.chi_dmm_styles .chi_mmc_activated .et_search_form_container input, body.chi_dmm_styles .chi_mmc_activated .et_close_search_field:after, body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated #et-top-navigation .et-cart-info {color: ' + newval + ' !important;} body.chi_dmm_styles .chi_mmc_activated .et_search_form_container input::-moz-placeholder {color: ' + newval + ' !important;} body.chi_dmm_styles .chi_mmc_activated .et_search_form_container input::-webkit-input-placeholder {color: ' + newval + ' !important;} body.chi_dmm_styles .chi_mmc_activated .et_search_form_container input:-ms-input-placeholder {color: ' + newval + ' !important;} } </style>',
				style_id = 'style#chimmc_header_text_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    //Update mobile menu bar background color
	wp.customize( 'et_divi[chimmc_menu_bar_bg_color]', function( value ) {
		value.bind( function( newval ) {
			var $style_content = '<style id="chimmc_menu_bar_bg_color">@media all and (max-width: 980px) {.chi_dmm_styles.et_header_style_split #main-header .mobile_nav,.chi_dmm_styles.et_header_style_centered #main-header .mobile_nav {background-color: ' + newval + ' !important;}} </style>',
				style_id = 'style#chimmc_menu_bar_bg_color';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
    
    // show menu if search icon is disabled when search form was visible(for Centered and Split headers)
	wp.customize( 'et_divi[chimmc_search_icon]', function( value ) {
		value.bind( function( newval ) {
			if ( $('#et_mobile_nav_menu').is(':visible')  && ( false === newval ) && $('.container.et_search_form_container').hasClass('et_pb_search_visible')){
                
                $('.container.et_search_form_container').removeClass('et_pb_search_visible').addClass('et_pb_search_form_hidden');
                
                $('#main-header .container.et_menu_container').removeClass('et_pb_menu_hidden ').addClass('et_pb_menu_visible ');
                
            }
            
	       } );
	} );
    // end menu header options
    
    // SINCE v2.0
    
    // menu icons
    
    // update menu item icons
    $( document ).ready(function() {
     
        function chimmc_menu_item_icons( nested_value ){ 
            
            /**
             * Add/Remove menu icons related CSS classes to/form body
             */
            wp.customize( 'et_divi[' + nested_value + ']', function( value ) {
                value.bind( function( newval ) {

                    var chimmc_icons_on_off = wp.customize('et_divi[chimmc_icons_on_off]').get();
                    var chimmc_icons_position = wp.customize('et_divi[chimmc_icons_position]').get();
                    var chimmc_align_icons_left = wp.customize('et_divi[chimmc_align_icons_left]').get();
                    var chimmc_align_icons_right = wp.customize('et_divi[chimmc_align_icons_right]').get();
                    var chidmm_text_align = wp.customize('et_divi[chidmm_text_align]').get();

                    // enable/disable menu icons
                    if ( chimmc_icons_on_off == 'enabled' ) {
                        $( 'body' ).addClass( 'chimmc_icons_enabled' );
                    } else {
                        $( 'body' ).removeClass( 'chimmc_icons_enabled' );
                    }

                    // add/remove menu icons position classes to/from body
                    if ( $( 'body' ).hasClass( 'chimmc_icons_enabled' ) ) {

                        if ( chimmc_icons_position == 'before' ) {

                                $( 'body' ).addClass( 'chimmc_icons_left' ).removeClass( 'chimmc_icons_right' );

                            } else if ( chimmc_icons_position == 'after' ) {

                                    $( 'body' ).addClass( 'chimmc_icons_right' ).removeClass( 'chimmc_icons_left' );

                                }

                    } else if ( !$( 'body' ).hasClass( 'chimmc_icons_enabled' ) ) { 

                            if ( $( 'body' ).hasClass( 'chimmc_icons_right' ) || $( 'body' ).hasClass( 'chimmc_icons_left' ) ) {

                                $( 'body' ).removeClass( 'chimmc_icons_right chimmc_icons_left' );

                            }
                        }

                    // add/remove menu icons left alignment class to/from body
                    if ( $( 'body' ).hasClass( 'chimmc_icons_left' ) ) {

                        if ( true === chimmc_align_icons_left ) {

                            $( 'body' ).addClass( 'chimmc_icons_aligned_left' );

                        } else {

                                $( 'body' ).removeClass( 'chimmc_icons_aligned_left' );

                            }

                    } else {

                            $( 'body' ).removeClass( 'chimmc_icons_aligned_left' );

                        }

                    // add/remove menu icons right alignment class to/from body
                    if ( $( 'body' ).hasClass( 'chimmc_icons_right' ) ) {

                        if ( true === chimmc_align_icons_right ) {

                            $( 'body' ).addClass( 'chimmc_icons_aligned_right' );

                        } else {

                                $( 'body' ).removeClass( 'chimmc_icons_aligned_right' );

                            }

                    } else {

                            $( 'body' ).removeClass( 'chimmc_icons_aligned_right' );

                        }
                    
                    // add/remove menu text alignment classes to/from body
                    if ( chidmm_text_align == 'left' ) {

                        $( 'body' ).addClass( 'chimmc_text_left' ).removeClass( 'chimmc_text_center chimmc_text_right' );

                        } else if ( chidmm_text_align == 'center' ) {

                            $( 'body' ).addClass( 'chimmc_text_center' ).removeClass( 'chimmc_text_left chimmc_text_right' );

                            } else if ( chidmm_text_align == 'right' ) {

                                $( 'body' ).addClass( 'chimmc_text_right' ).removeClass( 'chimmc_text_left chimmc_text_center' );

                                }                   
                   } );
            } ); 
            // end adding/removing menu icons related CSS classes to/form body 
            
            /**
             * Update mobile menu text alignment
             */
            wp.customize( 'et_divi[' + nested_value + ']', function( value ) {
                value.bind( function( newval ) {
                    
                    var newval = wp.customize('et_divi[chidmm_text_align]').get();

                    if ( newval !== 'right' ){
                    var $style_content = '<style id="chidmm_text_align">@media all and (max-width: 980px) { body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .mobile_nav ul#mobile_menu.et_mobile_menu li:not([class^="et_pb_"]) a, body:not(.et_header_style_fullscreen).chi_dmm_styles ul#mobile_menu_slide.et_mobile_menu li a {text-align: ' + newval + ' !important;} body:not(.et_header_style_fullscreen).chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu .menu-item-has-children > a span.chimmc_mobile_menu_arrow, body:not(.et_header_style_fullscreen).chi_dmm_styles .et_slide_in_menu_container span.et_mobile_menu_arrow {right: 0px !important;left: auto !important;}}</style>';} else {var $style_content = '<style id="chidmm_text_align"> @media all and (max-width: 980px) { body:not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .mobile_nav ul#mobile_menu.et_mobile_menu li:not([class^="et_pb_"]) a, body:not(.et_header_style_fullscreen).chi_dmm_styles ul#mobile_menu_slide.et_mobile_menu li a {text-align: ' + newval + ' !important;} body:not(.et_header_style_fullscreen).chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu .menu-item-has-children > a span.chimmc_mobile_menu_arrow, body:not(.et_header_style_fullscreen).chi_dmm_styles .et_slide_in_menu_container span.et_mobile_menu_arrow {left: 0px !important;right: auto !important;}}</style>';}
                        style_id = 'style#chidmm_text_align';

                    et_customizer_update_styles( style_id, $style_content );
                   } );
            } );
            // end mobile menu text alignment
            
            /**
             *  menu item padding and icon size
             */
            function chimmc_item_padding ( value ) {

                padding = '';

                chimmc_menu_icons_size = wp.customize('et_divi[chimmc_menu_icons_size]').get();

                Top = wp.customize('et_divi[chimmc_item_padding_top]').get();
                Right = wp.customize('et_divi[chimmc_item_padding_right]').get();
                Bottom = wp.customize('et_divi[chimmc_item_padding_bottom]').get();
                Left = wp.customize('et_divi[chimmc_item_padding_left]').get();

                // adjust menu item left and right paddings depending on icon size
                chimmc_item_padding_l_adjusted = ( ( $('body').hasClass('chimmc_text_left') && $('body').hasClass('chimmc_icons_left') ) || ( $('body').hasClass('et_header_style_fullscreen') && $('body').hasClass('chimmc_icons_left') ) ) ? parseInt( ( chimmc_menu_icons_size ) ) + parseInt( Left ) : Left;

                chimmc_item_padding_r_adjusted = ( ( $('body').hasClass('chimmc_text_right') && $('body').hasClass('chimmc_icons_right') ) || ( $('body').hasClass('et_header_style_fullscreen') && $('body').hasClass('chimmc_icons_right') ) ) ? parseInt( ( chimmc_menu_icons_size ) ) + parseInt( Right ) : Right;
                
                // adjust PARENT menu item arrow left and right paddings depending on icon & text position
                chimmc_parent_item_pad_l_adjusted =  ( $('body').is('.chimmc_text_right.chimmc_icons_aligned_left') && $('#main-header li.menu-item').hasClass('menu-item-has-children') ) ? parseInt( ( chimmc_menu_icons_size ) ) + parseInt( Left ) : Left;
                
                chimmc_parent_item_pad_r_adjusted =  ( ( $('body').is('.chimmc_text_left.chimmc_icons_aligned_right') || $('body').is('.chimmc_text_center.chimmc_icons_aligned_right') ) && $('#main-header li.menu-item').hasClass('menu-item-has-children') ) ? parseInt( ( chimmc_menu_icons_size ) ) + parseInt( Right ) : Right;


                padding = Top + 'px ' + chimmc_item_padding_r_adjusted + 'px ' + Bottom + 'px '+ chimmc_item_padding_l_adjusted + 'px ';

                return padding;
            }

            wp.customize( 'et_divi[' + nested_value + ']' , function itemPaddingLive ( value ) {
                value.bind( function( to ) {

                   var padding = chimmc_item_padding( to );

                    var $style_content = '<style id="chimmc_item_padding">@media all and (max-width: 980px) {body.chi_dmm_styles .chi_mmc_activated .mobile_nav ul#mobile_menu.et_mobile_menu li:not(.CTA-button).chimmc-has-icon > a, body.chi_dmm_styles ul#mobile_menu_slide.et_mobile_menu li:not(.CTA-button).chimmc-has-icon > a {padding: ' + padding + ' !important;} \
                    body.chi_dmm_styles .chi_mmc_activated .mobile_nav ul#mobile_menu.et_mobile_menu li:not([class^="et_pb_"]):not(.chimmc-has-icon) > a, body.chi_dmm_styles ul#mobile_menu_slide.et_mobile_menu li:not([class^="et_pb_"]):not(.chimmc-has-icon) > a {padding: ' + Top + 'px ' + Right + 'px ' + Bottom + 'px '+ Left + 'px !important;} \
                    body.chi_dmm_styles.et_header_style_slide ul#mobile_menu_slide.et_mobile_menu li:not(.CTA-button) > a .et_mobile_menu_arrow { margin-left: ' + Left + 'px !important; margin-right: ' + Right + 'px !important;} \
                    .chimmc_icons_aligned_left #main-header.chi_mmc_activated .et_mobile_menu li:not(.CTA-button).menu-item-has-children.chimmc-has-icon > a span.chimmc_mobile_menu_arrow, .et_header_style_slide.chimmc_icons_aligned_left ul#mobile_menu_slide.et_mobile_menu li:not(.CTA-button).chimmc-has-icon > a .et_mobile_menu_arrow {\
                        margin-left: ' + chimmc_parent_item_pad_l_adjusted + 'px !important;} \
                    .chimmc_icons_aligned_right #main-header.chi_mmc_activated .et_mobile_menu li:not(.CTA-button).menu-item-has-children.chimmc-has-icon > a span.chimmc_mobile_menu_arrow,\
                    .et_header_style_slide.chimmc_icons_aligned_right ul#mobile_menu_slide.et_mobile_menu li:not(.CTA-button).chimmc-has-icon > a .et_mobile_menu_arrow {\
                        margin-right: ' + chimmc_parent_item_pad_r_adjusted + 'px !important;} \
                    body.chi_dmm_styles #main-header li:not([class^="et_pb_"]) a:before, body.chi_dmm_styles #main-header li:not([class^="et_pb_"]) a:after, body.chi_dmm_styles #top-header #et-secondary-nav li.menu-item a:before, body.chi_dmm_styles #top-header #et-secondary-nav li.menu-item a:after, body.chi_dmm_styles .et_slide_in_menu_container #mobile_menu_slide a:before, body.chi_dmm_styles .et_slide_in_menu_container #mobile_menu_slide a:after {font-size: ' + chimmc_menu_icons_size + 'px !important;}} </style>',
                        style_id = 'style#chimmc_item_padding';

                    et_customizer_update_styles( style_id, $style_content );

                } );

            } );

            // end menu item padding and icon size
            
            /**
             *  menu item icon and pseudo elements
             */
            // loop through menu items
            $('#main-header li:not([class^="et_pb_"]), #top-header li.sec_menu_item').filter(function () {

                return this.className.match(/\bchimmc-menu-item_/);

            }).each(function( ) {

                // extract the menu item CSS class containing the menu item id
                var className = select_css_class_starting_with( $(this), 'chimmc-menu-item_' );
                // get the menu item id by slicing the prefix 'chimmc-menu-item_'
                var id = className.slice(17);

                // add/remove menu item icons
                wp.customize( 'et_divi[' + nested_value + ']', function( value ) { 
                    value.bind( function( newval ) {

                    icon_before_after = wp.customize('et_divi[chimmc_icons_position]').get();
                        
                    empty_pseudo_element = ( icon_before_after == 'before' ) ? 'after' : 'before';

                    newval = wp.customize('et_divi[chimmc_menu_icon_' + id + ']').get();
                        
                        if ( newval == '' ) {
                            $('#main-header .et_mobile_menu li.chimmc-menu-item_' + id + ', .et_slide_in_menu_container .et_mobile_menu li.chimmc-menu-item_' + id ).removeClass('chimmc-has-icon');
                            
                        } else {
                            $('#main-header .et_mobile_menu li.chimmc-menu-item_' + id + ', .et_slide_in_menu_container .et_mobile_menu li.chimmc-menu-item_' + id ).addClass('chimmc-has-icon');
                        }
                        
                    quotes = ( newval == '"' || newval == '\\') ? "'" : '"' ;
                    backslash = ( newval == '\\' ) ? '\\' : '' ;

                        var $style_content = '<style id="chimmc_menu_icon_' + id + '">@media all and (max-width: 980px) {\
                        .chi_dmm_styles.chimmc_icons_enabled .menu-item-' + id + '.chimmc-has-icon > a:' + icon_before_after + ' {content: ' + quotes + '' + backslash + '' + newval + '' + quotes + ' !important;}\
                        .chi_dmm_styles.chimmc_icons_enabled .menu-item-' + id + '.chimmc-has-icon > a:' + empty_pseudo_element + ' {content: "" !important;}} </style>',
                            style_id = 'style#chimmc_menu_icon_' + id + '';

                        et_customizer_update_styles( style_id, $style_content );
                        
                        
                       } );
                } );

            });
            // end looping through menu items
            // end menu item icon and pseudo elements
        }
        
        // enable/disable menu icons
        chimmc_menu_item_icons ( 'chimmc_icons_on_off' );

        // add/remove menu icons position classes to/from body
        chimmc_menu_item_icons ( 'chimmc_icons_position' );

        // add/remove menu icons left alignment class to/from body
        chimmc_menu_item_icons ( 'chimmc_align_icons_left' );

        // add/remove menu icons right alignment class to/from body
        chimmc_menu_item_icons ( 'chimmc_align_icons_right' );
        
        // select a CSS class that starts with a specific prefix
        function select_css_class_starting_with(element, class_starts_with) {

            var result = undefined;
            $(element.attr('class').split(' ')).each(function() {

                if (this.indexOf(class_starts_with) > -1) result = this;
            });
            return result;
        }

        // select elements that have a CSS class having the 'chimmc-menu-item_' prefix
        $('[class*=chimmc-menu-item_]').each(function() {
            
            // extract the menu item CSS class containing the menu item id
			var className = select_css_class_starting_with( $(this), 'chimmc-menu-item_' );
            
            // get the menu item id by slicing the prefix 'chimmc-menu-item_'
            var id = className.slice(17);
            
            // update menu item icon
            chimmc_menu_item_icons ( 'chimmc_menu_icon_' + id + '' );
            
		});
     
        // menu item top padding
        chimmc_menu_item_icons ( 'chimmc_item_padding_top' );
        
        // menu item right padding
        chimmc_menu_item_icons ( 'chimmc_item_padding_right' );
        
        // menu item bottom padding
        chimmc_menu_item_icons ( 'chimmc_item_padding_bottom' );
        
        // menu item left padding
        chimmc_menu_item_icons ( 'chimmc_item_padding_left' );
        
        // menu item icon size
        chimmc_menu_item_icons ( 'chimmc_menu_icons_size' );
        
        // menu item text alignment
        chimmc_menu_item_icons ( 'chidmm_text_align' );
               
    });
      
    // end menu icons 
    
    // toggle submenus
    
    // add/remove chimmc_toggle_submenus class
	wp.customize( 'et_divi[chimmc_toggle_submenus]', function( value ) {
		value.bind( function( newval ) {     
			
            if(true === newval){
                
                $('body').addClass('chimmc_toggle_submenus');
                // collapse all expanded submenus
                $('#main-header #mobile_menu li.menu-item-has-children').addClass('hidden_sub').removeClass('visible');
                
            } else {
                $('body').removeClass('chimmc_toggle_submenus');
            }
            
	       } );
	} );
    
    // end toggling submenus
    
    /**
     *  submenu animation
     */
    function chimmc_submenu_animation ( value ) {

        animation_name = wp.customize('et_divi[chimmc_submenu_animation]').get();
        animation_duration = wp.customize('et_divi[chimmc_submenu_animation_speed]').get();

        animation_and_duration = animation_name + ' ' + animation_duration ;

        return animation_and_duration;
    }
      
    function chimmc_submenu_animation_preview ( setting ) {
        
        wp.customize( 'et_divi[' + setting + ']' , function AnimationLive ( value ) {
            value.bind( function( to ) {

               var animation_and_duration = chimmc_submenu_animation( to );

                var $style_content = '<style id="chimmc_submenu_animation">#main-header .et_mobile_menu.chidmm_collapsable li.visible > ul.sub-menu {\
                    -webkit-animation: ' + animation_and_duration + 's ease-in-out forwards !important;\
                    animation: ' + animation_and_duration + 's ease-in-out forwards !important; } </style>',
                    style_id = 'style#chimmc_submenu_animation';

                et_customizer_update_styles( style_id, $style_content );

            } );

        } );
    
    }
    
    // dotnav bg animation name
    chimmc_submenu_animation_preview ( 'chimmc_submenu_animation' );
    // dotnav bg animation duration
    chimmc_submenu_animation_preview ( 'chimmc_submenu_animation_speed' );
    
    // end submenu animation
    
    // parent item arrow
    
    // add/remove chimmc_arrow_custom class
	wp.customize( 'et_divi[chimmc_arrow_styles_on]', function( value ) {
		value.bind( function( newval ) {     
			
            if(true === newval){
                
                $('body').addClass('chimmc_arrow_custom');
                
            } else {
                $('body').removeClass('chimmc_arrow_custom');
            }
            
	       } );
	} );
    
    // apply parent item arrow styles
    function chimmc_parent_arrow_styles($setting) {
        wp.customize( 'et_divi[' + $setting + ']', function( value ) {
		value.bind( function( newval ) {
            
        chimmc_parent_arrow = wp.customize('et_divi[chimmc_parent_arrow]').get();
            // adjust quotation mark for arrow content
            arr_quotes = ( chimmc_parent_arrow == '"' || chimmc_parent_arrow == "'" ) ? "'" : '"' ;
            arr_backslash = ( chimmc_parent_arrow == '\\' || chimmc_parent_arrow == "'" ) ? '\\' : '' ;
            
        chimmc_parent_arrow_rotate = wp.customize('et_divi[chimmc_parent_arrow_rotate]').get();
        chimmc_parent_arrow_size = wp.customize('et_divi[chimmc_parent_arrow_size]').get();
        chimmc_parent_arrow_color = wp.customize('et_divi[chimmc_parent_arrow_color]').get();
        chimmc_a_parent_arrow_color = wp.customize('et_divi[chimmc_a_parent_arrow_color]').get();
        chimmc_parent_arrow_bg_color = wp.customize('et_divi[chimmc_parent_arrow_bg_color]').get();
        chimmc_parent_arrow_brdr_color = wp.customize('et_divi[chimmc_parent_arrow_brdr_color]').get();
        
        chimmc_parent_arrow_pad_t = wp.customize('et_divi[chimmc_parent_arrow_padding_top]').get();
        chimmc_parent_arrow_pad_r = wp.customize('et_divi[chimmc_parent_arrow_padding_right]').get();
        chimmc_parent_arrow_pad_b = wp.customize('et_divi[chimmc_parent_arrow_padding_bottom]').get();
        chimmc_parent_arrow_pad_l = wp.customize('et_divi[chimmc_parent_arrow_padding_left]').get();
        // parent item arrow bg padding
        chimmc_parent_arrow_padding = chimmc_parent_arrow_pad_t + 'px ' + chimmc_parent_arrow_pad_r + 'px ' + chimmc_parent_arrow_pad_b + 'px ' + chimmc_parent_arrow_pad_l + 'px';
        
        chimmc_parent_arrow_brdr_t = wp.customize('et_divi[chimmc_parent_arrow_brdr_t_width]').get();
        chimmc_parent_arrow_brdr_r = wp.customize('et_divi[chimmc_parent_arrow_brdr_r_width]').get();
        chimmc_parent_arrow_brdr_b = wp.customize('et_divi[chimmc_parent_arrow_brdr_b_width]').get();
        chimmc_parent_arrow_brdr_l = wp.customize('et_divi[chimmc_parent_arrow_brdr_l_width]').get();
        // parent item arrow bg border width
        chimmc_parent_arrow_brdr_width = chimmc_parent_arrow_brdr_t + 'px ' + chimmc_parent_arrow_brdr_r + 'px ' + chimmc_parent_arrow_brdr_b + 'px ' + chimmc_parent_arrow_brdr_l + 'px';
        
        chimmc_parent_arrow_brdr_tl_radius = wp.customize('et_divi[chimmc_parent_arrow_brdr_tl_radius]').get();
        chimmc_parent_arrow_brdr_tr_radius = wp.customize('et_divi[chimmc_parent_arrow_brdr_tr_radius]').get();
        chimmc_parent_arrow_brdr_br_radius = wp.customize('et_divi[chimmc_parent_arrow_brdr_br_radius]').get();
        chimmc_parent_arrow_brdr_bl_radius = wp.customize('et_divi[chimmc_parent_arrow_brdr_bl_radius]').get();
        
        // parent item arrow bg border radius
        chimmc_parent_arrow_brdr_radius = chimmc_parent_arrow_brdr_tl_radius + 'px ' + chimmc_parent_arrow_brdr_tr_radius + 'px ' + chimmc_parent_arrow_brdr_br_radius + 'px ' + chimmc_parent_arrow_brdr_bl_radius + 'px';
            
			var $style_content = '<style id="chimmc_parent_arrow_styles">@media all and (max-width: 980px) {.chimmc_arrow_custom span.chimmc_mobile_menu_arrow, .chimmc_arrow_custom .et_slide_in_menu_container span.et_mobile_menu_arrow {\
                background-color: ' + chimmc_parent_arrow_bg_color + ' !important;\
                border-width: ' + chimmc_parent_arrow_brdr_width + ';\
                border-color: ' + chimmc_parent_arrow_brdr_color + ';\
                border-radius: ' + chimmc_parent_arrow_brdr_radius + ';\
                padding: ' + chimmc_parent_arrow_padding + ';}\
            .chimmc_arrow_custom span.chimmc_mobile_menu_arrow:before, .chimmc_arrow_custom ul.sub-menu a span.chimmc_mobile_menu_arrow:before, .chimmc_arrow_custom .et_slide_in_menu_container #mobile_menu_slide .et_mobile_menu_arrow:before, .chimmc_arrow_custom .et_slide_in_menu_container #mobile_menu_slide li ul.sub-menu li span.et_mobile_menu_arrow::before, .chimmc_arrow_custom.et_header_style_slide #mobile_menu_slide > li:not(.CTA-button) > a > span.et_mobile_menu_arrow:before, .chimmc_arrow_custom.et_header_style_fullscreen #mobile_menu_slide > li:not(.CTA-button) > a > span.et_mobile_menu_arrow:before {\
                content: ' + arr_quotes + arr_backslash + chimmc_parent_arrow + arr_quotes + ';\
                font-size: ' + chimmc_parent_arrow_size + 'px !important;\
                color: ' + chimmc_parent_arrow_color + ' !important;}\
            .chimmc_arrow_custom .current-menu-item > a > .chimmc_mobile_menu_arrow:before, .chimmc_arrow_custom .current-menu-parent > a > .chimmc_mobile_menu_arrow:before, .chimmc_arrow_custom .current-menu-ancestor > a > .chimmc_mobile_menu_arrow:before, .chimmc_arrow_custom #mobile_menu_slide li:not(.CTA-button).current-menu-item > a > span.et_mobile_menu_arrow:before, .chimmc_arrow_custom #mobile_menu_slide li:not(.CTA-button).current-menu-parent > a > span.et_mobile_menu_arrow:before, .chimmc_arrow_custom #mobile_menu_slide li:not(.CTA-button).current-menu-ancestor > a > span.et_mobile_menu_arrow:before {\
                color: ' + chimmc_a_parent_arrow_color + ' !important;}\
            .chimmc_arrow_custom .sub-menu .current-menu-item > a > .chimmc_mobile_menu_arrow:before, .chimmc_arrow_custom .sub-menu .current-menu-parent > a > .chimmc_mobile_menu_arrow:before, .chimmc_arrow_custom .sub-menu .current-menu-ancestor > a > .chimmc_mobile_menu_arrow:before, .chimmc_arrow_custom .et_slide_in_menu_container #mobile_menu_slide .sub-menu li.current-menu-item span.et_mobile_menu_arrow::before, .chimmc_arrow_custom .et_slide_in_menu_container #mobile_menu_slide .sub-menu li.current-menu-parent > a > span.et_mobile_menu_arrow::before, .chimmc_arrow_custom .et_slide_in_menu_container #mobile_menu_slide .sub-menu li.current-menu-ancestor > a > span.et_mobile_menu_arrow::before {\
                color: ' + chimmc_a_parent_arrow_color + ' !important;}\
            .chimmc_arrow_custom .menu-item-has-children.visible > a > span.chimmc_mobile_menu_arrow:before, .chimmc_arrow_custom .et_slide_in_menu_container span.et_pb_submenu_opened.et_mobile_menu_arrow:before {\
                -webkit-transform: rotate(' + chimmc_parent_arrow_rotate + 'deg);\
                -ms-transform: rotate(' + chimmc_parent_arrow_rotate + 'deg);\
                transform: rotate(' + chimmc_parent_arrow_rotate + 'deg);}} </style>',
            
            style_id = 'style#chimmc_parent_arrow_styles';
				
			et_customizer_update_styles( style_id, $style_content );
	       } );
	} );
        
    }
    
    // apply parent arrow styles
    chimmc_parent_arrow_styles('chimmc_arrow_styles_on');
    // parent arrow icon
    chimmc_parent_arrow_styles('chimmc_parent_arrow');
    // parent arrow icon rotate
    chimmc_parent_arrow_styles('chimmc_parent_arrow_rotate');
    // parent arrow icon size
    chimmc_parent_arrow_styles('chimmc_parent_arrow_size');
    // parent arrow icon color
    chimmc_parent_arrow_styles('chimmc_parent_arrow_color');
    // active parent arrow icon color
    chimmc_parent_arrow_styles('chimmc_a_parent_arrow_color');
    // parent arrow icon background color
    chimmc_parent_arrow_styles('chimmc_parent_arrow_bg_color');
    // parent arrow icon border color
    chimmc_parent_arrow_styles('chimmc_parent_arrow_brdr_color');
    // parent arrow top padding
    chimmc_parent_arrow_styles('chimmc_parent_arrow_padding_top');
    // parent arrow right padding
    chimmc_parent_arrow_styles('chimmc_parent_arrow_padding_right');
    // parent arrow bottom padding
    chimmc_parent_arrow_styles('chimmc_parent_arrow_padding_bottom');
    // parent arrow left padding
    chimmc_parent_arrow_styles('chimmc_parent_arrow_padding_left');
    // parent arrow border-top width
    chimmc_parent_arrow_styles('chimmc_parent_arrow_brdr_t_width');
    // parent arrow border-right width
    chimmc_parent_arrow_styles('chimmc_parent_arrow_brdr_r_width');
    // parent arrow border-bottom width
    chimmc_parent_arrow_styles('chimmc_parent_arrow_brdr_b_width');
    // parent arrow border-left width
    chimmc_parent_arrow_styles('chimmc_parent_arrow_brdr_l_width');
    // parent arrow border top-left radius
    chimmc_parent_arrow_styles('chimmc_parent_arrow_brdr_tl_radius');
    // parent arrow border top-right radius
    chimmc_parent_arrow_styles('chimmc_parent_arrow_brdr_tr_radius');
    // parent arrow border bottom-right radius
    chimmc_parent_arrow_styles('chimmc_parent_arrow_brdr_br_radius');
    // parent arrow border bottom-left radius
    chimmc_parent_arrow_styles('chimmc_parent_arrow_brdr_bl_radius');
    
    // end parent item arrow
    
} )( jQuery );