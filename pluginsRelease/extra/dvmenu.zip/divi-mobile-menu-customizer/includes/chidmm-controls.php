<?php 

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// DMM Customizer panel, sections and controls
function chidmm_customizer_plugin_settings( $wp_customize ) {
    
    if ( class_exists( 'WP_Customize_Control' ) ) {

        /**
         * Class for Divi Library layouts dropdown list
         */
        class Chi_MMC_PB_Layouts_Dropdown_Control extends WP_Customize_Control
        {
            private $posts = false;
            public function __construct($manager, $id, $args = array(), $options = array())
            {
                $type = 'et_pb_layout';
                $postargs = wp_parse_args($options, array('post_type' => $type,'numberposts' => '-1'));
                $this->posts = get_posts($postargs);
                parent::__construct( $manager, $id, $args );
            }
            /**
            * Render the content
            */
            public function render_content()
            {
                if(!empty($this->posts))
                {
                    ?>
                        <label class="">
                            <span class="customize-post-dropdown chimmc-customize-layouts-dropdown customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                            <select name="<?php echo $this->id; ?>" id="<?php echo $this->id; ?>" <?php $this->link(); ?>>
                            <?php
                                foreach ( $this->posts as $post ) {
                                    
                                    $post_title = $post->post_title;
                                    $post_ID = $post->ID;

                                        echo '<option value="' . esc_attr( $post_ID ) . '"' . selected( $this->value(), $post_ID, false ).'>' . esc_html( $post_title ) . '</option>';
                                    
                                }
                            ?>
                            </select>
                        </label>
                    <?php
                }
            }
        }    
        
        /**
         * Range-based sliding value picker for Customizer Multiple Input Option
         */

        class Chi_DMM_Multi_Input_Option extends WP_Customize_Control {

            public $html = array();
            
            public $type = 'range';

            public function build_field_html( $key, $setting ) {
                
                $value = '';
                
                if ( isset( $this->settings[ $key ] ) ) {
                    
                    $value = $this->settings[ $key ]->value();
                    
                    $default = $this->settings[ $key ]->default;
                    
                    $this->html[] = '
                    
                    <div class="chidmm-multi-box-control-input">
                    
                    <input type="number" class="et-pb-range-input" min="'.$this->input_attrs['min'].'" max="'.$this->input_attrs['max'].'" step="'.$this->input_attrs['step'].'" value="'.$value.'" />
                    
                    <span class="chidmm_reset_slider"></span>
                    
                    <input type="'.esc_attr( $this->type ).'" class="chidmm-multi-box-slider" min="'.$this->input_attrs['min'].'" max="'.$this->input_attrs['max'].'" step="'.$this->input_attrs['step'].'" value="'.$value.'" '.$this->get_link( $key ).' data-reset_value="'.$default.'" />
                    
                    </div>
                    ';
                }
            }

            public function render_content() {
                $output =  '<label class="chidmm-multi-box-control-label">' . $this->label .'</label><span class="chidmm-multi-box-label-container">';
                
                echo $output;
                
                foreach( $this->choices as $key => $value ) {
                    echo '<div class="chidmm-multi-box-label">'.esc_attr($value).'</div>';
                };
                
                
                foreach( $this->settings as $key => $value ) {
                    $this->build_field_html( $key, $value );
                }
                echo implode( '', $this->html );
            }

        }
        
        /* End Chi_DMM_Multi_Input_Option class */
        
        //Class for Custom Textarea Control
        class Chi_DMM_Textarea_Control extends WP_Customize_Control {
                public $type = 'textarea';

                public function render_content() {
                    ?>
                <label>
                    <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                    <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
                    <textarea rows="1" style="width:100%;" <?php $this->link(); ?>><?php echo esc_textarea( $this->value() ); ?></textarea>
                </label>
                <?php
                }
            }
        //Class for Custom Text Input Control
        class Chi_DMM_Text_Input_Control extends WP_Customize_Control {
                public $type = 'textinput';

                public function render_content() {
                    ?>
                <label>
                    <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                    <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
                    <input type="text" style="width:100%;" <?php $this->link(); ?><?php echo esc_html( $this->value() ); ?>>
                </label>
                <?php
                }
            }
        
        // parent item arrow icons set
        
        if ( ! function_exists( 'chimmc_p_get_font_icon_symbols' ) ) :
        function chimmc_p_get_font_icon_symbols() {
            $symbols = array( '&amp;#x21;', '&amp;#x22;', '&amp;#x23;', '&amp;#x24;', '&amp;#x32;', '&amp;#x33;', '&amp;#x34;', '&amp;#x35;', '&amp;#x36;', '&amp;#x37;', '&amp;#x38;', '&amp;#x39;', '&amp;#x3a;', '&amp;#x3b;', '&amp;#x3c;', '&amp;#x3d;', '&amp;#x3e;', '&amp;#x3f;', '&amp;#x40;', '&amp;#x41;', '&amp;#x42;', '&amp;#x43;', '&amp;#x44;', '&amp;#x45;', '&amp;#x46;', '&amp;#x47;', '&amp;#x48;', '&amp;#x49;', '&amp;#x4c;', '&amp;#x4d;', '&amp;#x50;', '&amp;#x51;', '&amp;#xe039;', '&amp;#xe03a;', '&amp;#xe03b;', '&amp;#xe03c;', '&amp;#xe043;', '&amp;#xe044;', '&amp;#xe045;', '&amp;#xe046;', '&amp;#xe047;', '&amp;#xe048;', '&amp;#xe049;', '&amp;#xe04a;', '&amp;#xe04b;', '&amp;#xe04c;', '&amp;#xe04d;', '&amp;#xe04e;', '&amp;#xe050;', '&amp;#xe051;', );

            $symbols = apply_filters( 'chimmc_p_font_icon_symbols', $symbols );

            return $symbols;
        }
        endif;
        if ( ! function_exists( 'chimmc_p_get_font_icon_list' ) ) :
        function chimmc_p_get_font_icon_list() {
            $output = is_customize_preview() ? chimmc_p_get_font_icon_list_items() : '<%= window.et_builder.font_icon_list_template() %>';

            $output = sprintf( '<ul class="et_font_icon">%1$s</ul>', $output );

            return $output;
        }
        endif;

        if ( ! function_exists( 'chimmc_p_get_font_icon_list_items' ) ) :
        function chimmc_p_get_font_icon_list_items() {
            $output = '';

            $symbols = chimmc_p_get_font_icon_symbols();

            foreach ( $symbols as $symbol ) {
                $output .= sprintf( '<li data-icon="%1$s"></li>', esc_attr( $symbol ) );
            }

            return $output;
        }
        endif;

        if ( ! function_exists( 'chimmc_p_font_icon_list' ) ) :
            function chimmc_p_font_icon_list() {
                echo chimmc_p_get_font_icon_list();
            }
        endif;
        
        // end icon set

        /**
         * Icon picker control for Customizer
         */
        class Chi_MMC_Arrow_Icon_Picker_Option extends WP_Customize_Control {
            public $type = 'icon_picker';

            public function render_content() {

            ?>
            <label>
                <?php if ( ! empty( $this->label ) ) : ?>
                    <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                <?php endif;
                chimmc_p_font_icon_list(); ?>
                <input type="hidden" class="et_selected_icon" <?php $this->input_attrs(); ?> value="<?php echo esc_attr( $this->value() ); ?>" <?php $this->link(); ?> />
            </label>
            <?php
            }
        }
        
        
        // CONTROLS
        
        // section
        function chimmc_settings_section( $wp_customize, $settings_section, $title, $description, $priority, $panel ){
                $wp_customize->add_section( 
                    $settings_section, 
                    array(
                    'capability'     	=> 'edit_theme_options',
                    'title'          	=> esc_html__( $title ),
                    'description' 	 	=> esc_html__( $description ),
                    'priority'       	=> $priority,
                    'panel'  	 		=> $panel,
                    ) );
                }
        
        // arrow icon picker control
        function chimmc_arrow_icon_picker_control ($wp_customize, $setting, $default, $transport, $label, $section, $priority, $description ){
            
        // Add a setting for 1st menu item icon
            $wp_customize->add_setting( 'et_divi['.$setting.']', array(
                'default'       => $default,
                'type'          => 'option',
                'capability'    => 'edit_theme_options',
                'transport'     => $transport,
                'sanitize_callback' => 'et_sanitize_font_icon',
            ) );
        // Add a control to change 1st menu item icon
            $wp_customize->add_control( new Chi_MMC_Arrow_Icon_Picker_Option ( $wp_customize, 'et_divi['.$setting.']', array(
                        'label'	        => esc_html__( $label ),
                        'section'       => $section,
                        'settings'      => 'et_divi['.$setting.']',
                        'priority' 	    => $priority,
                        'type'          => 'icon_picker',
                        'description' 	=> esc_html__( $description )
            ) ) );
        }
        
        // select control
        function chimmc_choices_select_control( $wp_customize, $setting, $default, $transport, $label, $section, $priority, $description, $choices ) {
            
            $wp_customize->add_setting( 'et_divi['.$setting.']', array(
                    'default'               => $default,
                    'type'			        => 'option',
                    'capability'	        => 'edit_theme_options',
                    'transport'		        => $transport,
                    'sanitize_callback'     => ''
                ) );
            $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'et_divi['.$setting.']', array(
                    'label'		            => esc_html__( $label, 'DMM' ),
                    'section'	            => $section,
                    'settings'              => 'et_divi['.$setting.']',
                    'priority' 		        => $priority,
                    'description'           => esc_html__( $description ),
                    'type'                  => 'select',
                    'choices'		        => $choices				
                    )));           
        }
        
        // layouts select control
        function chimmc_layouts_select_control( $wp_customize, $setting, $default, $transport, $label, $section, $priority, $description ) {
        
        $wp_customize->add_setting( 'et_divi['.$setting.']', array(
                                    'default'               => $default,
                                    'type'			        => 'option',
                                    'capability'	        => 'edit_theme_options',
                                    'transport'		        => $transport,
                                ) );

        $wp_customize->add_control( new Chi_MMC_PB_Layouts_Dropdown_Control( $wp_customize, 'et_divi['.$setting.']', array(
                                    'label'         => esc_html__( $label ),
                                    'type'          => 'select',
                                    'section'       => $section,
                                    'settings'      => 'et_divi['.$setting.']',
                                    'priority' 		=> $priority,
                                    'description'   => esc_html__( $description )
                                ) ) );
        
            
        }
        
        // alpha-color control
        function chimmc_alpha_color_control ($wp_customize, $setting, $default, $transport, $label, $section, $priority) {
            
            $wp_customize->add_setting( 'et_divi['.$setting.']', array(
                    'default'		=> $default,
                    'type'			=> 'option',
                    'capability'	=> 'edit_theme_options',
                    'transport'		=> $transport,
                    'sanitize_callback' => 'et_sanitize_alpha_color',
                ) );
            $wp_customize->add_control( new ET_Divi_Customize_Color_Alpha_Control( $wp_customize, 'et_divi['.$setting.']', 
                        array(
                            'label'		=> esc_html__( $label, 'DMM' ),
                            'section'	=> $section,
                            'settings'	=> 'et_divi['.$setting.']',
                            'priority'  => $priority
                    )));               
        }
            
        // range control
        function chimmc_range_control ($wp_customize, $setting, $default, $transport, $label, $section, $priority, $descritpion, $min, $max, $step){
            
            $wp_customize->add_setting('et_divi['.$setting.']',
                    array(
                        'default' 		       => $default,
                        'type'          	   => 'option',
                        'capability'    	   => 'edit_theme_options',
                        'transport' 		   => $transport,
                        'sanitize_callback'    => 'et_sanitize_int_number'
                        ));
            $wp_customize->add_control( new ET_Divi_Range_Option( $wp_customize, 'et_divi['.$setting.']',
                        array(
                                'label'             => esc_html__( $label ),
                                'section'           => $section,
                                'settings'          => 'et_divi['.$setting.']',
                                'priority' 		    => $priority,
                                'description'       => esc_html__($descritpion),
                                'type'              => 'range',
                                'input_attrs'       => array(
                                    'min'   => $min,
                                    'max'   => $max,
                                    'step'  => $step
                                ),
                            )));            
        }
        // float range control
        function chimmc_float_range_control ($wp_customize, $setting, $default, $transport, $label, $section, $priority, $descritpion, $min, $max, $step){
            
            $wp_customize->add_setting('et_divi['.$setting.']',
                    array(
                        'default' 		       => $default,
                        'type'          	   => 'option',
                        'capability'    	   => 'edit_theme_options',
                        'transport' 		   => $transport,
                        'sanitize_callback'    => 'et_sanitize_float_number'
                        ));
            $wp_customize->add_control( new ET_Divi_Range_Option( $wp_customize, 'et_divi['.$setting.']',
                        array(
                                'label'             => esc_html__( $label ),
                                'section'           => $section,
                                'settings'          => 'et_divi['.$setting.']',
                                'priority' 		    => $priority,
                                'description'       => esc_html__($descritpion),
                                'type'              => 'range',
                                'input_attrs'       => array(
                                    'min'   => $min,
                                    'max'   => $max,
                                    'step'  => $step
                                ),
                            )));            
        }
        // text field control
        function chimmc_text_field_control ($wp_customize, $setting, $default, $transport, $label, $section, $priority, $description ){
            
        // Add a textarea setting
            $wp_customize->add_setting('et_divi['.$setting.']',
                array(
                    'default' 		         => $default,
                    'type'          	     => 'option',
                    'capability'    	     => 'edit_theme_options',
                    'transport' 		     => $transport,
                    'sanitize_callback' 	 => 'et_sanitize_html_input_text',
                    )); 
        // Add a textarea control
            $wp_customize->add_control( new Chi_DMM_Text_Input_Control( $wp_customize, 'et_divi['.$setting.']', array(
                    'label'		             => esc_html__( $label ),
                    'section' 	             => $section,
                    'settings' 	             => 'et_divi['.$setting.']',
                    'priority' 		         => $priority,
                    'description' 		     => esc_html__( $description )
            ) ) ); 
        }
        
        // checkbox control
        function chimmc_checkbox_control ($wp_customize, $setting, $default, $transport, $label, $section, $priority, $description ){
        
        // Add a checkbox setting
            $wp_customize->add_setting( 'et_divi['.$setting.']', 
                array(
                    'default' 		=> $default,
                    'type'			=> 'option',
                    'capability'	=> 'edit_theme_options',
                    'transport'		=> $transport,
                    'sanitize_callback' => 'wp_validate_boolean',
                    ) );
        // Add a checkbox control
            $wp_customize->add_control( 'et_divi['.$setting.']', 
            array(
                    'label'		=> esc_html__( $label ),
                    'section'	=> $section,
                    'type'      => 'checkbox',
                    'settings' 	       => 'et_divi['.$setting.']',
                    'priority' 		   => $priority,
                    'description' 	   => esc_html__( $description )
            ) );
        }
        
        // font-style checkbox control
        function chimmc_font_style_checkbox_control ($wp_customize, $setting, $default, $transport, $label, $section, $priority, $description ){  
        
        // Add a checkbox setting
            $wp_customize->add_setting( 'et_divi['.$setting.']', array(
                    'default'               => $default,
                    'type'                  => 'option',
                    'capability'            => 'edit_theme_options',
                    'transport'             => $transport,
                    'sanitize_callback'     => 'et_sanitize_font_style',
                    ) );
        // Add a checkbox control
            $wp_customize->add_control( new ET_Divi_Font_Style_Option ( $wp_customize, 'et_divi['.$setting.']', array(
                    'label'	            => esc_html__( $label ),
                    'section'           => $section,
                    'settings'          => 'et_divi['.$setting.']',
                    'priority' 	        => $priority,
                    'type'              => 'font_style',
                    'choices'           => et_divi_font_style_choices(),
                    'description' 	    => esc_html__( $description )
            ) ) );
        }
        // multi-input control  
        function chimmc_multi_input_field_control ($wp_customize, $setting, $setting_1, $setting_2, $setting_3, $setting_4, $default_1, $default_2, $default_3, $default_4, $transport, $label, $section, $priority, $choice_1, $choice_2, $choice_3, $choice_4, $min, $max, $step){
        
            $wp_customize->add_setting( 'et_divi['.$setting_1.']', array(
                'default'        => $default_1,
                'type'           => 'option',
                'transport'      => $transport,
                'capability'     => 'edit_theme_options',

            ) );

            $wp_customize->add_setting( 'et_divi['.$setting_2.']', array(
                'default'        => $default_2,
                'type'           => 'option',
                'transport'      => $transport,
                'capability'     => 'edit_theme_options'
            ) );

            $wp_customize->add_setting( 'et_divi['.$setting_3.']', array(
                'default'        => $default_3,
                'type'           => 'option',
                'transport'      => $transport,
                'capability'     => 'edit_theme_options'
            ) );

            $wp_customize->add_setting( 'et_divi['.$setting_4.']', array(
                'default'        => $default_4,
                'type'           => 'option',
                'transport'      => $transport,
                'capability'     => 'edit_theme_options'
            ) );

            $wp_customize->add_control( new Chi_DMM_Multi_Input_Option( $wp_customize, 'et_divi['.$setting.']', 
                    array(
                            'label'         => esc_html__($label),
                            'section'       => $section,
                            'type'          => 'range',
                            'priority'      => $priority,
                            'choices'       => array (
                                'top-left'       => esc_html__($choice_1),
                                'top-right'      => esc_html__($choice_2),
                                'bottom-right'   => esc_html__($choice_3),
                                'bottom-left'    => esc_html__($choice_4)

                            ),
                            'input_attrs'    => array (
                                    'min'       => $min,
                                    'max'       => $max,
                                    'step'      => $step,
                            ),   
                            'settings'       => array (
                                'et_divi['.$setting_1.']',
                                'et_divi['.$setting_2.']',
                                'et_divi['.$setting_3.']',
                                'et_divi['.$setting_4.']'
                            )
                        ) ) ); 
        }
        // END multi-input control
        
        // image control
        function chimmc_image_control ( $wp_customize, $setting, $default, $transport, $label, $section, $priority, $description ){
            // Add image settting
            $wp_customize->add_setting( 'et_divi['.$setting.']', 
                array(
                    'default' 		=> $default,
                    'type'			=> 'option',
                    'capability'	=> 'edit_theme_options',
                    'transport'		=> $transport
                    ) );
            // Add image control
            $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'et_divi['.$setting.']', 
            array(
                    'label'		        => esc_html__( $label ),
                    'section'	        => $section,
                    'type'              => 'image',
                    'settings' 	        => 'et_divi['.$setting.']',
                    'priority' 		    => $priority,
                    'description' 	    => esc_html__( $description )
            ) ) );
        }
        // END image control
  
        // END CONTROLS
               
        // Add MMC Plugin Settings Panel
        $wp_customize->add_panel( esc_html__('DMM_settings_panel'), array(
                'priority'       => '1',
                'capability'     => 'edit_theme_options',
                'theme_supports' => '',
                'title'          => esc_html__( 'Mobile Menu Customizer', 'DMM' )
                ) );

        // Start sections

        // Mobile Menu Header Settings section - since v1.4.0
        chimmc_settings_section( $wp_customize, 'DMM_Mobile_Menu_Header_Settings','Menu Header Settings','Mobile Menu Header Settings','','DMM_settings_panel' );

        // Mobile Menu Settings section
        chimmc_settings_section( $wp_customize, 'DMM_Mobile_Menu_Settings','Menu Settings','Mobile Menu Settings','','DMM_settings_panel' );

        // Mobile Menu Item Settings section
        chimmc_settings_section( $wp_customize, 'DMM_Mobile_Menu_Item_Settings','Menu Item Settings','Mobile Menu Item Settings','','DMM_settings_panel' );

        // Mobile Submenu Settings section
        chimmc_settings_section( $wp_customize, 'DMM_Mobile_Submenu_Settings','Submenu Settings','Mobile Submenu Settings','','DMM_settings_panel' );

        // Mobile Menu Shadows section
        chimmc_settings_section( $wp_customize, 'DMM_Mobile_Menu_shadows','Shadow Settings','Shadow settings for mobile menu','','DMM_settings_panel' );

        // Mobile Menu Gradients section
        chimmc_settings_section( $wp_customize, 'DMM_Mobile_Menu_gradients','Gradients Settings','Gradient settings for mobile menu','','DMM_settings_panel' );

        // Mobile Menu Animations section
        chimmc_settings_section( $wp_customize, 'DMM_Mobile_Menu_animations','Animations Settings','Mobile menu animation settings','','DMM_settings_panel' );
        
        // Mobile Menu BG image section
        chimmc_settings_section( $wp_customize, 'DMM_Mobile_Menu_BG_Image','Background Image Settings','','','DMM_settings_panel' );
        
        // Mobile Menu Icons Settings section
        chimmc_settings_section( $wp_customize, 'DMM_Mobile_Menu_Icons_Settings','Menu Icons Settings','Mobile Menu Icons Settings','','DMM_settings_panel' );
        
        // Divi Layouts section
        chimmc_settings_section( $wp_customize, 'DMM_Divi_Library_Layouts_Settings','Divi Library','Select layouts from Divi Library to add to the mobile menu. This works for the menu assigned to the "MMC Mobile Menu" location only, make sure you have assigned a menu to it on Appearance->Menus page.','','DMM_settings_panel' );

        // End sections 
        
        
        // MENU HEADER OPTIONS
        
        // alpha-color control  
        chimmc_alpha_color_control ($wp_customize, 'chidmm_header_bg_color', et_get_option('chidmm_bg_color','#ffffff'), 'postMessage', 'Header Bg Color', 'DMM_Mobile_Menu_Header_Settings', 1);
        
        // since v1.4.0
        
        // header text color (Color Control)
        chimmc_alpha_color_control($wp_customize, 'chimmc_header_text_color',
                                    et_get_option( 'accent_color', '#2ea3f2' ), 'postMessage', 'Header Text & Icon Color', 'DMM_Mobile_Menu_Header_Settings', 2);
        
        // menu bar background color (Color Control)
        chimmc_alpha_color_control($wp_customize, 'chimmc_menu_bar_bg_color', 'rgba(0,0,0,0.05)', 'postMessage', 'Menu bar background color', 'DMM_Mobile_Menu_Header_Settings', 3);
        
        // select menu bar format (Select Control)
        chimmc_choices_select_control( $wp_customize, 'chimmc_menu_bar_format', 'icon_only', 'postMessage', 'Select menu icon format', 'DMM_Mobile_Menu_Header_Settings', 4, '', 
                                        array ( 'icon_only' => esc_html__( 'Icon Only' ), 
                                                'text_icon' => esc_html__( 'Text + Icon' ),  
                                                'icon_text' => esc_html__( 'Icon + Text' ),
                                                'text_only' => esc_html__( 'Text Only' )
                                            ) );
        
        // type text for the menu hamburger
        chimmc_text_field_control ($wp_customize, 'chimmc_menu_bar_text', '', 'postMessage', 'Type text for closed menu', 'DMM_Mobile_Menu_Header_Settings', 5, 'Example: MENU' );
        
        // type text for the menu hamburger
        chimmc_text_field_control ($wp_customize, 'chimmc_menu_bar_close_text', '', 'postMessage', 'Type text for opened menu', 'DMM_Mobile_Menu_Header_Settings', 6, 'Example: CLOSE' );
        
        // enable 'x' icon for closing menu
        chimmc_checkbox_control ($wp_customize, 'chimmc_menu_bar_close_icon', false, 'postMessage', 'Use "X" icon for closing menu', 'DMM_Mobile_Menu_Header_Settings', 7, '');
        
        // enable search icon for Ceneterd and Split headers
        chimmc_checkbox_control ($wp_customize, 'chimmc_search_icon', false, 'postMessage', 'Show search icon', 'DMM_Mobile_Menu_Header_Settings', 8, '');
        
        // menu header text size (Range Control)
        chimmc_range_control($wp_customize, 'chimmc_menu_bar_text_size', 14, 'postMessage', 
                             'Menu Header Text Size', 'DMM_Mobile_Menu_Header_Settings', 9, '', 10, 40, 1);
        
        // menu header icon size (Range Control)
        chimmc_range_control ($wp_customize, 'chimmc_menu_bar_icon_size', 32, 'postMessage', 
                             'Menu Header Icon Size', 'DMM_Mobile_Menu_Header_Settings', 10, '', 20, 70, 1);
        
        // menu bar font style
        chimmc_font_style_checkbox_control ($wp_customize, 'chimmc_menu_bar_font_style', '', 'postMessage', 'Menu Bar Font Style', 'DMM_Mobile_Menu_Header_Settings', 11, '' );
        
        // dropdown menu top offset (Range Control)
        chimmc_range_control ($wp_customize, 'chimmc_menu_dd_top_offset', 0, 'postMessage', 
                             'Dropdown Menu Top Offset', 'DMM_Mobile_Menu_Header_Settings', 12, '', -100, 100, 1);
      
        // END MENU HEADER OPTIONS
        
        // MENU OPTIONS
        
        // select control
        chimmc_choices_select_control( $wp_customize, 'chidmm_fixed', 'absolute', 'postMessage', 'Make Menu Fixed', 'DMM_Mobile_Menu_Settings', 1, '', 
                                            array (
                                                    'absolute'   => esc_html__( 'No' ),
                                                    'fixed'   	 => esc_html__( 'Yes' )
                                                    ));
        // make fixed menu scrollable (checkbox control)
        chimmc_checkbox_control ($wp_customize, 'chidmm_fixed_scrollable', true, 'postMessage', 'Make Fixed Menu Scrollable', 'DMM_Mobile_Menu_Settings', 2, '');
        
        // v1.1  
        // range control
        chimmc_range_control ($wp_customize, 'chidmm_fixed_menu_height', 80, 'postMessage', 'Fixed Menu Max-Height', 'DMM_Mobile_Menu_Settings', 3, '', 25, 100, 1);
        
        // select control
        chimmc_choices_select_control( $wp_customize, 'chidmm_fullwidth', 'relative', 'postMessage', 'Make Menu Fullwidth', 'DMM_Mobile_Menu_Settings', 4, '', 
                                            array (
                                                    'relative'   => esc_html__( 'No' ),
                                                    'initial'    => esc_html__( 'Yes' )
                                                    ));
        // make menu fullwidth on phone (checkbox)
        chimmc_checkbox_control ($wp_customize, 'chidmm_fullwidth_phone', true, 'postMessage', 'Fullwidth Menu on Phone', 'DMM_Mobile_Menu_Settings', 5, '');
        
        // make menu fullwidth on tablet (checkbox)
        chimmc_checkbox_control ($wp_customize, 'chidmm_fullwidth_tablet', false, 'postMessage', 'Fullwidth Menu on Tablet', 'DMM_Mobile_Menu_Settings', 6, '');
        
        // secondary menu items position(select control)
        chimmc_choices_select_control( $wp_customize, 'chimmc_sec_menu_items_position', 'after', 'refresh', 'Secondary Menu Items Position', 'DMM_Mobile_Menu_Settings', 7, '', 
                                            array (
                                                    'after'   => esc_html__( 'After main menu items(default)' ),
                                                    'before'    => esc_html__( 'Before main menu items' ),
                                                    'remove'    => esc_html__( 'Remove secondary menu items' )
                                                    ));
        
        // range control
        chimmc_range_control ($wp_customize, 'chidmm_font_size', 14, 'postMessage', 'Font Size', 'DMM_Mobile_Menu_Settings', 8, 'Measurement is in "px".', 10, 30, 1);
            
        // range control
        chimmc_range_control ($wp_customize, 'chidmm_letter_spacing', 0, 'postMessage', 'Letter Spacing', 'DMM_Mobile_Menu_Settings', 9, 'Measurement is in "px".', -1, 10, 1);
        
        // select control
        chimmc_choices_select_control( $wp_customize, 'chidmm_text_align', 'left', 'postMessage', 'Text Alignment', 'DMM_Mobile_Menu_Settings', 10, '', 
                                            array (
                                                    'left'   	=> esc_html__( 'Left' ),
                                                    'center'   	=> esc_html__( 'Center' ),
                                                    'right'   	=> esc_html__( 'Right' )
                                                    ));
        
        // font style checkbox control
        chimmc_font_style_checkbox_control ($wp_customize, 'chidmm_font_style', '', 'postMessage', 'Font Style', 'DMM_Mobile_Menu_Settings', 11, '' );
        
        // multi-input control
        chimmc_multi_input_field_control ($wp_customize, 'chidmm_padding', 'chidmm_padding_top', 'chidmm_padding_right', 'chidmm_padding_bottom', 'chidmm_padding_left', 5, 5, 5, 5, 'postMessage', 'Menu Padding (%)', 'DMM_Mobile_Menu_Settings', 12, 'top', 'right', 'bottom', 'left', 0, 25, 0.25);     
             
        // multi-input control
        chimmc_multi_input_field_control ($wp_customize, 'chidmm_padding_slide', 'chidmm_padding_top_slide', 'chidmm_padding_right_slide', 'chidmm_padding_bottom_slide', 'chidmm_padding_left_slide', 28, 40, 28, 40, 'postMessage', 'Menu Padding (Slide In)', 'DMM_Mobile_Menu_Settings', 6, 'top', 'right', 'bottom', 'left', 0, 80, 1);
        
        // multi-input control
        chimmc_multi_input_field_control ($wp_customize, 'chidmm_trbl_border_width', 'chidmm_top_border_width', 'chidmm_right_border_width', 'chidmm_bottom_border_width', 'chidmm_left_border_width', 3, 0, 0, 0, 'postMessage', 'Menu Border Width', 'DMM_Mobile_Menu_Settings', 13, 'top', 'right', 'bottom', 'left', 0, 20, 1);
        
        // multi-input control
        chimmc_multi_input_field_control ($wp_customize, 'chidmm_border_radius', 'chidmm_border_tl_radius', 'chidmm_border_tr_radius', 'chidmm_border_br_radius', 'chidmm_border_bl_radius', 0, 0, 0, 0, 'postMessage', 'Menu Border Radius', 'DMM_Mobile_Menu_Settings', 14, 'top-left', 'top-right', 'bottom-right', 'bottom-left', 0, 50, 1);
        
        // alpha-color control
         chimmc_alpha_color_control ($wp_customize, 'chidmm_top_header_bg_color', '#2ea3f2', 'postMessage', 'Top Bar Bg Color', 'DMM_Mobile_Menu_Settings', 15);
        
        // alpha-color control
        chimmc_alpha_color_control ($wp_customize, 'chidmm_bg_color', '#ffffff', 'postMessage', 'Menu Background Color', 'DMM_Mobile_Menu_Settings', 16);
        
        // alpha-color control
        chimmc_alpha_color_control ($wp_customize, 'chidmm_link_color', 'rgba(14,22,3,0.6)', 'postMessage', 'Menu Link Color', 'DMM_Mobile_Menu_Settings', 17);
           
        // alpha-color control
        chimmc_alpha_color_control ($wp_customize, 'chidmm_active_link_color', 'rgba(14,22,3,0.85)', 'postMessage', 'Current Menu Link Color', 'DMM_Mobile_Menu_Settings', 18);
        
        // alpha-color control
        chimmc_alpha_color_control ($wp_customize, 'chidmm_border_color', et_get_option( 'accent_color', '#2ea3f2' ), 'postMessage', 'Border Color', 'DMM_Mobile_Menu_Settings', 19);
        
        // END MENU OPTIONS
        
        // MENU ITEM OPTIONS
        
        // range control
        chimmc_range_control ($wp_customize, 'chidmm_items_margins', 0, 'postMessage', 'Menu Item Margins', 'DMM_Mobile_Menu_Item_Settings', 1, '', 0, 30, 1);
        
        // multi-input control
        chimmc_multi_input_field_control ($wp_customize, 'chimmc_item_padding', 'chimmc_item_padding_top', 'chimmc_item_padding_right', 'chimmc_item_padding_bottom', 'chimmc_item_padding_left', 10, 18, 10, 18, 'postMessage', 'Menu Item Padding (px)', 'DMM_Mobile_Menu_Item_Settings', 2, 'top', 'right', 'bottom', 'left', 0, 50, 1);
    
        // multi-input control
        chimmc_multi_input_field_control ($wp_customize, 'chidmm_item_trbl_border_width', 'chidmm_item_t_border_width', 'chidmm_item_r_border_width', 'chidmm_item_b_border_width', 'chidmm_item_l_border_width', 0, 0, 0, 0, 'postMessage', 'Item Border Width (px)', 'DMM_Mobile_Menu_Item_Settings', 3, 'top', 'right', 'bottom', 'left', 0, 20, 1);
      
        // multi-input control
        chimmc_multi_input_field_control ($wp_customize, 'chidmm_item_border_radius', 'chidmm_item_border_tl_radius', 'chidmm_item_border_tr_radius', 'chidmm_item_border_br_radius', 'chidmm_item_border_bl_radius', 0, 0, 0, 0, 'postMessage', 'Item Border Radius', 'DMM_Mobile_Menu_Item_Settings', 4, 'top-left', 'top-right', 'bottom-right', 'bottom-left', 0, 50, 1);
        
        // alpha-color control
        chimmc_alpha_color_control ($wp_customize, 'chidmm_item_bg_color', 'rgba(0,0,0,0)', 'postMessage', 'Menu Item Bg Color', 'DMM_Mobile_Menu_Item_Settings', 5);
             
        // alpha-color control
        chimmc_alpha_color_control ($wp_customize, 'chidmm_current_item_bg_color', 'rgba(0,0,0,0)', 'postMessage', 'Current Item Bg Color', 'DMM_Mobile_Menu_Item_Settings', 6);
            
        // alpha-color control
        chimmc_alpha_color_control ($wp_customize, 'chidmm_item_border_color', 'rgba(0,0,0,0)', 'postMessage', 'Menu Item Border Color', 'DMM_Mobile_Menu_Item_Settings', 7);
        
        
        
        // END MENU ITEM OPTIONS
        
        // SUBMENU OPTIONS
        
        // select control
        chimmc_choices_select_control( $wp_customize, 'chidmm_collapse_submenu', 0, 'postMessage', 'Collapse Submenu', 'DMM_Mobile_Submenu_Settings', 1, '', 
                                            array (
                                                    '0' => esc_html__( 'No' ),
                                                    '1' => esc_html__( 'Yes' )
                                                    ));
        
        // make parent item clickable (checkbox control)
        chimmc_checkbox_control ($wp_customize, 'chimmc_parent_clickable', false, 'refresh', 'Make Parent Item Clickable', 'DMM_Mobile_Submenu_Settings', 2, '' );
        
        // toggle submenus (checkbox control)
        chimmc_checkbox_control ($wp_customize, 'chimmc_toggle_submenus', false, 'postMessage', 'Enable Accordion', 'DMM_Mobile_Submenu_Settings', 3, '' );
        
        // customize parent item arrow (checkbox control)
        chimmc_checkbox_control ($wp_customize, 'chimmc_arrow_styles_on', false, 'postMessage', 'Customize Parent Item Arrow', 'DMM_Mobile_Submenu_Settings', 4, '' );
        
        // parent item arrow icon (icon picker control)
        chimmc_arrow_icon_picker_control ($wp_customize, 'chimmc_parent_arrow', '3', 'postMessage', 'Select Arrow Icon', 'DMM_Mobile_Submenu_Settings', 5, '' );
        
        // rotate parent item arrow (range control)
        chimmc_range_control ($wp_customize, 'chimmc_parent_arrow_rotate', 180, 'postMessage', 'Rotate arrow(deg)', 'DMM_Mobile_Submenu_Settings', 6, '', -360, 360, 15);
        
        // parent item arrow size (range control)
        chimmc_range_control ($wp_customize, 'chimmc_parent_arrow_size', 14, 'postMessage', 'Arrow size(px)', 'DMM_Mobile_Submenu_Settings', 7, '', 8, 100, 1);
        
        // parent item arrow bg border width (multi-input control)
        chimmc_multi_input_field_control ($wp_customize, 'chimmc_parent_arrow_brdr_width', 'chimmc_parent_arrow_brdr_t_width', 'chimmc_parent_arrow_brdr_r_width', 'chimmc_parent_arrow_brdr_b_width', 'chimmc_parent_arrow_brdr_l_width', 0, 0, 0, 0, 'postMessage', 'Arrow Bg Border Width', 'DMM_Mobile_Submenu_Settings', 8, 'top', 'right', 'bottom', 'left', 0, 20, 1);
        
        // parent item arrow bg border radius (multi-input control)
        chimmc_multi_input_field_control ($wp_customize, 'chimmc_parent_arrow_brdr_radius', 'chimmc_parent_arrow_brdr_tl_radius', 'chimmc_parent_arrow_brdr_tr_radius', 'chimmc_parent_arrow_brdr_br_radius', 'chimmc_parent_arrow_brdr_bl_radius', 0, 0, 0, 0, 'postMessage', 'Arrow Bg Border Radius', 'DMM_Mobile_Submenu_Settings', 9, 'top-left', 'top-right', 'bottom-right', 'bottom-left', 0, 100, 1);
        
        // parent item arrow bg padding (multi-input control)
        chimmc_multi_input_field_control ($wp_customize, 'chimmc_parent_arrow_padding', 'chimmc_parent_arrow_padding_top', 'chimmc_parent_arrow_padding_right', 'chimmc_parent_arrow_padding_bottom', 'chimmc_parent_arrow_padding_left', 10, 10, 10, 10, 'postMessage', 'Arrow Bg Padding', 'DMM_Mobile_Submenu_Settings', 10, 'top', 'right', 'bottom', 'left', 0, 50, 1);
        
        // parent item arrow color (alpha-color control)
        chimmc_alpha_color_control ($wp_customize, 'chimmc_parent_arrow_color', 'rgba(0,0,0,0.6)', 'postMessage', 'Arrow Color', 'DMM_Mobile_Submenu_Settings', 11);
        
        // active parent item arrow color (alpha-color control)
        chimmc_alpha_color_control ($wp_customize, 'chimmc_a_parent_arrow_color', 'rgba(0,0,0,0.6)', 'postMessage', 'Active Parent Item Arrow Color', 'DMM_Mobile_Submenu_Settings', 12);
        
        // parent item arrow BG color (alpha-color control)
        chimmc_alpha_color_control ($wp_customize, 'chimmc_parent_arrow_bg_color', 'rgba(0,0,0,0.1)', 'postMessage', 'Arrow Background Color', 'DMM_Mobile_Submenu_Settings', 13);
        
        // parent item arrow border color (alpha-color control)
        chimmc_alpha_color_control ($wp_customize, 'chimmc_parent_arrow_brdr_color', 'rgba(0,0,0,0.6)', 'postMessage', 'Arrow Border Color', 'DMM_Mobile_Submenu_Settings', 14);
        
        // select choices control
        chimmc_choices_select_control( $wp_customize, 'chimmc_submenu_animation', 'Grow', 'postMessage', 'Submenu Animation', 'DMM_Mobile_Submenu_Settings', 15, '',  
                                        array ( 'none' => esc_html__( 'No Animation' ),
                                                'fadeInRight' => esc_html__( 'Fade In Right' ),  
                                                'fadeInLeft' => esc_html__( 'Fade In Left' ),
                                                'fadeInTop' => esc_html__( 'Fade In Top' ),
                                                'fadeInBottom' => esc_html__( 'Fade In Bottom' ),
                                                'fadeIn' => esc_html__( 'Fade In' ),
                                                'Grow' => esc_html__( 'Grow' ),
                                                'zoom-in' => esc_html__( 'Zoom In' ),
                                                'flipInX' => esc_html__( 'Flip In X' ),
                                                'flipInY' => esc_html__( 'Flip In Y' ),
                                                'lightSpeedIn' => esc_html__( 'Lightspeed In' ),
                                            )  );
        // range control
        chimmc_float_range_control ($wp_customize, 'chimmc_submenu_animation_speed', '0.3', 'postMessage', 'Submenu Animation Duration', 'DMM_Mobile_Submenu_Settings', 16, '', 0, 3, 0.1);
        
        // range control
        chimmc_range_control ($wp_customize, 'chidmm_submenu_font_size', 14, 'postMessage', 'Submenu Font Size (px)', 'DMM_Mobile_Submenu_Settings', 17, '', 10, 30, 1);
             
        // font style checkbox control
        chimmc_font_style_checkbox_control ($wp_customize, 'chidmm_submenu_font_style', '', 'postMessage', 'Submenu Font Style', 'DMM_Mobile_Submenu_Settings', 18, '' );
        
        // alpha-color control
        chimmc_alpha_color_control ($wp_customize, 'chidmm_submenu_bg_color', 'rgba(0,0,0,0)', 'postMessage', 'Submenu Background Color', 'DMM_Mobile_Submenu_Settings', 19);
            
        // alpha-color control
        chimmc_alpha_color_control ($wp_customize, 'chidmm_submenu_link_color', 'rgba(14,22,3,0.6)', 'postMessage', 'Submenu Link Color', 'DMM_Mobile_Submenu_Settings', 20);
            
        // alpha-color control
        chimmc_alpha_color_control ($wp_customize, 'chidmm_submenu_active_link_color', 'rgba(14,22,3,0.85)', 'postMessage', 'Submenu Current Link Color', 'DMM_Mobile_Submenu_Settings', 21);
        
        // END SUBMENU OPTIONS
        
        // SHADOW
      
        // select control
        chimmc_choices_select_control( $wp_customize, 'chidmm_dd_shadow_in_out', ' ', 'postMessage', 'Shadow Direction', 'DMM_Mobile_Menu_shadows', 1, '', 
                                            array (
                                                    ' '      => esc_html__( 'Outset' ),
                                                    'inset'  => esc_html__( 'Inset' )
                                                    ));

        // range control
        chimmc_range_control ($wp_customize, 'chidmm_dd_shadow_x_offset', 0, 'postMessage', 'Shadow x-Offset', 'DMM_Mobile_Menu_shadows', 2, '', -150, 150, 1);
           
        // range control
        chimmc_range_control ($wp_customize, 'chidmm_dd_shadow_y_offset', 2, 'postMessage', 'Shadow y-Offset', 'DMM_Mobile_Menu_shadows', 3, '', -150, 150, 1);
 
        // range control
        chimmc_range_control ($wp_customize, 'chidmm_dd_shadow_blur', 5, 'postMessage', 'Shadow Blur', 'DMM_Mobile_Menu_shadows', 4, '', 0, 150, 1);

        // range control
        chimmc_range_control ($wp_customize, 'chidmm_dd_shadow_spread', 0, 'postMessage', 'Shadow Spread', 'DMM_Mobile_Menu_shadows', 5, '', -150, 150, 1);
             
        // alpha-color control
        chimmc_alpha_color_control ($wp_customize, 'chidmm_dd_shadow_color', 'rgba(0,0,0,0.1)', 'postMessage', 'Shadow Color', 'DMM_Mobile_Menu_shadows', 6);
        
        // END SHADOW              
        
        // START GRADIENTS 
        
        // select the element for applying gradient (Select Control)
        chimmc_choices_select_control( $wp_customize, 'chimmc_element_with_gradient', 'menuHeader', 'postMessage', 'Apply gradient to:', 'DMM_Mobile_Menu_gradients', 1, '', 
                                      array ( 
                                                'dropdownMenu' => esc_html__( 'Menu' ), 
                                                'menuHeader' => esc_html__( 'Menu Header' ) 
                                            ) );
        
        // dropdown menu gradient
        // enable/disable dropdown menu gradient (Select Control)
        chimmc_choices_select_control( $wp_customize, 'chimmc_menu_gradient_on_off', 'disabled', 'postMessage', 'Enable/disable menu gradient', 'DMM_Mobile_Menu_gradients', 2, 'Turn gradient on/off for menu.', 
                                      array ( 
                                                'enabled' => esc_html__( 'Enabled' ), 
                                                'disabled' => esc_html__( 'Disabled' ) 
                                            ) );
        
        
        // dropdown menu gradient stop #1 color (Color Control)
        chimmc_alpha_color_control($wp_customize, 'chimmc_menu_gradient_stop1_color',
                                    et_get_option('chidmm_bg_color','#ffffff'), 'postMessage', 'Stop-1 Color', 'DMM_Mobile_Menu_gradients', 3);
        
        // dropdown menu gradient stop #1 location (Range Control)
        chimmc_range_control($wp_customize, 'chimmc_menu_gradient_stop1_location', 0, 'postMessage', 
                             'Stop-1 Location', 'DMM_Mobile_Menu_gradients', 4, '', 0, 100, 1);
        
        // dropdown menu gradient stop #2 color (Color Control)
        chimmc_alpha_color_control($wp_customize, 'chimmc_menu_gradient_stop2_color',
                                    et_get_option('chidmm_bg_color','#ffffff'), 'postMessage', 'Stop-2 Color', 'DMM_Mobile_Menu_gradients', 5);
        
        // dropdown menu gradient stop #2 location (Range Control)
        chimmc_range_control($wp_customize, 'chimmc_menu_gradient_stop2_location', 35, 'postMessage', 
                             'Stop-2 Location', 'DMM_Mobile_Menu_gradients', 6, '', 0, 100, 1);
        
        // dropdown menu gradient stop #3 color (Color Control)
        chimmc_alpha_color_control($wp_customize, 'chimmc_menu_gradient_stop3_color',
                                    et_get_option('chidmm_bg_color','#ffffff'), 'postMessage', 'Stop-3 Color', 'DMM_Mobile_Menu_gradients', 7);
        
        // dropdown menu gradient stop #3 location (Range Control)
        chimmc_range_control($wp_customize, 'chimmc_menu_gradient_stop3_location', 75, 'postMessage', 
                             'Stop-3 Location', 'DMM_Mobile_Menu_gradients', 8, '', 0, 100, 1);
        
        // dropdown menu gradient angle (Range Control)
        chimmc_range_control($wp_customize, 'chimmc_menu_gradient_angle', 0, 'postMessage', 
                             'Gradient Angle', 'DMM_Mobile_Menu_gradients', 9, '', 0, 360, 1);
        
        // select control
        chimmc_choices_select_control( $wp_customize, 'chimmc_gradient_clip', 'border-box', 'postMessage', 'Background Clip', 'DMM_Mobile_Menu_gradients', 10, '', 
                                      array ( 
                                                'border-box' => esc_html__( 'Border-Box' ),
                                                'padding-box' => esc_html__( 'Padding-Box' ),
                                                'content-box' => esc_html__( 'Content-Box' ) 
                                            ) );
        
        // END dropdown menu gradient
        
        // menu header gradient
        // enable/disable menu header gradient (Select Control)
        chimmc_choices_select_control( $wp_customize, 'chimmc_header_gradient_on_off', 'disabled', 'postMessage', 'Enable/disable menu header gradient', 'DMM_Mobile_Menu_gradients', 10, 'Turn gradient on/off for menu header.', array ( 'enabled' => esc_html__( 'Enabled' ), 'disabled' => esc_html__( 'Disabled' ) ) );
        
        // dropdown menu gradient stop #1 color (Color Control)
        chimmc_alpha_color_control($wp_customize, 'chimmc_header_gradient_stop1_color',
                                    et_get_option('chidmm_header_bg_color','#ffffff'), 'postMessage', 'Header Stop-1 Color', 'DMM_Mobile_Menu_gradients', 11);
        
        // dropdown menu gradient stop #1 location (Range Control)
        chimmc_range_control($wp_customize, 'chimmc_header_gradient_stop1_location', 0, 'postMessage', 
                             'Header Stop-1 Location', 'DMM_Mobile_Menu_gradients', 12, '', 0, 100, 1);
        
        // dropdown menu gradient stop #2 color (Color Control)
        chimmc_alpha_color_control($wp_customize, 'chimmc_header_gradient_stop2_color',
                                    et_get_option('chidmm_header_bg_color','#ffffff'), 'postMessage', 'Header Stop-2 Color', 'DMM_Mobile_Menu_gradients', 13);
        
        // dropdown menu gradient stop #2 location (Range Control)
        chimmc_range_control($wp_customize, 'chimmc_header_gradient_stop2_location', 35, 'postMessage', 
                             'Header Stop-2 Location', 'DMM_Mobile_Menu_gradients', 14, '', 0, 100, 1);
        
        // dropdown menu gradient stop #3 color (Color Control)
        chimmc_alpha_color_control($wp_customize, 'chimmc_header_gradient_stop3_color',
                                    et_get_option('chidmm_header_bg_color','#ffffff'), 'postMessage', 'Header Stop-3 Color', 'DMM_Mobile_Menu_gradients', 15);
        
        // dropdown menu gradient stop #3 location (Range Control)
        chimmc_range_control($wp_customize, 'chimmc_header_gradient_stop3_location', 75, 'postMessage', 
                             'Header Stop-3 Location', 'DMM_Mobile_Menu_gradients', 16, '', 0, 100, 1);
        
        // dropdown menu gradient angle (Range Control)
        chimmc_range_control($wp_customize, 'chimmc_header_gradient_angle', 0, 'postMessage', 
                             'Header Gradient Angle', 'DMM_Mobile_Menu_gradients', 17, '', 0, 360, 1);
        
        // END menu header gradient
        
        // END GRADIENTS
        
        // BACKGROUND IMAGE
        
        // select control
        chimmc_choices_select_control( $wp_customize, 'chimmc_bg_image_on_off', 'disabled', 'postMessage', 'Enable/Disable menu bg image', 'DMM_Mobile_Menu_BG_Image', 1, 'Turn menu background image on/off.', 
                                      array ( 
                                            'enabled' => esc_html__( 'Enabled' ), 
                                            'disabled' => esc_html__( 'Disabled' ) 
                                            ) );
        
        // image control
        chimmc_image_control ( $wp_customize, 'chimmc_bg_image_url', '', 'postMessage', 'Background Image', 'DMM_Mobile_Menu_BG_Image', 2, 'Add background image to dorpdown menu' );
        
        // select control
        chimmc_choices_select_control( $wp_customize, 'chimmc_bg_image_size', 'cover', 'postMessage', 'Background Image Size', 'DMM_Mobile_Menu_BG_Image', 3, '', 
                                      array (   
                                            'cover' => esc_html__( 'Cover' ), 
                                            'contain' => esc_html__( 'Fit' ), 
                                            'initial' => esc_html__( 'Actual Size' )
                                            ) );
        // select control
        chimmc_choices_select_control( $wp_customize, 'chimmc_bg_image_position', 'center', 'postMessage', 'Background Image Position', 'DMM_Mobile_Menu_BG_Image', 4, '', 
                                      array (   
                                            'top left' => esc_html__( 'Top Left' ), 
                                            'top center' => esc_html__( 'Top Center' ), 
                                            'top right' => esc_html__( 'Top Right' ),
                                            'center left' => esc_html__( 'Center Left' ), 
                                            'center' => esc_html__( 'Center' ), 
                                            'center right' => esc_html__( 'Center Right' ),
                                            'bottom left' => esc_html__( 'Bottom Left' ), 
                                            'bottom center' => esc_html__( 'Bottom Center' ), 
                                            'bottom right' => esc_html__( 'Bottom Right' )
                                            ) );
        // select control
        chimmc_choices_select_control( $wp_customize, 'chimmc_bg_image_repeat', 'no-repeat', 'postMessage', 'Background Image Repeat', 'DMM_Mobile_Menu_BG_Image', 5, '', 
                                      array (   
                                            'no-repeat' => esc_html__( 'No Repeat' ), 
                                            'repeat' => esc_html__( 'Repeat' ), 
                                            'repeat-x' => esc_html__( 'Repeat X' ),
                                            'repeat-y' => esc_html__( 'Repeat Y' ), 
                                            'space' => esc_html__( 'Space' ), 
                                            'round' => esc_html__( 'Round' )
                                            ) );
        // select control
        chimmc_choices_select_control( $wp_customize, 'chimmc_bg_image_clip', 'border-box', 'postMessage', 'Background Image Clip', 'DMM_Mobile_Menu_BG_Image', 6, '', 
                                      array (   
                                            'border-box' => esc_html__( 'Border Box' ), 
                                            'padding-box' => esc_html__( 'Padding Box' ), 
                                            'content-box' => esc_html__( 'Content Box' )
                                            ) );
        
        // END BACKGROUND IMAGE
        
        // MENU ANIMATIONS
        
        // select menu open animation (Select Control)
        chimmc_choices_select_control( $wp_customize, 'chimmc_menu_in_animation', 'default', 'postMessage', 'Select menu open animation', 'DMM_Mobile_Menu_animations', 1, '', 
                                      array ( 'default' => esc_html__( 'Default' ), 
                                                'fadeInRight' => esc_html__( 'Fade In Right' ),  
                                                'fadeInLeft' => esc_html__( 'Fade In Left' ),
                                                'fadeInTop' => esc_html__( 'Fade In Top' ),
                                                'fadeInBottom' => esc_html__( 'Fade In Bottom' ),
                                                'fadeIn' => esc_html__( 'Fade In' ),
                                                'Grow' => esc_html__( 'Grow' ),
                                                'zoom-in' => esc_html__( 'Zoom In' ),
                                                'flipInX' => esc_html__( 'Flip In X' ),
                                                'flipInY' => esc_html__( 'Flip In Y' ),
                                                'lightSpeedIn' => esc_html__( 'Lightspeed In' ),
                                                'none' => esc_html__( 'No Animation' )
                                            ) );
        // select menu open animation (Select Control)
        chimmc_choices_select_control( $wp_customize, 'chimmc_menu_out_animation', 'default', 'postMessage', 'Select menu close animation', 'DMM_Mobile_Menu_animations', 2, '', 
                                      array ( 'default' => esc_html__( 'Default' ), 
                                                'fadeOutRight' => esc_html__( 'Fade Out Right' ),  
                                                'fadeOutLeft' => esc_html__( 'Fade Out Left' ),
                                                'fadeOutTop' => esc_html__( 'Fade Out Top' ),
                                                'fadeOutBottom' => esc_html__( 'Fade Out Bottom' ),
                                                'fadeOut' => esc_html__( 'Fade Out' ),
                                                'shrink' => esc_html__( 'Shrink' ),
                                                'zoom-out' => esc_html__( 'Zoom Out' ),
                                                'flipOutX' => esc_html__( 'Flip Out X' ),
                                                'flipOutY' => esc_html__( 'Flip Out Y' ),
                                                'lightSpeedOut' => esc_html__( 'Lightspeed Out' ),
                                                'none' => esc_html__( 'No Animation' )
                                            ) );
        
        // END ANIMATIONS
        
        
        // MENU ITEM ICONS
        
        // up-arrows icon set    
        if ( ! function_exists( 'chimmc_get_font_icon_symbols' ) ) :
        function chimmc_get_font_icon_symbols() {
            $symbols = array( '', '&amp;#x21;', '&amp;#x22;', '&amp;#x23;', '&amp;#x24;', '&amp;#x25;', '&amp;#x26;', '&amp;#x27;', '&amp;#x28;', '&amp;#x29;', '&amp;#x2a;', '&amp;#x2b;', '&amp;#x2c;', '&amp;#x2d;', '&amp;#x2e;', '&amp;#x2f;', '&amp;#x30;', '&amp;#x31;', '&amp;#x32;', '&amp;#x33;', '&amp;#x34;', '&amp;#x35;', '&amp;#x36;', '&amp;#x37;', '&amp;#x38;', '&amp;#x39;', '&amp;#x3a;', '&amp;#x3b;', '&amp;#x3c;', '&amp;#x3d;', '&amp;#x3e;', '&amp;#x3f;', '&amp;#x40;', '&amp;#x41;', '&amp;#x42;', '&amp;#x43;', '&amp;#x44;', '&amp;#x45;', '&amp;#x46;', '&amp;#x47;', '&amp;#x48;', '&amp;#x49;', '&amp;#x4a;', '&amp;#x4b;', '&amp;#x4c;', '&amp;#x4d;', '&amp;#x4e;', '&amp;#x4f;', '&amp;#x50;', '&amp;#x51;', '&amp;#x52;', '&amp;#x53;', '&amp;#x54;', '&amp;#x55;', '&amp;#x56;', '&amp;#x57;', '&amp;#x58;', '&amp;#x59;', '&amp;#x5a;', '&amp;#x5b;', '&amp;#x5c;', '&amp;#x5d;', '&amp;#x5e;', '&amp;#x5f;', '&amp;#x60;', '&amp;#x61;', '&amp;#x62;', '&amp;#x63;', '&amp;#x64;', '&amp;#x65;', '&amp;#x66;', '&amp;#x67;', '&amp;#x68;', '&amp;#x69;', '&amp;#x6a;', '&amp;#x6b;', '&amp;#x6c;', '&amp;#x6d;', '&amp;#x6e;', '&amp;#x6f;', '&amp;#x70;', '&amp;#x71;', '&amp;#x72;', '&amp;#x73;', '&amp;#x74;', '&amp;#x75;', '&amp;#x76;', '&amp;#x77;', '&amp;#x78;', '&amp;#x79;', '&amp;#x7a;', '&amp;#x7b;', '&amp;#x7c;', '&amp;#x7d;', '&amp;#x7e;', '&amp;#xe000;', '&amp;#xe001;', '&amp;#xe002;', '&amp;#xe003;', '&amp;#xe004;', '&amp;#xe005;', '&amp;#xe006;', '&amp;#xe007;', '&amp;#xe009;', '&amp;#xe00a;', '&amp;#xe00b;', '&amp;#xe00c;', '&amp;#xe00d;', '&amp;#xe00e;', '&amp;#xe00f;', '&amp;#xe010;', '&amp;#xe011;', '&amp;#xe012;', '&amp;#xe013;', '&amp;#xe014;', '&amp;#xe015;', '&amp;#xe016;', '&amp;#xe017;', '&amp;#xe018;', '&amp;#xe019;', '&amp;#xe01a;', '&amp;#xe01b;', '&amp;#xe01c;', '&amp;#xe01d;', '&amp;#xe01e;', '&amp;#xe01f;', '&amp;#xe020;', '&amp;#xe021;', '&amp;#xe022;', '&amp;#xe023;', '&amp;#xe024;', '&amp;#xe025;', '&amp;#xe026;', '&amp;#xe027;', '&amp;#xe028;', '&amp;#xe029;', '&amp;#xe02a;', '&amp;#xe02b;', '&amp;#xe02c;', '&amp;#xe02d;', '&amp;#xe02e;', '&amp;#xe02f;', '&amp;#xe030;', '&amp;#xe103;', '&amp;#xe0ee;', '&amp;#xe0ef;', '&amp;#xe0e8;', '&amp;#xe0ea;', '&amp;#xe101;', '&amp;#xe107;', '&amp;#xe108;', '&amp;#xe102;', '&amp;#xe106;', '&amp;#xe0eb;', '&amp;#xe010;', '&amp;#xe105;', '&amp;#xe0ed;', '&amp;#xe100;', '&amp;#xe104;', '&amp;#xe0e9;', '&amp;#xe109;', '&amp;#xe0ec;', '&amp;#xe0fe;', '&amp;#xe0f6;', '&amp;#xe0fb;', '&amp;#xe0e2;', '&amp;#xe0e3;', '&amp;#xe0f5;', '&amp;#xe0e1;', '&amp;#xe0ff;', '&amp;#xe031;', '&amp;#xe032;', '&amp;#xe033;', '&amp;#xe034;', '&amp;#xe035;', '&amp;#xe036;', '&amp;#xe037;', '&amp;#xe038;', '&amp;#xe039;', '&amp;#xe03a;', '&amp;#xe03b;', '&amp;#xe03c;', '&amp;#xe03d;', '&amp;#xe03e;', '&amp;#xe03f;', '&amp;#xe040;', '&amp;#xe041;', '&amp;#xe042;', '&amp;#xe043;', '&amp;#xe044;', '&amp;#xe045;', '&amp;#xe046;', '&amp;#xe047;', '&amp;#xe048;', '&amp;#xe049;', '&amp;#xe04a;', '&amp;#xe04b;', '&amp;#xe04c;', '&amp;#xe04d;', '&amp;#xe04e;', '&amp;#xe04f;', '&amp;#xe050;', '&amp;#xe051;', '&amp;#xe052;', '&amp;#xe053;', '&amp;#xe054;', '&amp;#xe055;', '&amp;#xe056;', '&amp;#xe057;', '&amp;#xe058;', '&amp;#xe059;', '&amp;#xe05a;', '&amp;#xe05b;', '&amp;#xe05c;', '&amp;#xe05d;', '&amp;#xe05e;', '&amp;#xe05f;', '&amp;#xe060;', '&amp;#xe061;', '&amp;#xe062;', '&amp;#xe063;', '&amp;#xe064;', '&amp;#xe065;', '&amp;#xe066;', '&amp;#xe067;', '&amp;#xe068;', '&amp;#xe069;', '&amp;#xe06a;', '&amp;#xe06b;', '&amp;#xe06c;', '&amp;#xe06d;', '&amp;#xe06e;', '&amp;#xe06f;', '&amp;#xe070;', '&amp;#xe071;', '&amp;#xe072;', '&amp;#xe073;', '&amp;#xe074;', '&amp;#xe075;', '&amp;#xe076;', '&amp;#xe077;', '&amp;#xe078;', '&amp;#xe079;', '&amp;#xe07a;', '&amp;#xe07b;', '&amp;#xe07c;', '&amp;#xe07d;', '&amp;#xe07e;', '&amp;#xe07f;', '&amp;#xe080;', '&amp;#xe081;', '&amp;#xe082;', '&amp;#xe083;', '&amp;#xe084;', '&amp;#xe085;', '&amp;#xe086;', '&amp;#xe087;', '&amp;#xe088;', '&amp;#xe089;', '&amp;#xe08a;', '&amp;#xe08b;', '&amp;#xe08c;', '&amp;#xe08d;', '&amp;#xe08e;', '&amp;#xe08f;', '&amp;#xe090;', '&amp;#xe091;', '&amp;#xe092;', '&amp;#xe0f8;', '&amp;#xe0fa;', '&amp;#xe0e7;', '&amp;#xe0fd;', '&amp;#xe0e4;', '&amp;#xe0e5;', '&amp;#xe0f7;', '&amp;#xe0e0;', '&amp;#xe0fc;', '&amp;#xe0f9;', '&amp;#xe0dd;', '&amp;#xe0f1;', '&amp;#xe0dc;', '&amp;#xe0f3;', '&amp;#xe0d8;', '&amp;#xe0db;', '&amp;#xe0f0;', '&amp;#xe0df;', '&amp;#xe0f2;', '&amp;#xe0f4;', '&amp;#xe0d9;', '&amp;#xe0da;', '&amp;#xe0de;', '&amp;#xe0e6;', '&amp;#xe093;', '&amp;#xe094;', '&amp;#xe095;', '&amp;#xe096;', '&amp;#xe097;', '&amp;#xe098;', '&amp;#xe099;', '&amp;#xe09a;', '&amp;#xe09b;', '&amp;#xe09c;', '&amp;#xe09d;', '&amp;#xe09e;', '&amp;#xe09f;', '&amp;#xe0a0;', '&amp;#xe0a1;', '&amp;#xe0a2;', '&amp;#xe0a3;', '&amp;#xe0a4;', '&amp;#xe0a5;', '&amp;#xe0a6;', '&amp;#xe0a7;', '&amp;#xe0a8;', '&amp;#xe0a9;', '&amp;#xe0aa;', '&amp;#xe0ab;', '&amp;#xe0ac;', '&amp;#xe0ad;', '&amp;#xe0ae;', '&amp;#xe0af;', '&amp;#xe0b0;', '&amp;#xe0b1;', '&amp;#xe0b2;', '&amp;#xe0b3;', '&amp;#xe0b4;', '&amp;#xe0b5;', '&amp;#xe0b6;', '&amp;#xe0b7;', '&amp;#xe0b8;', '&amp;#xe0b9;', '&amp;#xe0ba;', '&amp;#xe0bb;', '&amp;#xe0bc;', '&amp;#xe0bd;', '&amp;#xe0be;', '&amp;#xe0bf;', '&amp;#xe0c0;', '&amp;#xe0c1;', '&amp;#xe0c2;', '&amp;#xe0c3;', '&amp;#xe0c4;', '&amp;#xe0c5;', '&amp;#xe0c6;', '&amp;#xe0c7;', '&amp;#xe0c8;', '&amp;#xe0c9;', '&amp;#xe0ca;', '&amp;#xe0cb;', '&amp;#xe0cc;', '&amp;#xe0cd;', '&amp;#xe0ce;', '&amp;#xe0cf;', '&amp;#xe0d0;', '&amp;#xe0d1;', '&amp;#xe0d2;', '&amp;#xe0d3;', '&amp;#xe0d4;', '&amp;#xe0d5;', '&amp;#xe0d6;', '&amp;#xe0d7;', '&amp;#xe600;', '&amp;#xe601;', '&amp;#xe602;', '&amp;#xe603;', '&amp;#xe604;', '&amp;#xe605;', '&amp;#xe606;', '&amp;#xe607;', '&amp;#xe608;', '&amp;#xe609;', '&amp;#xe60a;', '&amp;#xe60b;', '&amp;#xe60c;', '&amp;#xe60d;', '&amp;#xe60e;', '&amp;#xe60f;', '&amp;#xe610;', '&amp;#xe611;', '&amp;#xe612;', '&amp;#xe008;', );

            $symbols = apply_filters( 'chimmc_font_icon_symbols', $symbols );

            return $symbols;
        }
        endif;
        if ( ! function_exists( 'chimmc_get_font_icon_list' ) ) :
        function chimmc_get_font_icon_list() {
            $output = is_customize_preview() ? chimmc_get_font_icon_list_items() : '<%= window.et_builder.font_icon_list_template() %>';

            $output = sprintf( '<ul class="et_font_icon">%1$s</ul>', $output );

            return $output;
        }
        endif;

        if ( ! function_exists( 'chimmc_get_font_icon_list_items' ) ) :
        function chimmc_get_font_icon_list_items() {
            $output = '';

            $symbols = chimmc_get_font_icon_symbols();

            foreach ( $symbols as $symbol ) {
                $output .= sprintf( '<li data-icon="%1$s"></li>', esc_attr( $symbol ) );
            }

            return $output;
        }
        endif;

        if ( ! function_exists( 'chimmc_font_icon_list' ) ) :
        function chimmc_font_icon_list() {
            echo chimmc_get_font_icon_list();
        }
        endif;   
        // end icon set
        /**
         * Icon picker control for Customizer
         */
        class Chi_MMC_Icon_Picker_Option extends WP_Customize_Control {
            public $type = 'icon_picker';

            public function render_content() {

            ?>
            <label class="chimmc_icon_picker_control">
                <?php if ( ! empty( $this->label ) ) : ?>
                    <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                <?php endif;
                if ( ! empty( $this->description ) ) : ?>
                    <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
                <?php endif; ?>
                <?php chimmc_font_icon_list(); ?>
                <input type="hidden" class="et_selected_icon" <?php $this->input_attrs(); ?> value="<?php echo esc_attr( $this->value() ); ?>" <?php $this->link(); ?> />
            </label>
            <?php
            }
        }
          
        /**
         *  Primary menu items dropdown select control
         */
        class Primary_Menu_Items_Dropdown_Control extends WP_Customize_Control {
            public $type = 'select';

            public function render_content() {
            ?>
            <label>
                <?php if ( ! empty( $this->label ) ) : ?>
                    <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                <?php endif;
                if ( ! empty( $this->description ) ) : ?>
                    <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
                <?php endif; ?>
                
                <?php
                if ( ("primary-menu") && ($locations = get_nav_menu_locations()) && isset($locations["primary-menu"]) ) { 
                
                $count = 0;
                $menu = get_term( $locations["primary-menu"], 'nav_menu' );
                $menu_items = wp_get_nav_menu_items($menu->term_id); 

                if( !empty( $menu_items ) ) { ?>
                
                <select <?php $this->link(); ?>>
                   <?php

                    foreach( $menu_items as $menu_item ) {

                        //$link = $menu_item->url;
                        $title = $menu_item->title;
                        $item_ID = $menu_item->ID;

                            echo '<option value="' . esc_attr( $item_ID ) . '"' . selected( $this->value(), $item_ID, false ).'>' . esc_html( $title ) . '</option>';

                        $count++;
                    }
                   
                   ?>
                </select>
                
                <?php } else {
                        echo '<div class="chimmc_no_menu_items_found">' . esc_html__('No Menu Items Found. Please make sure you\'ve assigned a Primary Menu. If you have already assigned a menu then SAVE and REFRESH the page.') . '</div>';
                    } 
                } ?>
                
            </label>
            <?php
            }
        }
        
        /**
         *  MMC mobile menu items dropdown select control
         */
        class ChiMMC_Mobile_Menu_Items_Dropdown_Control extends WP_Customize_Control {
            public $type = 'select';

            public function render_content() {
            ?>
            <label>
                <?php if ( ! empty( $this->label ) ) : ?>
                    <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                <?php endif;
                if ( ! empty( $this->description ) ) : ?>
                    <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
                <?php endif; ?>
                
                <?php
                if ( ("chimmc-mobile-menu") && ($locations = get_nav_menu_locations()) && isset($locations["chimmc-mobile-menu"]) ) { 
                
                $count = 0;
                $menu = get_term( $locations["chimmc-mobile-menu"], 'nav_menu' );
                $menu_items = wp_get_nav_menu_items($menu->term_id); 

                if( !empty( $menu_items ) ) { ?>
                
                <select <?php $this->link(); ?>>
                   <?php

                    foreach( $menu_items as $menu_item ) {

                        $title = $menu_item->title;
                        $item_ID = $menu_item->ID;

                            echo '<option value="' . esc_attr( $item_ID ) . '"' . selected( $this->value(), $item_ID, false ).'>' . esc_html( $title ) . '</option>';

                        $count++;
                    }
                   
                   ?>
                </select>
                
                <?php } else {
                        echo '<div class="chimmc_no_menu_items_found">' . esc_html__('No Menu Items Found. Please make sure you\'ve assigned a MMC Mobile Menu. If you have already assigned a menu then SAVE and REFRESH the page.') . '</div>';
                    } 
                } ?>
                
            </label>
            <?php
            }
        } 
        
        /**
         *  Secondary menu items dropdown select control
         */
        class Secondary_Menu_Items_Dropdown_Control extends WP_Customize_Control {
            public $type = 'select';

            public function render_content() {
            ?>
            <label>
                <?php if ( ! empty( $this->label ) ) : ?>
                    <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                <?php endif;
                if ( ! empty( $this->description ) ) : ?>
                    <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
                <?php endif; ?>
                
                <?php
                if ( ("secondary-menu") && ($locations = get_nav_menu_locations()) && isset($locations["secondary-menu"]) ) { 
                    
                $count = 0;
                $menu = get_term( $locations["secondary-menu"], 'nav_menu' );
                $menu_items = wp_get_nav_menu_items($menu->term_id); 

                if( !empty( $menu_items ) ) { ?>
                
                <select <?php $this->link(); ?>>
                   <?php 
                    
                    foreach( $menu_items as $menu_item ) {

                        $title = $menu_item->title;
                        $item_ID = $menu_item->ID;

                            echo '<option value="' . esc_attr( $item_ID ) . '"' . selected( $this->value(), $item_ID, false ).'>' . esc_html( $title ) . '</option>';

                        $count++;
                    }
                    
                   ?>
                </select>
                
                <?php } else {
                        echo '<div class="chimmc_no_menu_items_found">' . esc_html__('No Menu Items Found. Please make sure you\'ve assigned a Secondary Menu. If you have already assigned a menu then SAVE and REFRESH the page.') . '</div>';
                    } 
                } ?>
                
            </label>
            <?php
            }
        }
        
        // select control
        chimmc_choices_select_control( $wp_customize, 'chimmc_icons_on_off', 'disabled', 'postMessage', 'Enable/Disable Menu Icons', 'DMM_Mobile_Menu_Icons_Settings', 1, 'Turn menu icons on/off.', 
                                      array ( 
                                            'enabled' => esc_html__( 'Enabled' ), 
                                            'disabled' => esc_html__( 'Disabled' ) 
                                            ) );
        // icon picker control
        function chimmc_menu_item_icon_picker( $wp_customize, $theme_location ) {
            if ( ($theme_location) && ($locations = get_nav_menu_locations()) && isset($locations[$theme_location]) ) {
                $menu = get_term( $locations[$theme_location], 'nav_menu' );
                $menu_items = wp_get_nav_menu_items($menu->term_id);

                $count = 0;
                
                if($theme_location == 'primary-menu'){
                    $description = '(Primary menu item)';
                } else if($theme_location == 'chimmc-mobile-menu'){
                    $description = '(MMC mobile menu item)';
                } else {
                    $description = '(Secondary menu item)';
                }
                
                if( !empty( $menu_items ) ) {
                
                foreach( $menu_items as $menu_item ) {

                    $title = $menu_item->title;
                    $item_ID = $menu_item->ID;
                        
                        $wp_customize->add_setting( 'et_divi[chimmc_menu_icon_'.$item_ID.']', array(
                                    'default'               => '',
                                    'type'			        => 'option',
                                    'capability'	        => 'edit_theme_options',
                                    'transport'		        => 'postMessage',
                                    'sanitize_callback'     => 'et_sanitize_font_icon',
                                ) );

                        $wp_customize->add_control( new Chi_MMC_Icon_Picker_Option( $wp_customize, 'et_divi[chimmc_menu_icon_'.$item_ID.']', array(
                            'label'      => esc_html__( 'Select Icon for: "'.$title.'"' ),
                            'type'       => 'icon_picker',
                            'section'    => 'DMM_Mobile_Menu_Icons_Settings',
                            'settings'   => 'et_divi[chimmc_menu_icon_'.$item_ID.']',
                            'description' => esc_html__( $description ),
                        ) ) );
                    
                    $count++;
                }
                }
            } 
        }
        
        // select control
        $wp_customize->add_setting( 'et_divi[chimmc_menu_items_list]', array(
                                    'default'               => '',
                                    'type'			        => 'option',
                                    'capability'	        => 'edit_theme_options',
                                    'transport'		        => 'postMessage',
                                ) );

        $wp_customize->add_control( new Primary_Menu_Items_Dropdown_Control( $wp_customize, 'et_divi[chimmc_menu_items_list]', array(
                                    'label'   => esc_html__( 'Select Primary Menu Item' ),
                                    'type'    => 'select',
                                    'section' => 'DMM_Mobile_Menu_Icons_Settings',
                                    'settings'   => 'et_divi[chimmc_menu_items_list]',
                                ) ) );
        
        // icon picker controls for primary menu
        chimmc_menu_item_icon_picker( $wp_customize, "primary-menu" );
        
        // select control
        $wp_customize->add_setting( 'et_divi[chimmc_mob_menu_items_list]', array(
                                    'default'               => '',
                                    'type'			        => 'option',
                                    'capability'	        => 'edit_theme_options',
                                    'transport'		        => 'postMessage',
                                ) );

        $wp_customize->add_control( new ChiMMC_Mobile_Menu_Items_Dropdown_Control( $wp_customize, 'et_divi[chimmc_mob_menu_items_list]', array(
                                    'label'   => esc_html__( 'Select Mobile Menu Item' ),
                                    'type'    => 'select',
                                    'section' => 'DMM_Mobile_Menu_Icons_Settings',
                                    'settings'   => 'et_divi[chimmc_mob_menu_items_list]',
                                ) ) );
        
        // icon picker controls for primary menu
        chimmc_menu_item_icon_picker( $wp_customize, "chimmc-mobile-menu" );    
        
        // select control
        $wp_customize->add_setting( 'et_divi[chimmc_sec_menu_items_list]', array(
                                    'default'               => '',
                                    'type'			        => 'option',
                                    'capability'	        => 'edit_theme_options',
                                    'transport'		        => 'postMessage',
                                ) );

        $wp_customize->add_control( new Secondary_Menu_Items_Dropdown_Control( $wp_customize, 'et_divi[chimmc_sec_menu_items_list]', array(
                                    'label'   => esc_html__( 'Select Secondary Menu Item' ),
                                    'type'    => 'select',
                                    'section' => 'DMM_Mobile_Menu_Icons_Settings',
                                    'settings'   => 'et_divi[chimmc_sec_menu_items_list]',
                                ) ) );
        
        // icon picker controls for secondary menu
        chimmc_menu_item_icon_picker( $wp_customize, "secondary-menu" );
        
        // select control
        chimmc_choices_select_control( $wp_customize, 'chimmc_icons_position', 'before', 'postMessage', 'Icon Position', 'DMM_Mobile_Menu_Icons_Settings', 2, '', 
                                      array ( 
                                            'before' => esc_html__( 'Left' ), 
                                            'after' => esc_html__( 'Right' ) 
                                            ) );
        
        // checkbox control
        chimmc_checkbox_control ($wp_customize, 'chimmc_align_icons_left', false, 'postMessage', 'Align Icons Left', 'DMM_Mobile_Menu_Icons_Settings', 2, '' );
            
        // checkbox control
        chimmc_checkbox_control ($wp_customize, 'chimmc_align_icons_right', false, 'postMessage', 'Align Icons Right', 'DMM_Mobile_Menu_Icons_Settings', 2, '' );
        
        // range control
        chimmc_range_control ($wp_customize, 'chimmc_menu_icons_size', 14, 'postMessage', 'Icons Size', 'DMM_Mobile_Menu_Icons_Settings', 2, '', 1, 100, 1);
        
        // END MENU ITEM ICONS
        
        
        // DIVI LIBRARY
        
        // select control
        chimmc_choices_select_control( $wp_customize, 'chimmc_add_pb_layouts', 'disabled', 'refresh', 'Add Layouts From Divi Library', 'DMM_Divi_Library_Layouts_Settings', 2, '', 
                                      array ( 
                                            'disabled' => esc_html__( 'Disabled' ), 
                                            'above' => esc_html__( 'ABOVE menu items' ), 
                                            'below' => esc_html__( 'BELOW menu items' ), 
                                            'above_below' => esc_html__( 'ABOVE and BELOW menu items' )  
                                            ) );
        
        // posts select control
        chimmc_layouts_select_control( $wp_customize, 'chimmc_pb_layouts_add_above', '', 'refresh', 'Add Layout Above Menu Items', 'DMM_Divi_Library_Layouts_Settings', 2, '' );
        
        // posts select control
        chimmc_layouts_select_control( $wp_customize, 'chimmc_pb_layouts_add_below', '', 'refresh', 'Add Layout Below Menu Items', 'DMM_Divi_Library_Layouts_Settings', 3, '' );
        
        // END DIVI LIBRARY
        
        }
}

add_action( 'customize_register', 'chidmm_customizer_plugin_settings' );

// Customizer CSS
function chidmm_customizer_css(){
    ?><?php
    
        $chimmc_body_classes = get_body_class();
        
        // header format detection
        $chimmc_default_on = (in_array('et_header_style_left', $chimmc_body_classes) && ( !in_array('et_header_style_fullscreen', $chimmc_body_classes) && !in_array('et_header_style_slide', $chimmc_body_classes)) )  ? true : false ;
        $chimmc_centered_on = (in_array('et_header_style_centered', $chimmc_body_classes)) ? true : false ;
        $chimmc_split_on = (in_array('et_header_style_split', $chimmc_body_classes)) ? true : false ;
        $chimmc_slide_in_on = (in_array('et_header_style_slide', $chimmc_body_classes)) ? true : false ;
        $chimmc_fullscreen_on = (in_array('et_header_style_fullscreen', $chimmc_body_classes)) ? true : false ;
    
        // check if icons are enabled
        $chimmc_icons_enabled = (in_array('chimmc_icons_enabled', $chimmc_body_classes)) ? true : false ;    
    
        // menu icon and text position detection
        $chimmc_text_left = (in_array('chimmc_text_left', $chimmc_body_classes)) ? true : false ;
        $chimmc_text_right = (in_array('chimmc_text_right', $chimmc_body_classes)) ? true : false ;
        $chimmc_text_center = (in_array('chimmc_text_center', $chimmc_body_classes)) ? true : false ;
        $chimmc_icons_left = (in_array('chimmc_icons_left', $chimmc_body_classes)) ? true : false ;
        $chimmc_icons_right = (in_array('chimmc_icons_right', $chimmc_body_classes)) ? true : false ;
        $chimmc_icons_aligned_left = (in_array('chimmc_icons_aligned_left', $chimmc_body_classes)) ? true : false ;
        $chimmc_icons_aligned_right = (in_array('chimmc_icons_aligned_right', $chimmc_body_classes)) ? true : false ;
    
        // parent arrow styles enabled
        $chimmc_arrow_styles_on = (in_array('chimmc_arrow_custom', $chimmc_body_classes)) ? true : false ;

        // settings
    	$chidmm_text_align = et_get_option('chidmm_text_align','left');
        $chidmm_font_size = et_get_option('chidmm_font_size','14');
        
        $chidmm_fullwidth = et_get_option('chidmm_fullwidth','relative');
        $chidmm_fullwidth_phone = et_get_option('chidmm_fullwidth_phone', true);
        $chidmm_fullwidth_tablet = et_get_option('chidmm_fullwidth_tablet', false);
        // if fullwidth menu enabled
        if ($chidmm_fullwidth == 'initial') {

            if (true === $chidmm_fullwidth_phone && true === $chidmm_fullwidth_tablet) {
                // if fullwidth enabled for both tablet and phone
                $chimmc_fullwidth_menu_media = '(max-width: 980px)';
            } else if (true === $chidmm_fullwidth_phone && false === $chidmm_fullwidth_tablet) {
                // if fullwidth enabled for phone only
                $chimmc_fullwidth_menu_media = '(max-width: 479px)';
            } else if (false === $chidmm_fullwidth_phone && true === $chidmm_fullwidth_tablet) {
                // if fullwidth enabled for tablet only
                $chimmc_fullwidth_menu_media = '(max-width: 980px) and (min-width: 480px)';
            } else if (false === $chidmm_fullwidth_phone && false === $chidmm_fullwidth_tablet) {
                // if both phone and tablet fullwidth checkboxes unchecked(why would you do that?)
                $chimmc_fullwidth_menu_media = '(max-width: 0px)';
            }
        }
        // end if fullwidth menu enabled
    
        $chidmm_fixed = esc_html__( et_get_option('chidmm_fixed','absolute') );
        $chidmm_fixed_scroll = et_get_option('chidmm_fixed_scrollable', true );
        $chidmm_fixed_menu_height = et_get_option('chidmm_fixed_menu_height','80');
        $fixed_menu_overflow_y = (true === $chidmm_fixed_scroll)? 'scroll' : 'hidden';
    
        $chidmm_collapse_submenu = et_get_option('chidmm_collapse_submenu','0');
        $chidmm_border_color = et_get_option('chidmm_border_color','#2ea3f2');
        $chidmm_item_bg_color = et_get_option('chidmm_item_bg_color','rgba(0,0,0,0)');
        $chidmm_current_item_bg_color = et_get_option('chidmm_current_item_bg_color','rgba(0,0,0,0)');  
        $chidmm_item_border_color = et_get_option('chidmm_item_border_color','rgba(0,0,0,0)');
    
        $chidmm_top_border_width = esc_html( et_get_option('chidmm_top_border_width','3') );
        $chidmm_right_border_width = esc_html( et_get_option('chidmm_right_border_width','0') );
        $chidmm_bottom_border_width = esc_html( et_get_option('chidmm_bottom_border_width','0') );
        $chidmm_left_border_width = esc_html( et_get_option('chidmm_left_border_width','0') );
        // dropdown menu border width
        $chidmm_border_width = $chidmm_top_border_width.'px '.$chidmm_right_border_width.'px '.$chidmm_bottom_border_width.'px '.$chidmm_left_border_width.'px';
    
        $chidmm_item_t_border_width = esc_html( et_get_option('chidmm_item_t_border_width','0') );
        $chidmm_item_r_border_width = esc_html( et_get_option('chidmm_item_r_border_width','0') );
        $chidmm_item_b_border_width = esc_html( et_get_option('chidmm_item_b_border_width','0') );
        $chidmm_item_l_border_width = esc_html( et_get_option('chidmm_item_l_border_width','0') );
        // menu item border width
        $chidmm_item_border_width = $chidmm_item_t_border_width.'px '.$chidmm_item_r_border_width.'px '.$chidmm_item_b_border_width.'px '.$chidmm_item_l_border_width.'px';
    
        $chidmm_padding_top = esc_html( et_get_option('chidmm_padding_top','5') );
        $chidmm_padding_right = esc_html( et_get_option('chidmm_padding_right','5') );
        $chidmm_padding_bottom = esc_html( et_get_option('chidmm_padding_bottom','5') );
        $chidmm_padding_left = esc_html( et_get_option('chidmm_padding_left','5') );
        // dropdown menu padding
        $chimmc_dd_menu_padding = $chidmm_padding_top.'% '.$chidmm_padding_right.'% '.$chidmm_padding_bottom.'% '.$chidmm_padding_left.'%';
    
        $chidmm_padding_top_slide = esc_html( et_get_option('chidmm_padding_top_slide','28') );
        $chidmm_padding_right_slide = esc_html( et_get_option('chidmm_padding_right_slide','40') );
        $chidmm_padding_bottom_slide = esc_html( et_get_option('chidmm_padding_bottom_slide','28') );
        $chidmm_padding_left_slide = esc_html( et_get_option('chidmm_padding_left_slide','40') );
        // slide-in menu padding
        $chimmc_padding_slide = $chidmm_padding_top_slide.'px '.$chidmm_padding_right_slide.'px '.$chidmm_padding_bottom_slide.'px '.$chidmm_padding_left_slide.'px';
    
        $chidmm_items_margins = et_get_option('chidmm_items_margins','0');
    
        $chimmc_item_padding_top = esc_html( et_get_option('chimmc_item_padding_top','10') );
        $chimmc_item_padding_right = esc_html( et_get_option('chimmc_item_padding_right','18') );
        $chimmc_item_padding_bottom = esc_html( et_get_option('chimmc_item_padding_bottom','10') );
        $chimmc_item_padding_left = esc_html( et_get_option('chimmc_item_padding_left','18') );
        // menu item padding
        $chimmc_item_padding = $chimmc_item_padding_top.'px '.$chimmc_item_padding_right.'px '.$chimmc_item_padding_bottom.'px '.$chimmc_item_padding_left.'px';
    
        $chidmm_letter_spacing = et_get_option('chidmm_letter_spacing','0');
        $chidmm_font_style = et_get_option('chidmm_font_style','');
        $chidmm_bg_color = et_get_option('chidmm_bg_color','#ffffff');
        $chidmm_header_bg_color = et_get_option('chidmm_header_bg_color','#ffffff');
        $chidmm_top_header_bg_color = et_get_option('chidmm_top_header_bg_color','#2ea3f2');  
        $chidmm_link_color = et_get_option('chidmm_link_color','rgba(14,22,3,0.6)');
        $chidmm_active_link_color = et_get_option('chidmm_active_link_color','rgba(14,22,3,0.85)');  
    
        $chimmc_submenu_animation = esc_html( et_get_option('chimmc_submenu_animation', 'Grow' ) );
        $chimmc_submenu_animation_speed = esc_html( et_get_option('chimmc_submenu_animation_speed', '0.3' ) );
        $chidmm_submenu_bg_color = et_get_option('chidmm_submenu_bg_color','rgba(0,0,0,0)');
        $chidmm_submenu_link_color = et_get_option('chidmm_submenu_link_color','rgba(14,22,3,0.6)');
        $chidmm_submenu_active_link_color = et_get_option('chidmm_submenu_active_link_color','rgba(14,22,3,0.85)');
        $chidmm_submenu_font_size = et_get_option('chidmm_submenu_font_size','14');
        $chidmm_submenu_font_style = et_get_option('chidmm_submenu_font_style','');
    
        $chimmc_parent_arrow = et_get_option('chimmc_parent_arrow','3');
        $chimmc_parent_arrow_rotate = esc_html( et_get_option('chimmc_parent_arrow_rotate','180') );
        $chimmc_parent_arrow_size = esc_html( et_get_option('chimmc_parent_arrow_size','14') );
        $chimmc_parent_arrow_color = esc_html( et_get_option('chimmc_parent_arrow_color','rgba(0,0,0,0.6)') );
        $chimmc_a_parent_arrow_color = esc_html( et_get_option('chimmc_a_parent_arrow_color','rgba(0,0,0,0.6)') );
        $chimmc_parent_arrow_bg_color = esc_html( et_get_option('chimmc_parent_arrow_bg_color','rgba(0,0,0,0.1)') );
        $chimmc_parent_arrow_brdr_color = esc_html( et_get_option('chimmc_parent_arrow_brdr_color','rgba(0,0,0,0.6)') );
    
        $chimmc_parent_arrow_padding_top = esc_html( et_get_option('chimmc_parent_arrow_padding_top','10') );
        $chimmc_parent_arrow_padding_right = esc_html( et_get_option('chimmc_parent_arrow_padding_right','10') );
        $chimmc_parent_arrow_padding_bottom = esc_html( et_get_option('chimmc_parent_arrow_padding_bottom','10') );
        $chimmc_parent_arrow_padding_left = esc_html( et_get_option('chimmc_parent_arrow_padding_left','10') );

        // parent item arrow bg padding
        $chimmc_parent_arrow_padding = $chimmc_parent_arrow_padding_top.'px '.$chimmc_parent_arrow_padding_right.'px '.$chimmc_parent_arrow_padding_bottom.'px '.$chimmc_parent_arrow_padding_left.'px';
    
        $chimmc_parent_arrow_brdr_t_width = esc_html( et_get_option('chimmc_parent_arrow_brdr_t_width','0') );
        $chimmc_parent_arrow_brdr_r_width = esc_html( et_get_option('chimmc_parent_arrow_brdr_r_width','0') );
        $chimmc_parent_arrow_brdr_b_width = esc_html( et_get_option('chimmc_parent_arrow_brdr_b_width','0') );
        $chimmc_parent_arrow_brdr_l_width = esc_html( et_get_option('chimmc_parent_arrow_brdr_l_width','0') );

        // parent item arrow bg border width
        $chimmc_parent_arrow_brdr_width = $chimmc_parent_arrow_brdr_t_width.'px '.$chimmc_parent_arrow_brdr_r_width.'px '.$chimmc_parent_arrow_brdr_b_width.'px '.$chimmc_parent_arrow_brdr_l_width.'px';
    
        $chimmc_parent_arrow_brdr_tl_radius = esc_html( et_get_option('chimmc_parent_arrow_brdr_tl_radius','0') );
        $chimmc_parent_arrow_brdr_tr_radius = esc_html( et_get_option('chimmc_parent_arrow_brdr_tr_radius','0') );
        $chimmc_parent_arrow_brdr_br_radius = esc_html( et_get_option('chimmc_parent_arrow_brdr_br_radius','0') );
        $chimmc_parent_arrow_brdr_bl_radius = esc_html( et_get_option('chimmc_parent_arrow_brdr_bl_radius','0') );

        // parent item arrow bg border radius
        $chimmc_parent_arrow_brdr_radius = $chimmc_parent_arrow_brdr_tl_radius.'px '.$chimmc_parent_arrow_brdr_tr_radius.'px '.$chimmc_parent_arrow_brdr_br_radius.'px '.$chimmc_parent_arrow_brdr_bl_radius.'px';
    
        $chidmm_dd_shadow_in_out = esc_html( et_get_option('chidmm_dd_shadow_in_out',' ') );
        $chidmm_dd_shadow_x_offset = esc_html( et_get_option('chidmm_dd_shadow_x_offset','0') );
        $chidmm_dd_shadow_y_offset = esc_html( et_get_option('chidmm_dd_shadow_y_offset','2') );
        $chidmm_dd_shadow_blur = esc_html( et_get_option('chidmm_dd_shadow_blur','5') );
        $chidmm_dd_shadow_spread = esc_html( et_get_option('chidmm_dd_shadow_spread','0') );
        $chidmm_dd_shadow_color = esc_html( et_get_option('chidmm_dd_shadow_color','rgba(0,0,0,0.1)') );
        // dropdown menu shadow
        $chimmc_dd_menu_shadow = $chidmm_dd_shadow_in_out.' '.$chidmm_dd_shadow_x_offset.'px '.$chidmm_dd_shadow_y_offset.'px '.$chidmm_dd_shadow_blur.'px '.$chidmm_dd_shadow_spread.'px '.$chidmm_dd_shadow_color;
    
        $chidmm_border_tl_radius = et_get_option('chidmm_border_tl_radius','0');
        $chidmm_border_tr_radius = et_get_option('chidmm_border_tr_radius','0');
        $chidmm_border_br_radius = et_get_option('chidmm_border_br_radius','0');
        $chidmm_border_bl_radius = et_get_option('chidmm_border_bl_radius','0');
        // dropdown menu border radius
        $chimmc_border_radius = $chidmm_border_tl_radius.'px '.$chidmm_border_tr_radius.'px '.$chidmm_border_br_radius.'px '.$chidmm_border_bl_radius.'px';
    
        $chidmm_item_border_tl_radius = esc_html( et_get_option('chidmm_item_border_tl_radius','0') );
        $chidmm_item_border_tr_radius = esc_html( et_get_option('chidmm_item_border_tr_radius','0') );
        $chidmm_item_border_br_radius = esc_html( et_get_option('chidmm_item_border_br_radius','0') );
        $chidmm_item_border_bl_radius = esc_html( et_get_option('chidmm_item_border_bl_radius','0') );
        // menu item border radius
        $chimmc_item_border_radius = $chidmm_item_border_tl_radius.'px '.$chidmm_item_border_tr_radius.'px '.$chidmm_item_border_br_radius.'px '.$chidmm_item_border_bl_radius.'px';

    // START GRADIENTS (v1.2) and BG IMAGE (v2.0)
        $chimmc_element_with_gradient = esc_html( et_get_option('chimmc_element_with_gradient','menuHeader') );
        $chimmc_menu_gradient_on_off = esc_html( et_get_option('chimmc_menu_gradient_on_off','disabled') );
        $chimmc_menu_gradient_stop1_color = esc_html( et_get_option('chimmc_menu_gradient_stop1_color', $chidmm_bg_color) );
        $chimmc_menu_gradient_stop1_location = esc_html( et_get_option('chimmc_menu_gradient_stop1_location', '0') );
        $chimmc_menu_gradient_stop2_color = esc_html( et_get_option('chimmc_menu_gradient_stop2_color', $chidmm_bg_color) );
        $chimmc_menu_gradient_stop2_location = esc_html( et_get_option('chimmc_menu_gradient_stop2_location', '33') );
        $chimmc_menu_gradient_stop3_color = esc_html( et_get_option('chimmc_menu_gradient_stop3_color', $chidmm_bg_color) );
        $chimmc_menu_gradient_stop3_location = esc_html( et_get_option('chimmc_menu_gradient_stop3_location', '67') );
        $chimmc_menu_gradient_angle = esc_html( et_get_option('chimmc_menu_gradient_angle', '0') );
        // disable gradient background clip for fullscreen header
        $chimmc_gradient_clip = ( true === $chimmc_fullscreen_on ) ? '' : et_get_option('chimmc_gradient_clip', 'border-box');
        
        $chimmc_menu_gradient = $chimmc_menu_gradient_angle.'deg, '.$chimmc_menu_gradient_stop1_color.' '.$chimmc_menu_gradient_stop1_location.'%, '.$chimmc_menu_gradient_stop2_color.' '.$chimmc_menu_gradient_stop2_location.'%, '.$chimmc_menu_gradient_stop3_color.' '.$chimmc_menu_gradient_stop3_location.'% ';
    
        $chimmc_menu_moz_linear_gradient = ( $chimmc_menu_gradient_on_off == 'enabled' ) ? '-moz-linear-gradient( '.$chimmc_menu_gradient.' ) '.$chimmc_gradient_clip.' ' : '';
        $chimmc_menu_webkit_linear_gradient = ( $chimmc_menu_gradient_on_off == 'enabled' ) ? '-webkit-linear-gradient( '.$chimmc_menu_gradient.' ) '.$chimmc_gradient_clip.' ' : '';
        $chimmc_menu_o_linear_gradient = ( $chimmc_menu_gradient_on_off == 'enabled' ) ? '-o-linear-gradient( '.$chimmc_menu_gradient.' ) '.$chimmc_gradient_clip.' ' : '';
        $chimmc_menu_ms_linear_gradient = ( $chimmc_menu_gradient_on_off == 'enabled' ) ? '-ms-linear-gradient( '.$chimmc_menu_gradient.' ) '.$chimmc_gradient_clip.' ' : '';
        $chimmc_menu_linear_gradient = ( $chimmc_menu_gradient_on_off == 'enabled' ) ? 'linear-gradient( '.$chimmc_menu_gradient.' ) '.$chimmc_gradient_clip.' ' : '';

        $chimmc_bg_image_on_off = et_get_option('chimmc_bg_image_on_off','disabled');
        $chimmc_bg_image_url = esc_url( et_get_option('chimmc_bg_image_url','') );
        $chimmc_bg_image_size = et_get_option('chimmc_bg_image_size','cover');
        $chimmc_bg_image_position = et_get_option('chimmc_bg_image_position','center');
        $chimmc_bg_image_repeat = et_get_option('chimmc_bg_image_repeat','no-repeat');
        // disable gradient background clip for fullscreen header
        $chimmc_bg_image_clip = ( true === $chimmc_fullscreen_on ) ? '' : et_get_option('chimmc_bg_image_clip','border-box');

        $chimmc_bg_image = ( $chimmc_bg_image_on_off == 'enabled' ) ? 'url('.$chimmc_bg_image_url.') '.$chimmc_bg_image_position.' '.$chimmc_bg_image_repeat.' '.$chimmc_bg_image_clip : '';
        // comma between menu gradient and menu bg image
        $chimmc_bg_comma = ( 'enabled' == $chimmc_bg_image_on_off && 'enabled' == $chimmc_menu_gradient_on_off ) ? ',' : '';
    
        $chimmc_header_gradient_on_off = esc_html( et_get_option('chimmc_header_gradient_on_off','disabled') );
        $chimmc_header_gradient_stop1_color = esc_html( et_get_option('chimmc_header_gradient_stop1_color', $chidmm_header_bg_color) );
        $chimmc_header_gradient_stop1_location = esc_html( et_get_option('chimmc_header_gradient_stop1_location', '0') );
        $chimmc_header_gradient_stop2_color = esc_html( et_get_option('chimmc_header_gradient_stop2_color', $chidmm_header_bg_color) );
        $chimmc_header_gradient_stop2_location = esc_html( et_get_option('chimmc_header_gradient_stop2_location', '35') );
        $chimmc_header_gradient_stop3_color = esc_html( et_get_option('chimmc_header_gradient_stop3_color', $chidmm_header_bg_color) );
        $chimmc_header_gradient_stop3_location = esc_html( et_get_option('chimmc_header_gradient_stop3_location', '75') );
        $chimmc_header_gradient_angle = esc_html( et_get_option('chimmc_header_gradient_angle', '0') );
        
        $chimmc_header_gradient = $chimmc_header_gradient_angle.'deg, '.$chimmc_header_gradient_stop1_color.' '.$chimmc_header_gradient_stop1_location.'%, '.$chimmc_header_gradient_stop2_color.' '.$chimmc_header_gradient_stop2_location.'%, '.$chimmc_header_gradient_stop3_color.' '.$chimmc_header_gradient_stop3_location.'% ';
    
    // END GRADIENTS and BG IMAGE
    
    // START ANIMATIONS - v1.3.0
    
        $chimmc_menu_in_animation = esc_html( et_get_option('chimmc_menu_in_animation','default') );
        $chimmc_menu_out_animation = esc_html( et_get_option('chimmc_menu_out_animation','default') );
    
    // END ANIMATIONS
    
    // MENU HEADER OPTIONS - 1.4.0
        
        $chimmc_header_text_color = et_get_option('chimmc_header_text_color', et_get_option( 'accent_color', '#2ea3f2' ) );
        $chimmc_menu_bar_format = esc_html( et_get_option('chimmc_menu_bar_format','icon_only') ); 
        $chimmc_menu_bar_text = esc_html( et_get_option('chimmc_menu_bar_text','') );
        $chimmc_menu_bar_close_text = esc_html( et_get_option('chimmc_menu_bar_close_text','') );
        $chimmc_menu_bar_close_icon = et_get_option('chimmc_menu_bar_close_icon', false);
        $chimmc_menu_bar_text_size = esc_html( et_get_option('chimmc_menu_bar_text_size', 14) );
        $chimmc_menu_bar_icon_size = esc_html( et_get_option('chimmc_menu_bar_icon_size', 32) );
        // calculate search icon size relatively to hamburger icon size
        $chimmc_menu_search_icon_size = round( $chimmc_menu_bar_icon_size * 0.53125 );
        $chimmc_menu_bar_font_style = et_get_option('chimmc_menu_bar_font_style', '');
    
        $chimmc_menu_dd_top_offset = esc_html( et_get_option('chimmc_menu_dd_top_offset', 0 ) );
        $chimmc_menu_bar_bg_color = esc_html( et_get_option('chimmc_menu_bar_bg_color', 'rgba(0, 0, 0, 0.05)' ) );
    
        $chimmc_search_icon = et_get_option('chimmc_search_icon', false);
        $et_show_search_icon = esc_html( et_get_option('show_search_icon', true) );
        // search icon display
        $search_display = ( true === $chimmc_search_icon ) ? 'block' : 'none';
    
    // END MENU HEADER OPTIONS
    
    // MENU ITEM ICONS
    
        $chimmc_icons_on_off = et_get_option('chimmc_icons_on_off','disabled');
        $chimmc_menu_items_list = et_get_option('chimmc_menu_items_list','');
        $chimmc_sec_menu_items_list = et_get_option('chimmc_sec_menu_items_list','');
        $chimmc_icons_position = esc_html( et_get_option('chimmc_icons_position','before') );
        $chimmc_align_icons_left = et_get_option('chimmc_align_icons_left', false);
        $chimmc_align_icons_right = et_get_option('chimmc_align_icons_right', false);

        $chimmc_menu_icons_size = esc_html( et_get_option('chimmc_menu_icons_size', 14 ) );

        // adjust menu item left and right paddings depending on icon size
        $chimmc_item_padding_l_adjusted = ( ( true === $chimmc_text_left && true === $chimmc_icons_left ) || ( true === $chimmc_fullscreen_on && true === $chimmc_icons_left ) ) ? ( intval( $chimmc_menu_icons_size ) ) + intval( $chimmc_item_padding_left ) : intval( $chimmc_item_padding_left );

        $chimmc_item_padding_r_adjusted = ( ( true === $chimmc_text_right && true === $chimmc_icons_right ) || ( true === $chimmc_fullscreen_on && true === $chimmc_icons_right ) ) ? ( intval( $chimmc_menu_icons_size ) ) + intval( $chimmc_item_padding_right ) : intval( $chimmc_item_padding_right );

        // adjust PARENT menu item arrow left and right paddings depending on icon & text position
        $chimmc_parent_item_pad_l_adjusted = ( true === $chimmc_text_right && true === $chimmc_icons_aligned_left ) ? ( intval( $chimmc_menu_icons_size ) ) + intval( $chimmc_item_padding_left ) : intval( $chimmc_item_padding_left );

        $chimmc_parent_item_pad_r_adjusted = ( ( true === $chimmc_text_left && true === $chimmc_icons_aligned_right ) || ( true === $chimmc_text_center && true === $chimmc_icons_aligned_right ) ) ? ( intval( $chimmc_menu_icons_size ) ) + intval( $chimmc_item_padding_right ) : intval( $chimmc_item_padding_right );
        // parent menu item padding
        $chimmc_parent_item_padding = $chimmc_item_padding_top.'px '.$chimmc_item_padding_r_adjusted.'px '.$chimmc_item_padding_bottom.'px '.$chimmc_item_padding_l_adjusted.'px';
     
    // END MENU ITEM ICONS
        
    ?>
<style type="text/css">
/* Mobile Menu Customizer Plugin Styles */
<?php ob_start(); ?>   
@media all and (max-width: 980px) {
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    body.chi_dmm_styles .chi_mmc_activated .et_mobile_menu > li:not([class^="et_pb_"]) > a<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on ): ?>
    .et_header_style_slide #mobile_menu_slide > li:not([class^="et_pb_"]) > a, 
    .et_header_style_slide #mobile_menu_slide > li:not(.CTA-button) > a > span.et_mobile_menu_arrow:before<?php endif; ?>
    <?php if ( true === $chimmc_fullscreen_on ): ?>
    .et_header_style_fullscreen #mobile_menu_slide > li:not([class^="et_pb_"]) > a, 
    .et_header_style_fullscreen #mobile_menu_slide > li:not(.CTA-button) > a > span.et_mobile_menu_arrow:before<?php endif; ?>{ 
        color: <?php echo esc_html( $chidmm_link_color ); ?> !important; 
    }
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    body.chi_dmm_styles .chi_mmc_activated .et_mobile_menu > li:not(.CTA-button).current-menu-item > a, 
    body.chi_dmm_styles .chi_mmc_activated .et_mobile_menu > li:not(.CTA-button).current-menu-parent > a, 
    body.chi_dmm_styles .chi_mmc_activated .et_mobile_menu > li:not(.CTA-button).current-menu-ancestor > a 
    <?php endif; ?>
    <?php if ( true === $chimmc_fullscreen_on || true === $chimmc_slide_in_on ): ?>
    .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-item > a, 
    .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-item > a > span.et_mobile_menu_arrow:before,
    .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-parent > a, 
    .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-parent > a > span.et_mobile_menu_arrow:before,
    .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-ancestor > a,
    .et_slide_in_menu_container #mobile_menu_slide > li:not(.CTA-button).current-menu-ancestor > a > span.et_mobile_menu_arrow:before <?php endif; ?>{ 
        color: <?php echo esc_html( $chidmm_active_link_color ); ?> !important; 
    }
<?php if ( true === $chimmc_fullscreen_on || true === $chimmc_slide_in_on ): ?>
    <?php if ( true === $chimmc_slide_in_on ): ?>
    body.chi_dmm_styles.et_header_style_slide #page-container .et_slide_in_menu_container, 
    body.chi_dmm_styles.et_header_style_slide #main-header .nav li ul, 
    body.chi_dmm_styles.et_header_style_slide .et-search-form<?php endif; ?>   
    <?php if ( true === $chimmc_fullscreen_on ): ?>
    body.chi_dmm_styles.et_header_style_fullscreen #page-container .et_slide_in_menu_container<?php endif; ?> { 
        background-color: <?php echo esc_html( $chidmm_bg_color ); ?> !important; 
    }
<?php endif; ?>
<?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu { 
        background-color: <?php echo esc_html( $chidmm_bg_color ); ?> !important; overflow: hidden;
    }
<?php endif; ?>
    body.chi_dmm_styles #main-header.chi_mmc_activated { 
        background-color: <?php echo esc_html( $chidmm_header_bg_color ); ?> !important; 
    }
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    body.chi_dmm_styles #top-header<?php endif; ?>
    <?php if ( true === $chimmc_fullscreen_on || true === $chimmc_slide_in_on ): ?>
    body.chi_dmm_styles .et_slide_menu_top<?php endif; ?>{ 
        background-color: <?php echo esc_html( $chidmm_top_header_bg_color ); ?> !important; 
    }
<?php if ( false === $chimmc_fullscreen_on ): ?>
    <?php if ( false === $chimmc_slide_in_on ): ?>
    body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li ul.sub-menu<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on ): ?>
    body.chi_dmm_styles.et_header_style_slide #page-container .et_slide_in_menu_container #mobile_menu_slide li ul.sub-menu<?php endif; ?> { 
        background-color: <?php echo esc_html( $chidmm_submenu_bg_color ); ?> !important; 
    }
<?php endif; ?>
<?php if ( ( false === $chimmc_fullscreen_on && false === $chimmc_slide_in_on ) && $chimmc_submenu_animation != 'none' ): ?>    
    #main-header .et_mobile_menu.chidmm_collapsable li.visible > ul.sub-menu { 
        -webkit-animation: <?php echo $chimmc_submenu_animation;?> <?php echo $chimmc_submenu_animation_speed;?>s ease-in-out forwards;
        animation: <?php echo $chimmc_submenu_animation;?> <?php echo $chimmc_submenu_animation_speed;?>s ease-in-out forwards;
    }
<?php endif; ?>
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li ul.sub-menu a<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on ): ?>
    .et_header_style_slide #mobile_menu_slide li ul.sub-menu a, 
    .et_header_style_slide #mobile_menu_slide li ul.sub-menu span.et_mobile_menu_arrow::before<?php endif; ?>
    <?php if ( true === $chimmc_fullscreen_on ): ?>
    .et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li a , 
    .et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li span.et_mobile_menu_arrow::before<?php endif; ?> { 
        color: <?php echo esc_html( $chidmm_submenu_link_color ); ?> !important; 
        font-size: <?php echo esc_html( $chidmm_submenu_font_size ); ?>px !important; 
    }
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li ul.sub-menu li.current-menu-item > a, 
    body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li ul.sub-menu li.current-menu-parent > a, 
    body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li ul.sub-menu li.current-menu-ancestor > a<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on ): ?>
    .et_header_style_slide #mobile_menu_slide li ul.sub-menu li.current-menu-item > a, 
    .et_header_style_slide #mobile_menu_slide li ul.sub-menu li.current-menu-item > a > span.et_mobile_menu_arrow::before,
    .et_header_style_slide #mobile_menu_slide li ul.sub-menu li.current-menu-parent > a,
    .et_header_style_slide #mobile_menu_slide li ul.sub-menu li.current-menu-parent > a > span.et_mobile_menu_arrow::before,
    .et_header_style_slide #mobile_menu_slide li ul.sub-menu li.current-menu-ancestor > a, 
    .et_header_style_slide #mobile_menu_slide li ul.sub-menu li.current-menu-ancestor > a > span.et_mobile_menu_arrow::before<?php endif; ?> 
    <?php if ( true === $chimmc_fullscreen_on ): ?>
    .et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li.current-menu-item > a, 
    .et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li.current-menu-item > a > span.et_mobile_menu_arrow::before,
    .et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li.current-menu-parent > a, 
    .et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li.current-menu-parent > a > span.et_mobile_menu_arrow::before,
    .et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li.current-menu-ancestor > a,
    .et_header_style_fullscreen #mobile_menu_slide li ul.sub-menu li.current-menu-ancestor > a > span.et_mobile_menu_arrow::before <?php endif; ?>{ 
        color: <?php echo esc_html( $chidmm_submenu_active_link_color ); ?> !important; 
    }
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li:not(.CTA-button) ul.sub-menu a<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on ): ?>
    body.chi_dmm_styles.et_header_style_slide #page-container .et_slide_in_menu_container #mobile_menu_slide li:not(.CTA-button) ul.sub-menu a<?php endif; ?>
    <?php if ( true === $chimmc_fullscreen_on ): ?>
    body.chi_dmm_styles.et_header_style_fullscreen #page-container .et_pb_fullscreen_nav_container #mobile_menu_slide li:not(.CTA-button) ul.sub-menu li:not(.CTA-button) a<?php endif; ?> { 
        <?php echo esc_html( et_pb_print_font_style( $chidmm_submenu_font_style ) ); ?> 
    }
<?php if (true === $chimmc_arrow_styles_on){ ?>
    /* parent menu item arrow */
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ){ ?>
    .chimmc_arrow_custom span.chimmc_mobile_menu_arrow
    <?php } ?>
    <?php if ( true === $chimmc_fullscreen_on || true === $chimmc_slide_in_on ){ ?>
    .chimmc_arrow_custom .et_slide_in_menu_container span.et_mobile_menu_arrow
    <?php } ?> {
        background-color: <?php echo $chimmc_parent_arrow_bg_color; ?>;
        border-width: <?php echo $chimmc_parent_arrow_brdr_width; ?>;
        border-color: <?php echo $chimmc_parent_arrow_brdr_color; ?>;
        border-radius: <?php echo $chimmc_parent_arrow_brdr_radius; ?>;
        padding: <?php echo $chimmc_parent_arrow_padding; ?>;
    }
    <?php 
    // adjust quotation mark for arrow content
        $arr_quotes = ( $chimmc_parent_arrow == '"' || $chimmc_parent_arrow == "'" ) ? "'" : '"' ;
        $arr_backslash = ( $chimmc_parent_arrow == '\\' || $chimmc_parent_arrow == "'" ) ? '\\' : '' ;
    ?>
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ){ ?>
    .chimmc_arrow_custom .chimmc_mobile_menu_arrow:before, 
    .chimmc_arrow_custom ul.sub-menu a span.chimmc_mobile_menu_arrow:before
    <?php } ?>
    <?php if ( true === $chimmc_slide_in_on ){ ?>
    .chimmc_arrow_custom.et_header_style_slide #mobile_menu_slide > li:not(.CTA-button) > a > span.et_mobile_menu_arrow:before,
    .chimmc_arrow_custom .et_slide_in_menu_container #mobile_menu_slide li ul.sub-menu li span.et_mobile_menu_arrow::before
    <?php } ?>
    <?php if ( true === $chimmc_fullscreen_on ){ ?>
    .chimmc_arrow_custom.et_header_style_fullscreen #mobile_menu_slide > li:not(.CTA-button) > a > span.et_mobile_menu_arrow:before,
    .chimmc_arrow_custom .et_slide_in_menu_container #mobile_menu_slide li ul.sub-menu li span.et_mobile_menu_arrow::before
    <?php } ?> {
        content: <?php echo  $arr_quotes.''.$arr_backslash.''.$chimmc_parent_arrow.''.$arr_quotes; ?>;
        font-size: <?php echo $chimmc_parent_arrow_size; ?>px !important;
        color: <?php echo $chimmc_parent_arrow_color; ?> !important;
    }
    /* main menu active arrow */
    <?php if($chimmc_a_parent_arrow_color != $chimmc_parent_arrow_color) {?>
        <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ){ ?>
        .chimmc_arrow_custom .current-menu-item > a > .chimmc_mobile_menu_arrow:before, 
        .chimmc_arrow_custom .current-menu-parent > a > .chimmc_mobile_menu_arrow:before, 
        .chimmc_arrow_custom .current-menu-ancestor > a > .chimmc_mobile_menu_arrow:before 
        <?php } ?>
        <?php if ( true === $chimmc_fullscreen_on || true === $chimmc_slide_in_on ){ ?> 
        .chimmc_arrow_custom #mobile_menu_slide li:not(.CTA-button).current-menu-item > a > span.et_mobile_menu_arrow:before, 
        .chimmc_arrow_custom #mobile_menu_slide li:not(.CTA-button).current-menu-parent > a > span.et_mobile_menu_arrow:before, 
        .chimmc_arrow_custom #mobile_menu_slide li:not(.CTA-button).current-menu-ancestor > a > span.et_mobile_menu_arrow:before <?php } ?>{
            color: <?php echo $chimmc_a_parent_arrow_color; ?> !important;
        }
    <?php } ?>
    /* sub-menu active arrow */
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ){ ?>
    .chimmc_arrow_custom .sub-menu .current-menu-item > a > .chimmc_mobile_menu_arrow:before, 
    .chimmc_arrow_custom .sub-menu .current-menu-parent > a > .chimmc_mobile_menu_arrow:before, 
    .chimmc_arrow_custom .sub-menu .current-menu-ancestor > a > .chimmc_mobile_menu_arrow:before 
    <?php } ?>
    <?php if ( true === $chimmc_slide_in_on ){ ?> 
    .chimmc_arrow_custom #mobile_menu_slide li ul.sub-menu li.current-menu-item span.et_mobile_menu_arrow::before, 
    .chimmc_arrow_custom #mobile_menu_slide li ul.sub-menu li.current-menu-parent > a > span.et_mobile_menu_arrow::before,
    .chimmc_arrow_custom #mobile_menu_slide li ul.sub-menu li.current-menu-ancestor > a > span.et_mobile_menu_arrow::before
    <?php } ?> 
    <?php if ( true === $chimmc_fullscreen_on ){ ?>
    .chimmc_arrow_custom .et_slide_in_menu_container #mobile_menu_slide .sub-menu li.current-menu-item span.et_mobile_menu_arrow::before, 
    .chimmc_arrow_custom .et_slide_in_menu_container #mobile_menu_slide .sub-menu li.current-menu-parent > a > span.et_mobile_menu_arrow::before, 
    .chimmc_arrow_custom .et_slide_in_menu_container #mobile_menu_slide .sub-menu li.current-menu-ancestor > a > span.et_mobile_menu_arrow::before 
    <?php } ?>{ 
        color: <?php echo esc_html( $chimmc_a_parent_arrow_color ); ?> !important; 
    }
    /* arrow rotation degree */
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ){ ?>
    .chimmc_arrow_custom .menu-item-has-children.visible > a > span.chimmc_mobile_menu_arrow:before
    <?php } ?>
    <?php if ( true === $chimmc_fullscreen_on || true === $chimmc_slide_in_on ){ ?>
    .chimmc_arrow_custom .et_slide_in_menu_container span.et_pb_submenu_opened.et_mobile_menu_arrow:before 
    <?php } ?> {
        -webkit-transform: rotate(<?php echo $chimmc_parent_arrow_rotate; ?>deg);
        -ms-transform: rotate(<?php echo $chimmc_parent_arrow_rotate; ?>deg);
        transform: rotate(<?php echo $chimmc_parent_arrow_rotate; ?>deg);
    }
<?php } ?>  
<?php if ( false === $chimmc_fullscreen_on ): ?>
    <?php if ( false === $chimmc_slide_in_on ): ?>
    body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .et_mobile_menu<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on ): ?>
    body.et_header_style_slide .et_slide_in_menu_container.et_pb_slide_menu_opened<?php endif; ?> { 
        -webkit-box-shadow: <?php echo $chimmc_dd_menu_shadow; ?> !important; 
        -moz-box-shadow: <?php echo $chimmc_dd_menu_shadow; ?> !important; 
        box-shadow: <?php echo $chimmc_dd_menu_shadow; ?> !important; 
    }
<?php endif; ?>
<?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ){ ?>
    .chi_dmm_styles .mobile_nav ul#mobile_menu.et_mobile_menu > li > a { 
        font-size: <?php echo esc_html( $chidmm_font_size ); ?>px !important; 
    }
<?php } ?>
    
<?php if ( true === $chimmc_icons_enabled ): ?>
    li.chimmc-has-icon a:before, li.chimmc-has-icon a:after {
        font-size: <?php echo $chimmc_menu_icons_size ; ?>px ;
    }
<?php endif; ?>
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    .chi_dmm_styles .mobile_nav ul#mobile_menu.et_mobile_menu li:not(.CTA-button).chimmc-has-icon > a<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on || true === $chimmc_fullscreen_on ): ?>
    .chi_dmm_styles ul#mobile_menu_slide.et_mobile_menu li:not(.CTA-button).chimmc-has-icon > a<?php endif; ?> { 
        padding: <?php echo $chimmc_parent_item_padding;?>;
    }
    
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    .chi_dmm_styles .mobile_nav ul#mobile_menu.et_mobile_menu li:not([class^="et_pb_"]):not(.chimmc-has-icon) > a<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on || true === $chimmc_fullscreen_on ): ?>
    .chi_dmm_styles ul#mobile_menu_slide.et_mobile_menu li:not([class^="et_pb_"]):not(.chimmc-has-icon) > a<?php endif; ?> { 
        padding: <?php echo $chimmc_parent_item_padding;?>;
    }
      
<?php if ( false === $chimmc_fullscreen_on ){ ?>
    <?php if ( false === $chimmc_slide_in_on ){ ?>
    /* adjust arrow position depending on menu item icon alignment */
        .chimmc_icons_aligned_right .et_mobile_menu li:not(.CTA-button).menu-item-has-children.chimmc-has-icon > a span.chimmc_mobile_menu_arrow {
            margin-right: <?php echo $chimmc_parent_item_pad_r_adjusted ;?>px ;
        }
        .chimmc_icons_aligned_left .et_mobile_menu li:not(.CTA-button).menu-item-has-children.chimmc-has-icon > a span.chimmc_mobile_menu_arrow {
            margin-left: <?php echo $chimmc_parent_item_pad_l_adjusted ;?>px ;
        }
    <?php } ?>
    
    <?php if ( true === $chimmc_slide_in_on ){ ?>
    /* adjust arrow position depending on menu item icon alignment */
        .et_header_style_slide.chimmc_icons_aligned_right ul#mobile_menu_slide.et_mobile_menu li:not(.CTA-button).chimmc-has-icon > a .et_mobile_menu_arrow {
            margin-right: <?php echo $chimmc_parent_item_pad_r_adjusted ;?>px ;
        }
        .et_header_style_slide.chimmc_icons_aligned_left ul#mobile_menu_slide.et_mobile_menu li:not(.CTA-button).chimmc-has-icon > a .et_mobile_menu_arrow {
            margin-left: <?php echo $chimmc_parent_item_pad_l_adjusted ;?>px ;
        }
    <?php } ?>
    
    <?php if ( true === $chimmc_slide_in_on ){ ?>
    /* adjust arrow position as the left and right padding of parent item is changed */
    body.chi_dmm_styles.et_header_style_slide ul#mobile_menu_slide.et_mobile_menu li:not(.CTA-button) > a .et_mobile_menu_arrow { 
        margin-left: <?php echo $chimmc_item_padding_left ;?>px ;
        margin-right: <?php echo $chimmc_item_padding_right ;?>px ;
    }
    <?php } ?>
<?php } ?>

<?php if ( false === $chimmc_fullscreen_on ): ?>
    <?php if ( false === $chimmc_slide_in_on ): ?>
    body.chi_dmm_styles .chi_mmc_activated .mobile_nav ul#mobile_menu.et_mobile_menu li:not([class^="et_pb_"]) a<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on ): ?>
    body.chi_dmm_styles ul#mobile_menu_slide.et_mobile_menu li:not([class^="et_pb_"]) a<?php endif; ?> { 
        text-align: <?php echo esc_html( $chidmm_text_align ); ?>; 
    }
    <?php if ( $chidmm_text_align !== "right" ) { ?>
    <?php if ( false === $chimmc_slide_in_on ): ?>
    body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu .menu-item-has-children > a span.chimmc_mobile_menu_arrow<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on ): ?>
    body.chi_dmm_styles .et_slide_in_menu_container span.et_mobile_menu_arrow<?php endif; ?> { 
        right: 0px; 
    }<?php } else { ?>
    <?php if ( false === $chimmc_slide_in_on ): ?>
    body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu .menu-item-has-children > a span.chimmc_mobile_menu_arrow<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on ): ?>
    body.chi_dmm_styles .et_slide_in_menu_container span.et_mobile_menu_arrow<?php endif; ?> { 
        left: 0px; 
        right: auto; 
    }
    <?php } ?>
<?php endif; ?>
<?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    body.chi_dmm_styles #main-header.chi_mmc_activated, body.chi_dmm_styles #top-header { 
        position: <?php echo $chidmm_fixed; ?> !important; 
    }
    <?php if ( $chidmm_fixed == "fixed" ) { ?> 
        body.chi_dmm_styles .chi_mmc_activated #mobile_menu { 
            overflow-y: <?php echo esc_html( $fixed_menu_overflow_y ); ?> !important; 
            max-height: <?php echo esc_html( $chidmm_fixed_menu_height ); ?>vh !important; 
            -ms-overflow-style: -ms-autohiding-scrollbar; 
        }
    <?php } ?>
    body.chi_dmm_styles #top-header { 
        width: 100% !important; 
    }
<?php endif; ?>
<?php if ( false === $chimmc_fullscreen_on ): ?>
    <?php if ( false === $chimmc_slide_in_on ): ?>
    body.chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not([class^="et_pb_"])<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on ): ?>
    body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not([class^="et_pb_"])<?php endif; ?> { 
        background-color: <?php echo esc_html( $chidmm_item_bg_color ); ?> !important; 
        border-width: <?php echo $chidmm_item_border_width; ?> !important; 
        border-style: solid; 
        border-color: <?php echo esc_html( $chidmm_item_border_color ); ?> !important; 
        -webkit-border-radius: <?php echo $chimmc_item_border_radius; ?> !important; 
        -moz-border-radius: <?php echo $chimmc_item_border_radius; ?> !important; 
        border-radius: <?php echo $chimmc_item_border_radius; ?> !important; 
        overflow: hidden; 
    }
    <?php if ( false === $chimmc_slide_in_on ): ?>
    body.chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button).current-menu-item, 
    body.chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button).current-menu-parent, 
    body.chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu > li:not(.CTA-button).current-menu-ancestor<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on ): ?>
    body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not(.CTA-button).current-menu-item, 
    body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not(.CTA-button).current-menu-parent, 
    body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu > li:not(.CTA-button).current-menu-ancestor<?php endif; ?> { 
        background-color: <?php echo esc_html( $chidmm_current_item_bg_color ); ?> !important; 
    }
<?php endif; ?>
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    .chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu li:not([class^="et_pb_"]):not(:first-of-type)<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on || true === $chimmc_fullscreen_on ): ?>
    .chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu li:not([class^="et_pb_"]):not(:first-of-type)<?php endif; ?> { 
        margin-top: <?php echo esc_html( $chidmm_items_margins ); ?>px; 
    }
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    .chi_dmm_styles .chi_mmc_activated ul.et_mobile_menu li:not([class^="et_pb_"]):not(:last-of-type)<?php endif; ?>
    <?php if ( true === $chimmc_slide_in_on || true === $chimmc_fullscreen_on ): ?>
    .chi_dmm_styles .et_slide_in_menu_container ul.et_mobile_menu li:not([class^="et_pb_"]):not(:last-of-type)<?php endif; ?> { 
        margin-bottom: <?php echo esc_html( $chidmm_items_margins ); ?>px; 
    }
<?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    body.chi_dmm_styles .chi_mmc_activated .et_mobile_menu { 
        padding: <?php echo $chimmc_dd_menu_padding; ?>; 
        border-color: <?php echo esc_html( $chidmm_border_color ); ?> !important; 
        border-width: <?php echo $chidmm_border_width; ?> !important; 
        border-style: solid; 
        -webkit-border-radius: <?php echo $chimmc_border_radius; ?> !important; 
        -moz-border-radius: <?php echo $chimmc_border_radius; ?> !important; 
        border-radius: <?php echo $chimmc_border_radius; ?> !important; 
    }
<?php endif; ?>
<?php if ( true === $chimmc_slide_in_on ): ?>
    body.et_header_style_slide.chi_dmm_styles .et_slide_in_menu_container .et_mobile_menu { 
        padding: <?php echo $chimmc_padding_slide; ?> !important; 
    }
<?php endif; ?>
<?php if ( true === $chimmc_slide_in_on || true === $chimmc_fullscreen_on ): ?>
    .chi_dmm_styles ul#mobile_menu_slide.et_mobile_menu > li > a { 
        font-size: <?php echo esc_html( $chidmm_font_size ); ?>px !important; 
    }
<?php endif; ?>
<?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu li:not([class^="et_pb_"]) a { 
        letter-spacing: <?php echo esc_html( $chidmm_letter_spacing ); ?>px !important; 
    } 
    body.chi_dmm_styles #main-header.chi_mmc_activated .et_mobile_menu > li > a { 
        <?php echo esc_html( et_pb_print_font_style( $chidmm_font_style ) ); ?> 
    }
<?php endif; ?>
<?php if ($chimmc_menu_gradient_on_off == 'enabled' || $chimmc_bg_image_on_off == 'enabled' ): ?>
    body.chi_dmm_styles .chi_mmc_activated #mobile_menu, body.chi_dmm_styles .et_slide_in_menu_container {
        <?php if ( $chimmc_menu_gradient_on_off == 'enabled' ): ?>
        background: <?php echo $chimmc_menu_gradient_stop1_color; ?> !important;<?php endif; ?>
        background: <?php echo $chimmc_menu_moz_linear_gradient.' '.$chimmc_bg_comma.' '.$chimmc_bg_image;?> !important; 
        background: <?php echo $chimmc_menu_webkit_linear_gradient.' '.$chimmc_bg_comma.' '.$chimmc_bg_image;?> !important; 
        background: <?php echo $chimmc_menu_o_linear_gradient.' '.$chimmc_bg_comma.' '.$chimmc_bg_image;?> !important; 
        background: <?php echo $chimmc_menu_ms_linear_gradient.' '.$chimmc_bg_comma.' '.$chimmc_bg_image;?> !important; 
        background: <?php echo $chimmc_menu_linear_gradient.' '.$chimmc_bg_comma.' '.$chimmc_bg_image;?> !important;
        <?php if ( $chimmc_bg_image_on_off == 'enabled' ): ?>
        background-size: <?php echo $chimmc_bg_image_size; ?> !important;
        <?php endif; ?>
    }
<?php endif; ?>
<?php if ($chimmc_header_gradient_on_off == 'enabled'): ?>
    body.chi_dmm_styles #main-header.chi_mmc_activated { 
        background: <?php echo $chimmc_header_gradient_stop1_color ; ?>; 
        background: -moz-linear-gradient(<?php echo $chimmc_header_gradient ; ?>); 
        background: -webkit-linear-gradient(<?php echo $chimmc_header_gradient ; ?>); 
        background: -o-linear-gradient(<?php echo $chimmc_header_gradient ; ?>); 
        background: -ms-linear-gradient(<?php echo $chimmc_header_gradient ; ?>); 
        background: linear-gradient(<?php echo $chimmc_header_gradient ; ?>); }
<?php endif; ?>
<?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    <?php if ( $chimmc_menu_in_animation != 'default' ) { ; ?>
    body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles #main-header.chi_mmc_activated .mobile_nav.opened .et_mobile_menu { 
        animation: <?php echo $chimmc_menu_in_animation; ?> .8s ease; 
        -webkit-animation: <?php echo $chimmc_menu_in_animation; ?> .8s ease; 
    }
    <?php } ;?>
    <?php if ( $chimmc_menu_out_animation != 'default' ) { ; ?>
    body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles #main-header.chi_mmc_activated .mobile_nav.closed .et_mobile_menu { 
        animation: <?php echo $chimmc_menu_out_animation; ?> .8s ease; 
        -webkit-animation: <?php echo $chimmc_menu_out_animation; ?> .8s ease; 
    }
    <?php } ;?>
<?php endif; ?>
<?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    <?php if ( true === $chimmc_centered_on ): ?>
    body.chi_dmm_styles.et_header_style_centered .chi_mmc_activated .mobile_nav .select_page, <?php endif; ?>
    <?php if ( true === $chimmc_split_on ): ?>
    body.chi_dmm_styles.et_header_style_split .chi_mmc_activated .mobile_nav .select_page, <?php endif; ?>
    body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .mobile_menu_bar:before, 
    body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated .mobile_menu_bar:after,
    body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles .chi_mmc_activated #et-top-navigation .et-cart-info,
<?php endif; ?>
    body.chi_dmm_styles .chi_mmc_activated #et_search_icon:before, 
    body.chi_dmm_styles .chi_mmc_activated #et_top_search .et-search-form input, 
    body.chi_dmm_styles .chi_mmc_activated .et_search_form_container input, 
    body.chi_dmm_styles .chi_mmc_activated .et_close_search_field:after { 
        color: <?php echo esc_html( $chimmc_header_text_color ); ?> !important; 
    } 
    body.chi_dmm_styles .chi_mmc_activated .et_search_form_container input::-moz-placeholder { 
        color: <?php echo esc_html( $chimmc_header_text_color ); ?> !important; 
    } 
    body.chi_dmm_styles .chi_mmc_activated .et_search_form_container input::-webkit-input-placeholder { 
        color: <?php echo esc_html( $chimmc_header_text_color ); ?> !important; 
    } 
    body.chi_dmm_styles .chi_mmc_activated .et_search_form_container input:-ms-input-placeholder { 
        color: <?php echo esc_html( $chimmc_header_text_color ); ?> !important; 
    }
<?php 
        // swap pseudo elements: after <-> before
        $chimmc_menu_pseudo_1 = ( $chimmc_menu_bar_format == 'text_icon' ) ? 'after' : 'before';
        $chimmc_menu_pseudo_2 = ( $chimmc_menu_bar_format == 'text_icon' ) ? 'before' : 'after';
        // show/hide pseudo elements' content
        $chimmc_menu_pseudo_1_content = ( $chimmc_menu_bar_format == 'text_only' ) ? '' : '\61' ;
        $chimmc_menu_pseudo_2_content = ( $chimmc_menu_bar_format == 'icon_only' ) ? '' : $chimmc_menu_bar_text ;
        // menu "close" text
        $chimmc_menu_pseudo_2_content_close = ( '' != $chimmc_menu_bar_close_text && $chimmc_menu_bar_format != 'icon_only' ) ? $chimmc_menu_bar_close_text : $chimmc_menu_pseudo_2_content;
        //enable/disable "X" icon for closing menu
        $chimmc_menu_pseudo_1_content_close = ( true === $chimmc_menu_bar_close_icon && $chimmc_menu_bar_format != 'text_only' ) ? '\4d' : $chimmc_menu_pseudo_1_content;
    
        // fix for menu icon font weight when text_icon format chosen
        $icon_font_weight_normal = 'body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_left #main-header.chi_mmc_activated .mobile_menu_bar:after, .chi_dmm_styles.et_header_style_split #main-header .mobile_menu_bar:after,.chi_dmm_styles.et_header_style_centered #main-header .mobile_menu_bar:after { font-weight: normal !important; }';
        $pseudo_after_icon_style = ( $chimmc_menu_bar_format == 'text_icon' ) ? $icon_font_weight_normal : '';
    
        // add padding-right to menu bar text
        $menu_icon_text_padding_right = ( $chimmc_menu_bar_format == 'text_icon' || $chimmc_menu_bar_format == 'icon_only' ) ? 0 : 5;
        
    ?>
<?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ): ?>
    .chi_dmm_styles #main-header .mobile_nav.opened .mobile_menu_bar:<?php echo $chimmc_menu_pseudo_1; ?>, 
    .chi_dmm_styles #main-header .mobile_nav.closed .mobile_menu_bar:<?php echo $chimmc_menu_pseudo_1; ?> { 
        font-family: "ETmodules" !important; 
        font-size: <?php echo $chimmc_menu_bar_icon_size; ?>px ; 
    }
    .chi_dmm_styles #main-header.chi_mmc_activated #et_search_icon:before { 
        font-size: <?php echo $chimmc_menu_search_icon_size; ?>px; 
    }
    .chi_dmm_styles #main-header .mobile_nav.closed .mobile_menu_bar:<?php echo $chimmc_menu_pseudo_1; ?> { 
        content: "<?php echo $chimmc_menu_pseudo_1_content; ?>"; 
    }
    .chi_dmm_styles #main-header .mobile_nav.opened .mobile_menu_bar:<?php echo $chimmc_menu_pseudo_1; ?> { 
        content: "<?php echo $chimmc_menu_pseudo_1_content_close; ?>"; 
    }
    .chi_dmm_styles #main-header .mobile_nav.opened .mobile_menu_bar:<?php echo $chimmc_menu_pseudo_2; ?>,
    .chi_dmm_styles #main-header .mobile_nav.closed .mobile_menu_bar:<?php echo $chimmc_menu_pseudo_2; ?> { 
        font-family: inherit !important; 
        font-size: <?php echo $chimmc_menu_bar_text_size; ?>px ; 
        padding: 0px <?php echo $menu_icon_text_padding_right ;?>px 2px 0px;
    }
    <?php if ( true === $chimmc_centered_on || true === $chimmc_split_on ): ?>
    .chi_dmm_styles #main-header .mobile_nav .select_page { 
        font-size: <?php echo $chimmc_menu_bar_text_size; ?>px ; 
        <?php echo esc_html( et_pb_print_font_style( $chimmc_menu_bar_font_style ) ); ?> ; 
    }
        <?php if ( true === $chimmc_search_icon && true === $chimmc_centered_on ):?>
            .et_header_style_centered #et_top_search,
            .et_vertical_nav.et_header_style_centered #main-header #et_top_search { 
                display: block !important;
            }
            .et_header_style_centered .et_search_outer {
                display: block;
            }
        <?php endif; ?>
        <?php if ( true === $chimmc_search_icon && true === $chimmc_split_on ):?>
            .et_header_style_split #et_top_search,
            .et_vertical_nav.et_header_style_split #main-header #et_top_search {
                display: block !important;
            }
            .et_header_style_split .et_search_outer {
                display: block;
            }
        <?php endif; ?>
    <?php endif; ?>
    .chi_dmm_styles #main-header .mobile_nav.closed .mobile_menu_bar:<?php echo $chimmc_menu_pseudo_2; ?> { 
        content: "<?php echo $chimmc_menu_pseudo_2_content; ?>"; 
    }
    .chi_dmm_styles #main-header .mobile_nav.opened .mobile_menu_bar:<?php echo $chimmc_menu_pseudo_2; ?> { 
        content: "<?php echo $chimmc_menu_pseudo_2_content_close; ?>"; 
    }
    .chi_dmm_styles #main-header .mobile_nav.opened .mobile_menu_bar:<?php echo $chimmc_menu_pseudo_2; ?>, 
    .chi_dmm_styles #main-header .mobile_nav.closed .mobile_menu_bar:<?php echo $chimmc_menu_pseudo_2; ?> { 
        <?php echo esc_html( et_pb_print_font_style( $chimmc_menu_bar_font_style ) ); ?> 
    }
    <?php if ( false === $chimmc_centered_on && false === $chimmc_split_on ): ?>
    body:not(.et_header_style_slide):not(.et_header_style_fullscreen).chi_dmm_styles.et_header_style_left #main-header.chi_mmc_activated .et_mobile_menu { 
        margin-top: <?php echo $chimmc_menu_dd_top_offset; ?>px; 
    }
    <?php if ( $chimmc_search_icon != $et_show_search_icon ):?>
    body:not(.et_header_style_slide):not(.et_header_style_fullscreen).et_header_style_left #main-header #et_top_search,
    .et_vertical_nav.et_header_style_left #main-header #et_top_search {
        display: <?php echo esc_html( $search_display );?>;
    }<?php endif; ?>
    <?php endif; ?>
    .chi_dmm_styles.et_header_style_split #main-header .et_mobile_menu, 
    .chi_dmm_styles.et_header_style_centered #main-header .et_mobile_menu { 
        top: <?php echo intval( 53 ) + intval( $chimmc_menu_dd_top_offset ); ?>px; 
    }
    <?php echo $pseudo_after_icon_style; ?>
<?php if ( true === $chimmc_split_on || true === $chimmc_centered_on ): ?>
    <?php if ( true === $chimmc_split_on ): ?>
    .chi_dmm_styles.et_header_style_split #main-header .mobile_nav<?php endif; ?>
    <?php if ( true === $chimmc_centered_on ): ?>
    .chi_dmm_styles.et_header_style_centered #main-header .mobile_nav<?php endif; ?> { 
        background-color: <?php echo $chimmc_menu_bar_bg_color; ?> 
    }
<?php endif; ?>
<?php endif; ?>
<?php
    function chimmc_menu_item_icon_css( $theme_location, $icon_before_after ) {
            if ( ($theme_location) && ($locations = get_nav_menu_locations()) && isset($locations[$theme_location]) ) {
        
                // get body classes
                $chimmc_body_classes = get_body_class();
        
                // check if icons are enabled
                $chimmc_icons_enabled = (in_array('chimmc_icons_enabled', $chimmc_body_classes)) ? true : false ;
                
                $menu = get_term( $locations[$theme_location], 'nav_menu' );
                $menu_items = wp_get_nav_menu_items($menu->term_id);

                $count = 0;
                
                if( !empty( $menu_items ) ) {
                
                foreach( $menu_items as $menu_item ) {

                    $item_ID = $menu_item->ID;
                    
                    $icon_content = et_get_option('chimmc_menu_icon_'.$item_ID , '');
                                             
                    $quotes = ( $icon_content == '"' || $icon_content == "'" ) ? "'" : '"' ;
                    $backslash = ( $icon_content == '\\' || $icon_content == "'" ) ? '\\' : '' ;
                    
                    ?><?php if ( true === $chimmc_icons_enabled ): ?>
    
                        .chimmc_icons_enabled .menu-item-<?php echo $item_ID; ?>.chimmc-has-icon > a:<?php echo $icon_before_after; ?> {
                            content: <?php echo  $quotes.''.$backslash.''.$icon_content.''.$quotes ; ?>;
                        }<?php endif; ?> <?php
                    
                    $count++;
                }
            } 
            }
        }
        // icon picker controls for primary menu
        chimmc_menu_item_icon_css ( 'primary-menu', $chimmc_icons_position );

        // icon picker controls for MMC mobile menu
        chimmc_menu_item_icon_css ( 'chimmc-mobile-menu', $chimmc_icons_position );
    
        // icon picker controls for secondary menu
        chimmc_menu_item_icon_css ( 'secondary-menu', $chimmc_icons_position );

?>
}
<?php if ( $chidmm_fullwidth == 'initial' && (true === $chidmm_fullwidth_phone || true === $chidmm_fullwidth_tablet)) { ?>
    @media all and <?php echo $chimmc_fullwidth_menu_media; ?> {
    <?php if ( false === $chimmc_slide_in_on && false === $chimmc_fullscreen_on ) { ?>
        .chi_dmm_styles .container.et_menu_container { 
            position: <?php echo esc_html( $chidmm_fullwidth ); ?> !important; 
        }
        <?php if ( true === $chimmc_default_on ) { ?>
        .ie.chi_dmm_styles:not(.et_header_style_slide):not(.et_header_style_fullscreen).et_header_style_left #mobile_menu.et_mobile_menu { 
            width: 125% !important; 
            left: -12.5% !important; 
        }<?php } ?>
        <?php if ( true === $chimmc_centered_on ) { ?>
            .chi_dmm_styles.et_header_style_centered #mobile_menu.et_mobile_menu { 
                width: 125% !important; 
                left: -12.5% !important; 
            }
        <?php } ?>
        <?php if ( true === $chimmc_split_on ) { ?>
            .chi_dmm_styles.et_header_style_split #mobile_menu.et_mobile_menu { 
                width: 125% !important; 
                left: -12.5% !important; 
            }
        <?php } ?>
        <?php if ( true === $chimmc_default_on ) { ?>
            .chi_dmm_styles.et_header_style_left .logo_container { 
                width: 90%; 
            }
        <?php } ?>
    <?php } ?>
    }
<?php } ?>   
<?php
    
/**
 * clean up css comments and unnecessary spaces
 */

$chimmc_css_output = "";

$chimmc_css_output = apply_filters( 'chimmc_customizer_css_output', ob_get_clean() );
    
// Remove comments
$chimmc_css_output = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $chimmc_css_output);

// Remove space after colons
$chimmc_css_output = str_replace(': ', ':', $chimmc_css_output);

// Remove whitespace
$chimmc_css_output = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $chimmc_css_output);

// echo css
echo( $chimmc_css_output );    
    
?>

/* End Mobile Menu Customizer Plugin Styles */
</style>
<?php
}
add_action('wp_head', 'chidmm_customizer_css');