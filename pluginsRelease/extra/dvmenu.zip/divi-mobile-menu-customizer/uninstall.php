<?php

/**
 * Fired when the plugin is uninstalled.
 */

// Die if uninstall not called from WordPress

	if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
		die();
	}