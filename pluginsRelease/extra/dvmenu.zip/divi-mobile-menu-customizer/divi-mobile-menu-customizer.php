<?php
/**
* Plugin Name: Divi Mobile Menu Customizer
* Plugin URI: www.divicio.us
* Description: Customize mobile menu of Divi theme via Theme Customizer with live preview. This plugin allows you to style tablet and phone menus for all header formats of Divi theme.
* Author: Ivan Chiurcci(Chi)
* Author URI: www.divicio.us
* Version: 2.6.3
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * MMC plugin version constant
 */
define('CHI_MMC_VERSION', '2.6.3');

class chidmm_customize {
    /**
     * Class constructor
     */
    function __construct(){
        
        /**
         * Enqueue javascript file for live preview 
         */     
        add_action( 'customize_preview_init', array( $this, 'chidmmLiveCustomize') );  
        
        /**
         * Enqueue javascript file for panels, sections and controls
         */
        add_action( 'customize_controls_enqueue_scripts', array( $this, 'chidmmCustomizer' ) );
        
        /**
         * Enqueue js and css files
         */
        add_action( 'wp_enqueue_scripts', array( $this, 'chidmmJsCSS' ), 20 );

        /**
         * register mobile menu 
         */
        add_action( 'init', array( $this, 'chimmc_mobile_menu_location') );
        
        /**
         * add mobile-only menu to header
         */
        add_action( 'et_header_top', array( $this, 'chimmc_add_mobile_menu') );

        /**
         * Add/remove the custom mobile menu CSS class to/from body
         */
        function chimmc_custom_mobile_menu_class( $classes ) {
            
            // add/remove the class if the 'chimmc-mobile-menu' location has been assigned a menu
            if ( has_nav_menu( 'chimmc-mobile-menu' ) ) {
            
                // add class to body class array
                $classes[] = 'chimmc_mobile_menu_assigned';
            
            } else {
                
                // remove the class if no menus assigned to the 'chimmc-mobile-menu' location
                $remove_class = array( 'chimmc_mobile_menu_assigned' );
                
                // Remove class from body class array
                $classes = array_diff( $classes, $remove_class );
                
            }
            
            // Return modified body class array
            return $classes;

        }
        add_filter( 'body_class','chimmc_custom_mobile_menu_class' );

        /**
         * Add CSS classes to body
         */
        function chimmc_body_classes( $classes ) {
            
            $chimmc_header_style = esc_html( et_get_option('header_style', 'left') );
            $chimmc_icons_on_off = esc_html( et_get_option('chimmc_icons_on_off', 'disabled') );
            $chimmc_icons_position = esc_html( et_get_option('chimmc_icons_position', 'before') );
            $chimmc_align_icons_left = et_get_option('chimmc_align_icons_left', false);
            $chimmc_align_icons_right = et_get_option('chimmc_align_icons_right', false);
            $chidmm_text_align = esc_html( et_get_option('chidmm_text_align', 'left') );
            $chidmm_collapse_submenu = et_get_option('chidmm_collapse_submenu', '0');
            $chimmc_parent_clickable = et_get_option('chimmc_parent_clickable', false);
            $chimmc_toggle_submenus = et_get_option('chimmc_toggle_submenus', false);
            $chimmc_arrow_styles_on = et_get_option('chimmc_arrow_styles_on', false);
            
            // add MMC plugin main class
            $classes[] = 'chi_dmm_styles';
            
            if ( $chimmc_icons_on_off == 'enabled' ) :
                $classes[] = 'chimmc_icons_enabled';
                endif;
            
            if ( $chimmc_icons_on_off == 'enabled' && $chimmc_icons_position == 'before' ) :
                $classes[] = 'chimmc_icons_left';
                endif;
            
            if ( $chimmc_icons_on_off == 'enabled' && $chimmc_icons_position == 'after' ) :
                $classes[] = 'chimmc_icons_right';
                endif;
            
            if ( $chimmc_icons_on_off == 'enabled' && true === $chimmc_align_icons_left ) :
                $classes[] = 'chimmc_icons_aligned_left';
                endif;
            
            if ( $chimmc_icons_on_off == 'enabled' && true === $chimmc_align_icons_right ) :
                $classes[] = 'chimmc_icons_aligned_right';
                endif;
            
            if ( $chidmm_text_align == 'left' ) :
                $classes[] = 'chimmc_text_left';
                elseif ( $chidmm_text_align == 'center' ) :
                    $classes[] = 'chimmc_text_center';
                    else :
                        $classes[] = 'chimmc_text_right';
                        endif;
            
            if($chimmc_header_style !== 'slide' || $chimmc_header_style !== 'fullscreen'){
                // clickable parent class
                if ( $chidmm_collapse_submenu == '1' && true === $chimmc_parent_clickable ) :
                    $classes[] = 'chimmc_parent_clickable';
                    endif;
                
                // toggle submenus class
                if ( $chidmm_collapse_submenu == '1' && true === $chimmc_toggle_submenus ) :
                    $classes[] = 'chimmc_toggle_submenus';
                    endif;

                // custom arrow class
                if ( $chidmm_collapse_submenu == '1' && true === $chimmc_arrow_styles_on ) :
                    $classes[] = 'chimmc_arrow_custom';
                    endif;  
            } else {
                // custom arrow class
                if ( true === $chimmc_arrow_styles_on ) :
                    $classes[] = 'chimmc_arrow_custom';
                    endif;
            }
            
            return $classes;

        }
        add_filter( 'body_class','chimmc_body_classes' );
        
        /**
         * Remove classes from body
         */
        function chimmc_remove_body_classes( $wp_classes ) {
            
            // header style
            $chimmc_header_style = esc_html( et_get_option('header_style', 'left') );
            // menu icons position
            $chimmc_icons_position = esc_html( et_get_option('chimmc_icons_position','before') );
            
            if ( $chimmc_icons_position == 'before' ) {
                
                // The class to remove
                $remove_class = array( 'chimmc_icons_aligned_right' );
                
                // Remove class from array
                $wp_classes = array_diff( $wp_classes, $remove_class );
                
            } else {
                
                // The class to remove
                $remove_class = array( 'chimmc_icons_aligned_left' );
                
                // Remove class from array
                $wp_classes = array_diff( $wp_classes, $remove_class );
                
            }
            
            // remove chimmc_parent_clickable class if Slide-in or Fullscreen header enabled
            if ( $chimmc_header_style == 'slide' || $chimmc_header_style == 'fullscreen' ) {
                
                // The class to remove
                $remove_class = array( 'chimmc_parent_clickable' );
                
                // Remove class from array
                $wp_classes = array_diff( $wp_classes, $remove_class );
                
            }
            
            // remove chimmc_toggle_submenus class if Slide-in or Fullscreen header enabled
            if ( $chimmc_header_style == 'slide' || $chimmc_header_style == 'fullscreen' ) {
                
                // The class to remove
                $remove_class = array( 'chimmc_toggle_submenus' );
                
                // Remove class from array
                $wp_classes = array_diff( $wp_classes, $remove_class );
                
            }
                
            // Return modified body class array
            return $wp_classes;
        }
        add_filter( 'body_class', 'chimmc_remove_body_classes', 10, 2 );
    
        /**
         * Add classes to menu items
         */ 
        function chimmc_menu_items_classes( $classes, $menu_item, $args ){
    
            $item_ID = $menu_item->ID;
            
            if ( ! empty( $args->theme_location ) && $args->theme_location !== 'footer-menu' ) {
                
                // add specific class containing menu item id
                $classes[] = 'chimmc-menu-item_'.$item_ID;
                
                // add specific class if menu item has icon
                $chimmc_has_icon = et_get_option('chimmc_menu_icon_'.$item_ID.'','');
                
                if ( $chimmc_has_icon != '' ) {
                    $classes[] = 'chimmc-has-icon';
                }
                
            }

            return $classes;
            
        }
        add_filter('nav_menu_css_class' , 'chimmc_menu_items_classes' , 10 , 3 );

        /**
         * Add class to secondary menu items
         */  
        function chimmc_secondary_nav_item_class( $classes, $item, $args ) {
            if ( 'secondary-menu' === $args->theme_location ) {
                $classes[] = 'sec_menu_item';
            }

            return $classes;
        }
        add_filter( 'nav_menu_css_class', 'chimmc_secondary_nav_item_class', 10, 3 );  
        
        /**
         * Add/remove Divi Layouts to/from mobile menu
         */
        function chimmc_add_pb_to_menu ( $items, $args ) {
            
            // get layouts status (enabled. above, below or above&below)
            $layouts_status = esc_html( et_get_option('chimmc_add_pb_layouts','disabled') );
            
            // get above layout id
            $above_layout_id = esc_html__(et_get_option('chimmc_pb_layouts_add_above',''));
            // get below layout id
            $below_layout_id = esc_html__(et_get_option('chimmc_pb_layouts_add_below',''));
            
            if ($args->theme_location == 'chimmc-mobile-menu') {
                
                // above layout
                $above_layout = ($layouts_status == 'above' || $layouts_status == 'above_below') ? do_shortcode('[et_pb_section global_module="'.$above_layout_id.'"][/et_pb_section]') : '';
                
                // below layout
                $below_layout = ($layouts_status == 'below' || $layouts_status == 'above_below') ? do_shortcode('[et_pb_section global_module="'.$below_layout_id.'"][/et_pb_section]') : '';
                
                // updated menu
                $items = $above_layout . $items . $below_layout;
                
            }
            return $items;
        }
        
        // get layouts status (enabled. above, below or above&below)
        $layouts_status = get_option('chimmc_add_pb_layouts');
        
        if ( isset($layouts_status) && $layouts_status != 'disabled' ) { 
        
            add_filter( 'wp_nav_menu_items', 'chimmc_add_pb_to_menu', 10, 2 );
            
        }    
        
    }
     
    function chidmmLiveCustomize() {
            wp_enqueue_script( 'chidmm-customizer-js', plugin_dir_url( __FILE__ ) . 'js/customize-preview.js', array('jquery' , 'customize-preview' ), '1.0', false );
        }
    function chidmmCustomizer() {
            // customizer css
            wp_enqueue_style( 'dmm-customizer-css', plugin_dir_url( __FILE__ ) . 'css/customize-controls.css', array(), '1.0' );
            // customizer js
            wp_enqueue_script( 'dmm-customizer-js', plugin_dir_url( __FILE__ ) . 'js/customize-controls.js', array( 'jquery' ), '1.0', true );
            // Settings values for conditional controls 
            wp_localize_script('dmm-customizer-js', 'Chi_DMM_Options', array( 
                'chi_header_style_D' => esc_html( et_get_option('header_style','left') ),
                'chimmc_fixed_menu' => esc_html( et_get_option('chidmm_fixed','absolute') ),
                'chimmc_fullwidth' => esc_html( et_get_option('chidmm_fullwidth','relative') ),
                'chimmc_element_with_gradient' => esc_html( et_get_option('chimmc_element_with_gradient','menuHeader') ),
                'chimmc_icons_on_off' => esc_html( et_get_option('chimmc_icons_on_off','disabled') ),
                'chimmc_icons_position' => esc_html( et_get_option('chimmc_icons_position','before') ),
                'chimmc_bg_image_on_off' => esc_html( et_get_option('chimmc_bg_image_on_off','disabled') ),
                'chimmc_menu_gradient_on_off' => esc_html( et_get_option('chimmc_menu_gradient_on_off','disabled') ),
                'chimmc_header_gradient_on_off' => esc_html( et_get_option('chimmc_header_gradient_on_off','disabled') ),
            ) );
        }
    function chidmmJsCSS() {
            wp_enqueue_style( 'chi-dmm-css', plugin_dir_url( __FILE__ ) . 'css/styles.css', array(), '1.0' );
            wp_enqueue_script( 'dmm-general-js', plugin_dir_url( __FILE__ ) . 'js/general.js', array( 'jquery' ), '1.0', true );
            wp_localize_script('dmm-general-js', 'Chi_MMC_gen_options', array( 
                'collapseSubmenu' => esc_html( et_get_option('chidmm_collapse_submenu','0') ),
                'fixedMenu' => esc_html( et_get_option('chidmm_fixed','absolute') ),
                'customInAnimation' => esc_html( et_get_option('chimmc_menu_in_animation','default') ),
                'customOutAnimation' => esc_html( et_get_option('chimmc_menu_out_animation','default') ),
                'showSearchIcon' => esc_html( et_get_option('chimmc_search_icon', false) ),
                'etShowSearchIcon' => esc_html( et_get_option('show_search_icon', true) ),
                'chimmc_sec_menu_items_position' => esc_html( et_get_option('chimmc_sec_menu_items_position', 'after') ),
            ) );
        }

    /**
     * MMC mobile menu location
     */
    public function chimmc_mobile_menu_location() {

      register_nav_menu('chimmc-mobile-menu', esc_html__( 'MMC Mobile Menu' ));

    }
    
    /**
     * add MMC mobile-only menu to header
     */
    public function chimmc_add_mobile_menu() { ?>
        
        <?php if ( is_customize_preview() || ( 'slide' !== et_get_option( 'header_style', 'left' ) && 'fullscreen' !== et_get_option( 'header_style', 'left' ) ) ) {
        
            $menuClass = 'et_mobile_menu chimmc_mobile_menu';
        
            $MMCmobileNav = '';
        
            // get body css classes
            $body_classes = get_body_class();
            
            // if body has the chimmc_mobile_menu_assigned class the use the custom mobile menu
            $theme_location = in_array('chimmc_mobile_menu_assigned', $body_classes) ? 'chimmc-mobile-menu' : 'primary-menu';

            $MMCmobileNav = wp_nav_menu( array( 'theme_location' => $theme_location, 'container' => '', 'fallback_cb' => '', 'menu_class' => $menuClass, 'menu_id' => 'mobile_menu', 'echo' => false ) );
        
            if ( '' == $MMCmobileNav ) {

                // add an empty ul tag so that secondary nav items could be added to mobile menu
                $MMCmobileNav = '<ul id="mobile_menu" class="et_mobile_menu chimmc_mobile_menu"></ul>';

            }

            //if ( '' != $MMCmobileNav ) :    

            printf(
                '<div id="et_mobile_nav_menu" class="chimmc_mobile_nav_menu">
                    <div class="mobile_nav closed">
                        <span class="select_page">%1$s</span>
                        <span class="mobile_menu_bar mobile_menu_bar_toggle"></span>
                        %2$s
                    </div>
                </div>',
                esc_html__( 'Select Page', 'Divi' ),
                $MMCmobileNav
            );

            //endif; // if ( '' != $MMCmobileNav )
        
        }

     }

}

/**
 * remove et_add_mobile_navigation action 
 */        
add_action( 'after_setup_theme', 'remove_et_add_mobile_navigation_action', 11 );

function remove_et_add_mobile_navigation_action(){
    
    remove_action('et_header_top', 'et_add_mobile_navigation');
    
}
    
/**
 * Require customizer controls
 */
require_once( plugin_dir_path( __FILE__ ) . 'includes/chidmm-controls.php' );

/**
 * Require plugin updater
 */
require_once('includes/chi_mmc_plugin_licensing.php');

/**
 * Instantiate the plugin
 */
global $chidmm_customize;

$chidmm_customize = new chidmm_customize();

$chidmm_customize->pluginurl = plugins_url( '/', __FILE__ );
